extends Node2D
# Hoshi no Ko - Creature with Needs, AI, and Reproduction

const HAIR_COLORS = [
	Color(1.0, 0.63, 0.71),   # pink
	Color(0.78, 0.67, 0.90),  # lilac
	Color(0.51, 0.82, 0.78),  # teal
	Color(1.0, 0.82, 0.39),   # gold
]
const EYE_COLORS = [
	Color(0.39, 0.67, 0.92),  # blue
	Color(0.67, 0.47, 0.86),  # violet
	Color(0.39, 0.78, 0.55),  # green
	Color(0.90, 0.39, 0.43),  # red
]
const DRESS_COLORS = [
	Color(1.0, 0.71, 0.82),   # pink dress
	Color(0.82, 0.71, 0.94),  # lilac dress
	Color(0.63, 0.90, 0.82),  # mint dress
	Color(1.0, 0.86, 0.47),   # gold dress
]

# Visual improvement: Real anime sprites from assets
var variant_names := ["pink_blue", "lilac_violet", "teal_green", "gold_red"]
var stage_names := ["embryo", "juvenile", "adult", "elder"]
var current_sprite: Texture2D = null
var facing_right: bool = true
var base_scale: float = 1.0

# ── Core Stats ────────────────────────────────────────────────────────────────
var genome: Genome = null
var life_stage: int = Constants.LIFE_STAGE_JUVENILE
var age_hours: float = 0.0
var health: float = 100.0
var color_variant: int = 0

# ── Physiological Needs (0-100) ───────────────────────────────────────────────
var hunger: float       = 85.0
var thirst: float       = 85.0
var fatigue: float      = 85.0   # rest
var repro_drive: float  = 0.0

# ── AI State ──────────────────────────────────────────────────────────────────
enum AIState { WANDER, SEEK_FOOD, SEEK_WATER, REST, SEEK_ENEMY, REPRODUCE, FLEE }
var ai_state: AIState = AIState.WANDER
var target_pos: Vector2 = Vector2.ZERO
var target_food: Node2D = null     # food item being chased
var target_mate: Node2D = null
var target_enemy: Node2D = null    # enemy being hunted (SEEK_ENEMY state)
var repro_cooldown: float = 0.0    # seconds until next breed possible
var _eat_anim: float = 0.0         # brief eat animation timer
var drink_cooldown: float = 0.0

# ── Movement ──────────────────────────────────────────────────────────────────
var move_dir: Vector2 = Vector2.ZERO
var move_timer: float = 0.0

# ── Animation ─────────────────────────────────────────────────────────────────
var _blink_timer: float = 0.0
var _blink_open: bool = true
var _bob_phase: float = 0.0
var _emotion: int = Constants.EMOTION_CONTENTMENT
var emotion_intensity: float = 0.5
var memory: Array = []
var last_danger_pos: Vector2 = Vector2.ZERO

# === DEEP LIFE SIMULATION (Creatures-like core) ===
enum Personality { CURIOUS, FEARFUL, AGGRESSIVE, SOCIAL, MATERNAL, LAZY, EXPLORER }
var personality: int = Personality.CURIOUS
var personality_modifiers := {"speed": 1.0, "sight": 1.0, "social": 0.5, "fear_resist": 1.0}

# === MENTAL DISORDERS (Psychological conditions) ===
enum MentalDisorder { NONE, ANXIETY, DEPRESSION, PTSD, AGGRESSION_DISORDER }
var mental_disorder: int = MentalDisorder.NONE
var disorder_severity: float = 0.0  # 0.0 - 1.0

var will_to_live: float = 1.0          # desire to survive (drops with trauma)
var trauma_level: float = 0.0
var known_friends: Array = []          # creature references
var known_enemies: Array = []
var known_parents: Array = []
var known_children: Array = []
var safe_zones: Array = []               # positions where this creature felt safe
var trauma_events: Array = []            # {type, time, intensity, position}

# === ADVANCED SOCIAL MEMORY (Negative/Positive Experience + Fear from specific objects) ===
var relationships: Dictionary = {}       # creature -> {trust: float, fear: float, anger: float, last_interaction: float}

# === ADVANCED AI (Goals + Planning + Territory) ===
var current_goals: Array = []            # {type, priority, target, progress}
var territory_center: Vector2 = Vector2.ZERO
var territory_radius: float = 120.0

# === LEARNING SYSTEM (Experience Memory) ===
var experience_memory: Array = []        # {action, success, time, reward}
var episodic_memory: Array = []       # episodic memory records
var neurochemicals: Dictionary = {}    # neurochemical state (init in _ready)

# === ADVANCED BEHAVIORS (C + D) ===
var food_stashes: Array = []             # positions where creature stores food
var healing_plants_used: int = 0
var has_nest: bool = false
var nest_position: Vector2 = Vector2.ZERO

# === PROCEDURAL MORPHOLOGY (Body Evolution from genes) ===
var horn_length: float = 0.0
var ear_size: float = 1.0
var tail_length: float = 0.0
var fur_density: float = 1.0
var eye_glow: float = 0.0

# === SURVIVAL, STRESS & DISEASE SYSTEM VARIABLES ===
var wounds: Array = []                 # List of active wounds: {zone: int, type: int, severity: float, condition: int}
var stress_level: float = 0.0          # Current stress (0.0 to 1.0)
var viral_infection: float = 0.0       # Progress of viral disease (0.0 to 1.0)
var parasitical_infection: float = 0.0  # Progress of parasites (0.0 to 1.0)
var active_mental_break: int = Constants.BREAK_NONE
var break_duration: float = 0.0        # Remaining breakdown time in game hours
var cough_cooldown: float = 0.0        # Timer between coughs / virus spreading

signal creature_selected(creature)
signal wants_reproduce(parent1, parent2)
signal interaction_happened(initiator, target, action, result)  # new: for world feedback

# ── Interaction system ──────────────────────────────────────────────────────
var hug_cooldown: float = 0.0          # seconds until next hug
var hit_cooldown: float = 0.0          # seconds between attacks
var mating_request_cooldown: float = 0.0
var _interaction_flash_timer: float = 0.0   # visual flash after interaction
var _interaction_flash_color: Color = Color.WHITE

# ─────────────────────────────────────────────────────────────────────────────
func _ready() -> void:
	color_variant = randi() % 4
	if genome == null:
		genome = Genome.new()
	add_to_group("creatures")
	_pick_wander_target()
	_blink_timer = randf_range(2.0, 5.0)
	_load_creature_sprite()
	if genome:
		base_scale = lerp(0.7, 1.3, genome.get_trait_value(Constants.TRAIT_SIZE) if genome.has_method("get_trait_value") else 0.5)
		scale = Vector2(base_scale, base_scale)
	
	# === Generate Personality Archetype (deep life simulation) ===
	_generate_personality()
	_generate_morphology()
	CreatureNeurochemistry.init_neurochemicals(self)

# === GENETIC MEMORY CAPACITY ===
func get_max_memory_size() -> int:
	var intel = genome.get_trait_value(Constants.TRAIT_INTELLIGENCE) if genome else 1.0
	return int(round(60.0 * intel))

func get_max_experience_memory_size() -> int:
	var intel = genome.get_trait_value(Constants.TRAIT_INTELLIGENCE) if genome else 1.0
	return int(round(40.0 + 40.0 * intel))

# === DEEP SOCIAL + TRAUMA SYSTEM ===
func record_social_bond(other: Node2D, bond_type: String, strength: float = 1.0) -> void:
	if not is_instance_valid(other):
		return
	match bond_type:
		"friend":
			if other not in known_friends:
				known_friends.append(other)
		"enemy":
			if other not in known_enemies:
				known_enemies.append(other)
		"parent":
			if other not in known_parents:
				known_parents.append(other)
		"child":
			if other not in known_children:
				known_children.append(other)
	
	# Record positive memory
	memory.append({
		"type": Constants.MEMORY_TYPE_ENTITY,
		"target": other,
		"bond": bond_type,
		"strength": strength,
		"time": age_hours
	})

func record_trauma(trauma_type: String, intensity: float, pos: Vector2 = Vector2.ZERO) -> void:
	trauma_level = min(1.0, trauma_level + intensity * 0.15)
	trauma_events.append({
		"type": trauma_type,
		"time": age_hours,
		"intensity": intensity,
		"pos": pos
	})
	will_to_live = max(0.2, will_to_live - intensity * 0.1)
	
	# Add to memory
	memory.append({
		"type": Constants.MEMORY_TYPE_EXPERIENCE,
		"event": trauma_type,
		"intensity": intensity,
		"pos": pos,
		"time": age_hours
	})
	if memory.size() > get_max_memory_size():
		memory.pop_front()

func update_relationship(other: Node2D, trust_change: float = 0.0, fear_change: float = 0.0, anger_change: float = 0.0) -> void:
	if not is_instance_valid(other):
		return
	
	if not relationships.has(other):
		relationships[other] = {"trust": 0.0, "fear": 0.0, "anger": 0.0, "last_interaction": age_hours}
	
	var rel = relationships[other]
	rel.trust = clamp(rel.trust + trust_change, -1.0, 1.0)
	rel.fear = clamp(rel.fear + fear_change, 0.0, 1.0)
	rel.anger = clamp(rel.anger + anger_change, 0.0, 1.0)
	rel.last_interaction = age_hours
	
	# If fear or anger is high → add to known_enemies
	if rel.fear > 0.6 or rel.anger > 0.6:
		if other not in known_enemies:
			known_enemies.append(other)
	
	# If trust is high → add to friends
	if rel.trust > 0.6:
		if other not in known_friends:
			known_friends.append(other)

func _generate_personality() -> void:
	# Weighted random based on genome traits (if available)
	var roll = randf()
	if genome:
		var intel = genome.get_trait_value(Constants.TRAIT_INTELLIGENCE) if genome.has_method("get_trait_value") else 0.5
		var social = genome.get_trait_value(Constants.TRAIT_SOCIAL) if genome.has_method("get_trait_value") else 0.5
		var speed_val = genome.get_trait_value(Constants.TRAIT_SPEED) if genome.has_method("get_trait_value") else 1.0
		
		if intel > 0.7 and social > 0.6:
			personality = Personality.SOCIAL
		elif intel > 0.75:
			personality = Personality.CURIOUS
		elif social > 0.7:
			personality = Personality.MATERNAL
		elif speed_val < 0.75:
			personality = Personality.LAZY
		elif roll < 0.15:
			personality = Personality.AGGRESSIVE
		elif roll < 0.35:
			personality = Personality.FEARFUL
		else:
			personality = Personality.EXPLORER
	else:
		personality = [Personality.CURIOUS, Personality.FEARFUL, Personality.SOCIAL, Personality.EXPLORER, Personality.LAZY][randi() % 5]
	
	# Apply modifiers
	match personality:
		Personality.CURIOUS:
			personality_modifiers = {"speed": 1.1, "sight": 1.3, "social": 0.4, "fear_resist": 0.9}
		Personality.FEARFUL:
			personality_modifiers = {"speed": 0.85, "sight": 1.5, "social": 0.3, "fear_resist": 0.4}
		Personality.AGGRESSIVE:
			personality_modifiers = {"speed": 1.2, "sight": 0.9, "social": 0.2, "fear_resist": 1.4}
		Personality.SOCIAL:
			personality_modifiers = {"speed": 1.0, "sight": 1.1, "social": 1.0, "fear_resist": 1.1}
		Personality.MATERNAL:
			personality_modifiers = {"speed": 0.9, "sight": 1.2, "social": 0.9, "fear_resist": 1.3}
		Personality.EXPLORER:
			personality_modifiers = {"speed": 1.25, "sight": 1.4, "social": 0.5, "fear_resist": 0.85}
		Personality.LAZY:
			personality_modifiers = {"speed": 0.75, "sight": 0.9, "social": 0.6, "fear_resist": 1.1}
		_:
			personality_modifiers = {"speed": 1.0, "sight": 1.0, "social": 0.5, "fear_resist": 1.0}
	
	will_to_live = randf_range(0.85, 1.0)

func _generate_morphology() -> void:
	if not genome or not genome.has_method("get_trait_value"):
		return
	
	var str_val = genome.get_trait_value(Constants.TRAIT_STRENGTH)
	var size_val = genome.get_trait_value(Constants.TRAIT_SIZE)
	var intel_val = genome.get_trait_value(Constants.TRAIT_INTELLIGENCE)
	
	# Horns from strength + size
	horn_length = max(0.0, (str_val - 0.6) * 18.0 + (size_val - 0.5) * 8.0)
	
	# Ears from intelligence + curiosity
	ear_size = 0.8 + intel_val * 0.6
	
	# Tail length
	tail_length = 8.0 + size_val * 12.0
	
	# Fur density (warmth / protection)
	fur_density = 0.7 + str_val * 0.5
	
	# Eye glow from intelligence
	eye_glow = max(0.0, (intel_val - 0.7) * 0.8)

func record_experience(action: String, success: bool, reward: float) -> void:
	# Legacy bridge: maps old action names -> neurochemistry + episodic memory.
	experience_memory.append({
		"action": action,
		"success": success,
		"time": age_hours,
		"reward": reward
	})
	if experience_memory.size() > get_max_experience_memory_size():
		experience_memory.pop_front()

	var event_map := {
		"seek_food":       ["food_eaten",   1.0,  1.0],
		"seek_water":      ["water_drunk",  1.0,  1.0],
		"reproduce":       ["mate_found",   1.0,  1.0],
		"mating_accepted": ["mate_found",   1.0,  1.0],
		"mating_request":  ["mate_found",   0.8,  1.0],
		"hit_enemy":       ["attacked",     0.6, -0.5],
		"hit_other":       ["attacked",     0.5, -0.4],
		"received_hit":    ["attacked",     0.8, -1.0],
		"give_hug":        ["social_touch", 0.4,  1.0],
		"receive_hug":     ["social_touch", 0.5,  1.0],
		"help_friend":     ["social_touch", 0.4,  1.0],
	}

	if event_map.has(action):
		var mapping = event_map[action]
		var ev_type: String   = mapping[0]
		var ev_mag: float     = mapping[1] * abs(reward)
		var ev_valence: float = mapping[2] * (1.0 if success else -1.0)
		CreatureNeurochemistry.apply_event(self, ev_type, ev_mag)
		CreatureEpisodicMemory.record_memory(self, ev_type, global_position, ev_mag, ev_valence)
	else:
		var valence: float = float(sign(reward)) if reward != 0.0 else (1.0 if success else -1.0)
		CreatureEpisodicMemory.record_memory(
			self, action, global_position, clamp(abs(reward), 0.0, 1.0), valence
		)


func _load_creature_sprite() -> void:
	var stage = stage_names[clamp(life_stage, 0, 3)]
	var variant = variant_names[clamp(color_variant, 0, 3)]
	var path = "res://assets/sprites/creatures/%s_%s.png" % [stage, variant]
	if ResourceLoader.exists(path):
		current_sprite = load(path)
	else:
		current_sprite = null  # fallback to procedural
	queue_redraw()

func setup(g: Genome, variant: int = -1) -> void:
	genome = g
	if variant >= 0:
		color_variant = variant % 4
	queue_redraw()

# ─────────────────────────────────────────────────────────────────────────────
func _process(delta: float) -> void:
	if GameManager.is_paused:
		return

	var gd = delta * GameManager.time_scale

	# ── Age & Life Stage ──────────────────────────────────────────────────
	age_hours += gd / Constants.GAME_HOUR_SECONDS
	_update_life_stage()
	if life_stage == Constants.LIFE_STAGE_DECEASED:
		# Unregister and remove from scene on the first DECEASED frame
		if not get_meta("death_processed", false):
			set_meta("death_processed", true)
			_trigger_death_reactions()
			GameManager.unregister_creature(self)
			queue_free()
		return

	var hour_delta = gd / Constants.GAME_HOUR_SECONDS

	# ── Physiology (wounds, diseases, stress, needs, health damage) ───────
	# Neurochemistry tick: cortisol feeds into physiology stress
	CreatureNeurochemistry.tick(self, hour_delta)
	# Spatial hash update for O(1) proximity queries
	GameManager.update_spatial(self)

	# REFACTOR: extracted to CreaturePhysiology for testability.
	# All state vars (hunger, wounds, viral_infection…) live on this node;
	# CreaturePhysiology.tick() reads and writes them in place.
	CreaturePhysiology.tick(self, hour_delta)

	# CreaturePhysiology sets health to 0 on lethal damage; check here.
	if health <= 0.0:
		life_stage = Constants.LIFE_STAGE_DECEASED
		if not get_meta("death_processed", false):
			set_meta("death_processed", true)
			_trigger_death_reactions()
			GameManager.unregister_creature(self)
			queue_free()
		return

	# ── AI Decision ───────────────────────────────────────────────────────
	# REFACTOR: scoring + execution extracted to CreatureAI.
	CreatureAI.update(self, delta)

	# ── Animation ─────────────────────────────────────────────────────────
	_blink_timer -= delta
	if _blink_timer <= 0:
		_blink_open = !_blink_open
		_blink_timer = 0.12 if !_blink_open else randf_range(2.0, 6.0)

	_bob_phase += delta * (2.0 if ai_state == AIState.WANDER else 3.5)
	_update_emotion()
	_eat_anim = max(0.0, _eat_anim - delta)
	
	# Simple memory recording (Phase 2)
	if randf() < 0.02 and is_instance_valid(target_food):
		memory.append({
			"type": Constants.MEMORY_TYPE_LOCATION,
			"pos": target_food.global_position,
			"value": "food",
			"time": age_hours
		})
	if memory.size() > get_max_memory_size():
		memory.pop_front()
	
	# Record safe zones when feeling good (long-term habits)
	if _emotion == Constants.EMOTION_CONTENTMENT and emotion_intensity > 0.6 and randf() < 0.008:
		safe_zones.append(global_position)
		if safe_zones.size() > 5:
			safe_zones.pop_front()
	
	# BUG FIX: was 0.5% chance per frame → dead refs piled up for hours.
	# Now 2% so the average creature cleans up every ~3 real seconds at 60fps.
	if randf() < 0.02:
		_cleanup_dead_references()
	
	queue_redraw()

func _trigger_death_reactions() -> void:
	# Clean up our own dead refs first so we don't notify invalid nodes
	_cleanup_dead_references()
	for friend in known_friends:
		if is_instance_valid(friend) and friend.has_method("record_trauma"):
			friend.record_trauma("friend_died", 0.6, global_position)
			friend._emotion = Constants.EMOTION_PAIN
			friend.emotion_intensity = 0.85
	
	for child in known_children:
		if is_instance_valid(child) and child.has_method("record_trauma"):
			child.record_trauma("parent_died", 0.9, global_position)
			child._emotion = Constants.EMOTION_PAIN
			child.emotion_intensity = 0.95
			child.will_to_live = max(0.15, child.will_to_live - 0.3)
	
	# If this creature had a strong will to live, it "fights" death a bit
	if will_to_live > 0.7:
		pass

# ─────────────────────────────────────────────────────────────────────────────
func _update_ai(delta: float) -> void:
	var vp = get_viewport_rect().size
	var margin = 20.0
	var sight = 80.0
	if genome:
		sight = 80.0 * genome.get_trait_value(Constants.TRAIT_SIGHT_RANGE)

	# ── UTILITY AI + Multi-generational planning (Phase 3-4) ─────────────
	if life_stage == Constants.LIFE_STAGE_EMBRYO:
		return

	var old_state = ai_state
	var scores := {
		AIState.WANDER: 12.0,
		AIState.SEEK_FOOD: 0.0,
		AIState.SEEK_WATER: 0.0,
		AIState.REST: 0.0,
		AIState.SEEK_ENEMY: 0.0,
		AIState.REPRODUCE: 0.0
	}

	# Needs scoring (strong urgency when starving)
	var hunger_urgency = (100.0 - hunger) * (1.0 if hunger > 30.0 else 2.5)  # desperate when very hungry
	var thirst_urgency = (100.0 - thirst) * (1.0 if thirst > 25.0 else 3.0)  # even more desperate from thirst
	
	scores[AIState.SEEK_FOOD] = hunger_urgency * 0.9
	scores[AIState.SEEK_WATER] = thirst_urgency * 0.95
	scores[AIState.REST] = (100.0 - fatigue) * 0.55

	# Emotion & Personality influence
	if _emotion == Constants.EMOTION_FEAR:
		scores[AIState.WANDER] += 45.0 * emotion_intensity * personality_modifiers.get("fear_resist", 1.0)
	if _emotion == Constants.EMOTION_PAIN:
		scores[AIState.REST] += 40.0 * emotion_intensity
	if _emotion == Constants.EMOTION_EXCITEMENT:
		scores[AIState.REPRODUCE] += 28.0

	# Personality bonuses
	match personality:
		Personality.FEARFUL:
			scores[AIState.WANDER] += 30.0
		Personality.AGGRESSIVE:
			scores[AIState.SEEK_FOOD] += 18.0
		Personality.LAZY:
			scores[AIState.REST] += 25.0
		Personality.CURIOUS, Personality.EXPLORER:
			scores[AIState.WANDER] += 22.0
		Personality.SOCIAL, Personality.MATERNAL:
			scores[AIState.WANDER] += 8.0

	# Long-term habits (safe zones)
	if (trauma_level > 0.3 or emotion_intensity > 0.5) and safe_zones.size() > 0:
		scores[AIState.WANDER] += 20.0

	# === VENGEANCE & AGGRESSION: drive SEEK_ENEMY instead of aimless wandering ===
	# Old code added to WANDER — creatures just wandered faster near enemies,
	# never actually pursuing them. Now AGGRESSIVE creatures with high anger
	# score SEEK_ENEMY which routes to a dedicated pursuit + attack execute.
	if known_enemies.size() > 0 and active_mental_break == Constants.BREAK_NONE:
		# Find the enemy we're most angry at
		var hottest_enemy: Node2D = null
		var hottest_anger: float = 0.0
		for e in known_enemies:
			if not is_instance_valid(e) or e.life_stage == Constants.LIFE_STAGE_DECEASED:
				continue
			var anger = relationships.get(e, {}).get("anger", 0.0)
			if anger > hottest_anger:
				hottest_anger = anger
				hottest_enemy = e

		if hottest_enemy != null:
			var pursue_score = 0.0
			# AGGRESSIVE creatures pursue enemies above anger threshold 0.5
			if personality == Personality.AGGRESSIVE and hottest_anger > 0.5:
				pursue_score = hottest_anger * 90.0
			# Others only retaliate if severely traumatised and very angry (>0.75)
			elif trauma_level > 0.5 and hottest_anger > 0.75:
				pursue_score = hottest_anger * 45.0
			# Healthy needs don't block revenge, but survival still wins
			scores[AIState.SEEK_ENEMY] = pursue_score
			# Keep a small wander bump for non-aggressive fear of enemies
			if pursue_score < 10.0:
				scores[AIState.WANDER] += 20.0 * trauma_level

	# Use healing plants when injured (advanced behavior C)
	if trauma_level > 0.4 or health < 50.0:
		scores[AIState.WANDER] += 15.0  # actively search for healing herbs

	# Alliances (friends of friends = allies)
	var ally_bonus = 0.0
	for friend in known_friends:
		if is_instance_valid(friend) and friend.has_method("known_friends"):
			for f2 in friend.known_friends:
				if is_instance_valid(f2) and f2 != self:
					ally_bonus += 4.0
	scores[AIState.WANDER] += min(ally_bonus, 25.0)

	# DEPRECATED: old learned_preferences loop removed.
	# Scoring now uses neurochemicals + episodic memory via CreatureAI.

	# Reproduction drive
	# COMPLEX REPRODUCTION SYSTEM
	if life_stage == Constants.LIFE_STAGE_ADULT and repro_drive > 65.0 and repro_cooldown <= 0.0 and health > 45.0:
		var can_reproduce = true
		if trauma_level > 0.5 or _emotion == Constants.EMOTION_FEAR or _emotion == Constants.EMOTION_PAIN:
			can_reproduce = false
		if health < 55.0:
			can_reproduce = false
		
		if can_reproduce:
			scores[AIState.REPRODUCE] = max(scores[AIState.REPRODUCE], 55.0)
		else:
			if randf() < 0.3:
				record_experience("reproduce", false, -0.4)

	# ========================================================================
	# --- MENTAL BREAKS & ILLNESS INTEGRATION WITH UTILITY AI ---
	# ========================================================================
	if active_mental_break == Constants.BREAK_BERSERK:
		# Berserkers care only about violence, ignore physical needs
		for s in scores:
			scores[s] = -100.0
		scores[AIState.WANDER] = 100.0
	elif active_mental_break == Constants.BREAK_CATATONIC:
		# Catatonics are completely unconscious, force REST
		for s in scores:
			scores[s] = -100.0
		scores[AIState.REST] = 100.0
	else:
		if active_mental_break == Constants.BREAK_DEPRESSIVE:
			# Depressed creatures refuse to eat or drink (utility scaled by 0.05)
			scores[AIState.SEEK_FOOD] *= 0.05
			scores[AIState.SEEK_WATER] *= 0.05
		
		# Sickness and heavy injuries encourage resting to heal
		var has_sepsis = false
		for w in wounds:
			if w.condition == Constants.WOUND_STATE_SEPTIC:
				has_sepsis = true
				break
		if has_sepsis or viral_infection > 0.35 or health < 45.0:
			scores[AIState.REST] += 75.0

	# Choose best
	var best_state = AIState.WANDER
	var best_score = -999.0
	for state in scores:
		if scores[state] > best_score:
			best_score = scores[state]
			best_state = state

	ai_state = best_state

	if old_state != ai_state:
		target_food = null
		target_mate = null
		target_enemy = null

	# ── Execute State ─────────────────────────────────────────────────────
	match ai_state:
		AIState.WANDER:
			_execute_wander()
		AIState.SEEK_FOOD:
			_execute_seek_food(sight)
		AIState.SEEK_WATER:
			_execute_seek_water()
		AIState.REST:
			_execute_rest()
		AIState.SEEK_ENEMY:
			_execute_seek_enemy()
		AIState.REPRODUCE:
			_execute_reproduce(sight)

	# ── Move ──────────────────────────────────────────────────────────────
	# BUG FIX: BASE_SPEED(100) * 0.35 = 35 px/s — at that speed a creature
	# crossing the ~1000px world takes 28s, but food rots and needs drop fast.
	# Raised to 0.60 so creatures can actually reach targets in time.
	var speed = Constants.BASE_SPEED * 0.60
	if genome:
		speed *= genome.get_trait_value(Constants.TRAIT_SPEED)

	# --- FRACTURED / SEVERE LIMB WOUNDS PENALTY ---
	var speed_penalty = 1.0
	for w in wounds:
		if w.zone in [Constants.ZONE_FRONT_LEFT, Constants.ZONE_FRONT_RIGHT, Constants.ZONE_BACK_LEFT, Constants.ZONE_BACK_RIGHT]:
			var mult = 0.35 if w.condition == Constants.WOUND_STATE_FRACTURED else 0.7
			speed_penalty = min(speed_penalty, lerp(1.0, mult, w.severity))
	speed *= speed_penalty

	# --- MENTAL BREAK SPEED ADJUSTMENTS ---
	if active_mental_break == Constants.BREAK_CATATONIC:
		speed = 0.0
	elif active_mental_break == Constants.BREAK_DEPRESSIVE:
		speed *= 0.5
	elif active_mental_break == Constants.BREAK_PANIC:
		speed *= 1.6
	elif active_mental_break == Constants.BREAK_BERSERK:
		speed *= 1.4
	if ai_state == AIState.SEEK_FOOD or ai_state == AIState.SEEK_WATER:
		# BUG FIX: Was 1.4x — barely noticeable. Now 1.8x so urgency is visible.
		# Extra boost when critically low so creatures desperately sprint.
		var urgency = 1.8
		if hunger < 25.0 or thirst < 25.0:
			urgency = 2.2
		speed *= urgency
	if ai_state == AIState.REST:
		speed = 0.0
	if life_stage == Constants.LIFE_STAGE_EMBRYO:
		speed = 0.0
	if life_stage == Constants.LIFE_STAGE_ELDER:
		speed *= 0.65

	if ai_state != AIState.REST:
		position += move_dir * speed * get_process_delta_time()
		if move_dir.x != 0:
			facing_right = move_dir.x > 0
		
		# === SIDE-VIEW GROUND SNAPPING (visual immersion - creatures walk on ground) ===
		var ground_y = get_viewport_rect().size.y * 0.72
		if position.y > ground_y - 5:
			position.y = ground_y - 8 + sin(_bob_phase) * 1.5
		if position.y < ground_y - 55:
			position.y = ground_y - 55  # limit flight

	# Bounce off edges
	if position.x < margin or position.x > vp.x - margin:
		move_dir.x *= -1
		position.x = clamp(position.x, margin, vp.x - margin)
	if position.y < margin or position.y > vp.y - margin:
		move_dir.y *= -1
		position.y = clamp(position.y, margin, vp.y - margin)

func _execute_wander() -> void:
	if active_mental_break == Constants.BREAK_BERSERK:
		# Berserk behavior: hunt and attack anyone nearby!
		var target: Node2D = null
		var min_d = 999999.0
		for c in get_tree().get_nodes_in_group("creatures"):
			if c != self and is_instance_valid(c) and c.life_stage != Constants.LIFE_STAGE_DECEASED:
				var d = global_position.distance_squared_to(c.global_position)
				if d < min_d:
					min_d = d
					target = c
		
		if target:
			var dir = (target.global_position - global_position)
			var dist = dir.length()
			if dist < 28.0:
				# Attack!
				if randf() < 0.25: # Attack once in a few frames
					target.receive_hit(self, 16.0)
					_emotion = Constants.EMOTION_EXCITEMENT
					emotion_intensity = 0.9
			else:
				move_dir = dir.normalized()
			return

	move_timer -= get_process_delta_time()
	if move_timer <= 0:
		_pick_wander_target()

	# Try social interactions while wandering (hugs for social types, etc.)
	_try_social_interaction()

func _execute_seek_enemy() -> void:
	# Refresh target: pick the enemy we're most angry at that's still alive
	if not is_instance_valid(target_enemy) or target_enemy.life_stage == Constants.LIFE_STAGE_DECEASED:
		target_enemy = null
		var hottest_anger: float = 0.0
		for e in known_enemies:
			if not is_instance_valid(e) or e.life_stage == Constants.LIFE_STAGE_DECEASED:
				continue
			var anger = relationships.get(e, {}).get("anger", 0.0)
			if anger > hottest_anger:
				hottest_anger = anger
				target_enemy = e

	if not is_instance_valid(target_enemy):
		# No valid enemy left — drop back to wandering
		ai_state = AIState.WANDER
		_execute_wander()
		return

	var dir = (target_enemy.global_position - global_position)
	var dist = dir.length()

	if dist < 30.0:
		# Close enough — strike if cooldown allows
		if hit_cooldown <= 0.0:
			var dmg = Constants.BASE_STRENGTH * (genome.get_trait_value(Constants.TRAIT_STRENGTH) if genome else 1.0)
			target_enemy.receive_hit(self, dmg)
			hit_cooldown = randf_range(1.5, 3.5)   # seconds between strikes
			_emotion = Constants.EMOTION_ANGER
			emotion_intensity = 0.9
			_interaction_flash_timer = 0.4
			_interaction_flash_color = Color(1.0, 0.3, 0.0)
			record_experience("hit_enemy", true, 0.6)
			# Partially satisfy the anger after a successful hit
			if relationships.has(target_enemy):
				relationships[target_enemy]["anger"] = max(0.0, relationships[target_enemy]["anger"] - 0.15)
	else:
		move_dir = dir.normalized()

func _try_social_interaction() -> void:
	# Called every wander tick. Initiates hugs or targeted hits based on
	# personality and nearby creatures.
	# SOCIAL trait: higher value → wider social range and shorter hug cooldown.
	var social_trait = genome.get_trait_value(Constants.TRAIT_SOCIAL) if genome else 1.0
	var social_range = 45.0 * social_trait  # high-social creatures initiate from farther

	# ── GROUP FOLLOW: social creatures drift toward nearest friend while wandering ──
	# This makes packs stay loosely together without explicit flocking state.
	if social_trait > 1.0 and known_friends.size() > 0 and move_timer <= 0.5:
		var nearest_friend: Node2D = null
		var nearest_d := 9999.0
		for f in known_friends:
			if is_instance_valid(f) and f.life_stage != Constants.LIFE_STAGE_DECEASED:
				var d = global_position.distance_to(f.global_position)
				if d < nearest_d:
					nearest_d = d
					nearest_friend = f
		if nearest_friend != null and nearest_d > 80.0 and nearest_d < 250.0:
			# Nudge wander direction toward friend (partial, not full pursuit)
			var to_friend = (nearest_friend.global_position - global_position).normalized()
			move_dir = (move_dir + to_friend * (social_trait - 1.0)).normalized()

	# ── HUG: SOCIAL / MATERNAL creatures embrace nearby friends ──────────
	if hug_cooldown <= 0.0 and personality in [Personality.SOCIAL, Personality.MATERNAL]:
		for c in GameManager.creatures:
			if c == self or not is_instance_valid(c):
				continue
			if c.life_stage == Constants.LIFE_STAGE_DECEASED:
				continue
			if global_position.distance_to(c.global_position) > social_range:
				continue
			if c not in known_friends:
				continue
			# Only hug when we're emotionally able
			if _emotion in [Constants.EMOTION_PAIN, Constants.EMOTION_ANGER]:
				break
			# SOCIAL trait shortens cooldown (high-social = hugs more often)
			hug_cooldown = randf_range(20.0, 45.0) / social_trait
			c.receive_hug(self)
			record_experience("give_hug", true, 0.5)
			return

	# ── HIT: AGGRESSIVE creatures strike enemies on sight ────────────────
	if hit_cooldown <= 0.0 and personality == Personality.AGGRESSIVE:
		for c in GameManager.creatures:
			if c == self or not is_instance_valid(c):
				continue
			if c.life_stage == Constants.LIFE_STAGE_DECEASED:
				continue
			if global_position.distance_to(c.global_position) > social_range * 0.7:
				continue
			if c not in known_enemies:
				continue
			var anger = relationships.get(c, {}).get("anger", 0.0)
			if anger < 0.4:
				continue
			var dmg = Constants.BASE_STRENGTH * (genome.get_trait_value(Constants.TRAIT_STRENGTH) if genome else 1.0)
			c.receive_hit(self, dmg)
			hit_cooldown = randf_range(2.0, 4.0)
			_emotion = Constants.EMOTION_ANGER
			emotion_intensity = 0.8
			record_experience("hit_enemy", true, 0.4)
			return

func _execute_flee() -> void:
	var fv: Vector2 = get_meta("_flee_vector", Vector2.ZERO)
	if fv.length_squared() > 0.01:
		move_dir = fv.normalized()
	else:
		_pick_wander_target()
	_emotion = Constants.EMOTION_FEAR
	emotion_intensity = min(1.0, neurochemicals.get("adrenaline", 0.5))
	# Chemical relief when threat is gone
	var still_threatened := false
	for e in known_enemies:
		if is_instance_valid(e) and e.life_stage != Constants.LIFE_STAGE_DECEASED:
			if global_position.distance_to(e.global_position) < 150.0:
				still_threatened = true
				break
	if not still_threatened and neurochemicals.get("adrenaline", 1.0) > 0.6:
		CreatureNeurochemistry.apply_event(self, "successfully_fled", 1.0)
		CreatureEpisodicMemory.record_memory(self, "fled_from_danger", global_position, 0.6, -0.3)


func _execute_seek_food(sight: float) -> void:
	# Find nearest food in sight range
	if not is_instance_valid(target_food):
		target_food = _find_nearest_food(sight)

	if is_instance_valid(target_food):
		var dir = (target_food.global_position - global_position)
		var dist = dir.length()
		if dist < 16.0:
			# Eat it - make sure it disappears
			# BUG FIX: food_value is stored as meta, not as a property.
			# .get("food_value") always returned null → creatures always got 30.0
			# and the learning reward was measured AFTER hunger was already topped up.
			var prev_hunger = hunger   # capture BEFORE eating for correct reward
			var val = 30.0
			if target_food.has_meta("food_value"):
				val = target_food.get_meta("food_value")
			var ftype = ""
			if target_food.has_meta("food_type"):
				ftype = target_food.get_meta("food_type")

			# BUG FIX: water_drop items had food_value=0.0 and were added to hunger*val
			# and thirst*val*0.3 → both were 0. They now correctly hydrate the creature.
			if ftype == "water_drop":
				thirst = min(100.0, thirst + 40.0)
			else:
				hunger = min(100.0, hunger + val)
				thirst = min(100.0, thirst + val * 0.3)
			_eat_anim = 0.4
			
			# Visual feedback: other creatures can see someone is eating
			if target_food.has_method("set_modulate"):
				target_food.set_modulate(Color(1, 0.6, 0.4, 0.6))
			
			# Remember where food was found
			memory.append({
				"type": Constants.MEMORY_TYPE_LOCATION,
				"pos": target_food.global_position,
				"value": "food",
				"time": age_hours
			})
			
			target_food.queue_free()
			target_food = null
			_pick_wander_target()
			
			# Learning: reward based on how hungry we WERE (not current value)
			# BUG FIX: old code checked hunger AFTER eating → always > 25 → reward=0.8
			# Now uses prev_hunger so desperate finds correctly yield reward=1.6
			var reward = 0.8
			if prev_hunger < 25.0:
				reward = 1.6   # strong memory: found food while starving
			elif prev_hunger < 50.0:
				reward = 1.1   # moderate bonus for eating when quite hungry
			elif prev_hunger >= 80.0:
				reward = -0.5  # penalize eating when full
			record_experience("seek_food", true, reward)
			# Neurochemistry: food reward spike + episodic location memory
			CreatureNeurochemistry.apply_event(self, "food_eaten", clamp(reward * 0.5, 0.2, 1.0))
			CreatureEpisodicMemory.record_memory(self, "food_found", global_position, clamp(reward * 0.5, 0.2, 1.0), 1.0)
		else:
			move_dir = dir.normalized()
	else:
		_execute_wander()

func _execute_seek_water() -> void:
	# Drink from permanent pond on the ground
	var world = get_tree().get_first_node_in_group("world")
	if world and world.has_method("get_nearest_water_pos"):
		var wp = world.get_nearest_water_pos(global_position)
		var dir = (wp - global_position)
		var dist = dir.length()
		
		# FIX: Capture thirst BEFORE drinking so desperate-learning reward fires correctly.
		# Old code checked `if thirst < 20.0` INSIDE `if thirst >= 92.0` block —
		# those two conditions are mutually exclusive → desperate reward NEVER triggered.
		var prev_thirst = thirst
		
		# Always remember water location when near it (was 30% chance → missed too often)
		if dist < 35.0:
			memory.append({
				"type": Constants.MEMORY_TYPE_LOCATION,
				"pos": wp,
				"value": "water",
				"time": age_hours
			})
		
		if dist < 35.0:  # close enough to drink
			# BUG FIX: was using get_process_delta_time() which ignores time_scale,
			# making parasite risk independent of simulation speed. Also the check
			# `parasitical_infection <= 0.0` didn't prevent re-infection mid-drink
			# because thirst fills slowly over multiple frames — parasites could
			# stack before the creature walked away. Now: one roll per drink session,
			# gated by a per-session flag cleared when the creature leaves water.
			var hour_delta = get_process_delta_time() * GameManager.time_scale / Constants.GAME_HOUR_SECONDS
			if parasitical_infection <= 0.0 and not get_meta("parasite_checked", false):
				set_meta("parasite_checked", true)
				var tox_res = genome.get_trait_value(Constants.TRAIT_TOXIN_RESISTANCE) if genome else 1.0
				if randf() < 0.25 and randf() > tox_res * 0.75:
					parasitical_infection = 0.15
					print("Hoshi #%d contracted gut parasites." % (get_meta("creature_id") if has_meta("creature_id") else 0))

			thirst = min(100.0, thirst + 75.0 * get_process_delta_time())
			if thirst >= 92.0:
				# Reward based on how thirsty we WERE before drinking
				var water_reward = 0.8
				if prev_thirst < 20.0:
					water_reward = 1.6  # desperate learning
				elif prev_thirst < 40.0:
					water_reward = 1.1
				elif prev_thirst >= 80.0:
					water_reward = -0.5  # penalize drinking when not thirsty
				record_experience("seek_water", true, water_reward)
				# Neurochemistry: hydration relief
				CreatureNeurochemistry.apply_event(self, "water_drunk", 1.0)
				CreatureEpisodicMemory.record_memory(self, "water_found", global_position, 0.7, 1.0)
				drink_cooldown = randf_range(25.0, 50.0)
				# BUG FIX: reset per-session parasite flag when leaving water
				set_meta("parasite_checked", false)
				ai_state = AIState.WANDER
				_pick_wander_target()
		else:
			# BUG FIX: also reset flag when walking away from water mid-drink
			set_meta("parasite_checked", false)
			move_dir = dir.normalized()
	else:
		_execute_wander()

func _execute_rest() -> void:
	move_dir = Vector2.ZERO

func _execute_reproduce(sight: float) -> void:
	if not is_instance_valid(target_mate):
		target_mate = _find_nearby_mate(sight)
	if is_instance_valid(target_mate):
		var dir = (target_mate.global_position - global_position)
		var dist = dir.length()
		if dist < 30.0:
			# Breed!
			if target_mate.has_method("receive_mating_request"):
				target_mate.receive_mating_request(self)
			else:
				# Fallback to asexual cloning if partner doesn't support requests
				repro_drive = 0.0
				repro_cooldown = Constants.BREEDING_COOLDOWN_HOURS * Constants.GAME_HOUR_SECONDS
				wants_reproduce.emit(self, null)
			target_mate = null
			_pick_wander_target()
		else:
			move_dir = dir.normalized()
	else:
		ai_state = AIState.WANDER
		_execute_wander()

# ═══════════════════════════════════════════════════════════════════════
# SOCIAL INTERACTIONS: hug / hit / mating request
# ═══════════════════════════════════════════════════════════════════════

# ── HUG ─────────────────────────────────────────────────────────────────────
func receive_hug(initiator) -> void:
	if not is_instance_valid(initiator):
		return
	if life_stage == Constants.LIFE_STAGE_DECEASED:
		return

	var accepted = false
	var rel_fear = 0.0
	if relationships.has(initiator):
		rel_fear = relationships[initiator].get("fear", 0.0)

	if _emotion == Constants.EMOTION_PAIN or _emotion == Constants.EMOTION_ANGER:
		accepted = false
	elif rel_fear > 0.5 or initiator in known_enemies:
		accepted = false
	elif personality == Personality.FEARFUL and initiator not in known_friends and randf() < 0.55:
		accepted = false
	else:
		accepted = true

	if accepted:
		health = min(100.0, health + 4.0)
		trauma_level = max(0.0, trauma_level - 0.08)
		will_to_live = min(1.0, will_to_live + 0.18)
		stress_level = max(0.0, stress_level - 0.30)
		_emotion = Constants.EMOTION_LOVE
		emotion_intensity = 0.85
		_interaction_flash_timer = 0.6
		_interaction_flash_color = Color(1.0, 0.6, 0.8)
		update_relationship(initiator, 0.15, -0.05, 0.0)
		if initiator not in known_friends and initiator not in known_enemies:
			record_social_bond(initiator, "friend", 0.5)
		record_experience("receive_hug", true, 0.7)
		# Neurochemistry: oxytocin from physical contact
		CreatureNeurochemistry.apply_event(self, "social_touch", 0.7)
		CreatureEpisodicMemory.record_memory(
			self, "social_touch",
			initiator.global_position if is_instance_valid(initiator) else global_position,
			0.7, 1.0
		)

		if is_instance_valid(initiator):
			initiator._emotion = Constants.EMOTION_LOVE
			initiator.emotion_intensity = 0.80
			initiator.health = min(100.0, initiator.health + 2.0)
			initiator.trauma_level = max(0.0, initiator.trauma_level - 0.05)
			initiator.will_to_live = min(1.0, initiator.will_to_live + 0.15)
			initiator.stress_level = max(0.0, initiator.stress_level - 0.25)
			initiator._interaction_flash_timer = 0.6
			initiator._interaction_flash_color = Color(1.0, 0.6, 0.8)
			initiator.update_relationship(self, 0.12, -0.04, 0.0)
			initiator.record_experience("give_hug", true, 0.65)

		interaction_happened.emit(initiator, self, "hug", "accepted")
	else:
		_emotion = Constants.EMOTION_EMBARRASSMENT if randf() < 0.5 else Constants.EMOTION_ANGER
		emotion_intensity = 0.7
		_interaction_flash_timer = 0.35
		_interaction_flash_color = Color(0.9, 0.9, 0.3)
		update_relationship(initiator, -0.05, 0.1, 0.05)
		record_experience("reject_hug", true, 0.1)

		if is_instance_valid(initiator):
			initiator._emotion = Constants.EMOTION_EMBARRASSMENT
			initiator.emotion_intensity = 0.75
			initiator.trauma_level = min(1.0, initiator.trauma_level + 0.04)
			initiator._interaction_flash_timer = 0.4
			initiator._interaction_flash_color = Color(0.8, 0.8, 0.2)
			initiator.update_relationship(self, -0.08, 0.05, 0.0)
			initiator.record_experience("give_hug", false, -0.3)

		interaction_happened.emit(initiator, self, "hug", "rejected")

# ── HIT ─────────────────────────────────────────────────────────────────────
func receive_hit(initiator, damage: float = 15.0) -> void:
	if not is_instance_valid(initiator) or life_stage == Constants.LIFE_STAGE_DECEASED:
		return

	var actual_dmg = damage
	if initiator.genome and initiator.genome.has_method("get_trait_value"):
		actual_dmg = damage * initiator.genome.get_trait_value(Constants.TRAIT_STRENGTH)

	health = max(0.0, health - actual_dmg)
	_emotion = Constants.EMOTION_PAIN if actual_dmg > 20 else Constants.EMOTION_ANGER
	emotion_intensity = min(1.0, 0.5 + actual_dmg / 50.0)
	_interaction_flash_timer = 0.5
	_interaction_flash_color = Color(1.0, 0.2, 0.2)

	# --- ANATOMICAL WOUND GENERATION ---
	var zones = [Constants.ZONE_HEAD, Constants.ZONE_TORSO, Constants.ZONE_FRONT_LEFT, 
				 Constants.ZONE_FRONT_RIGHT, Constants.ZONE_BACK_LEFT, Constants.ZONE_BACK_RIGHT, 
				 Constants.ZONE_TAIL]
	var zone = zones[randi() % zones.size()]
	
	# Determine damage type: Laceration (40%) vs Blunt (60%)
	var type = Constants.DAMAGE_TYPE_BLUNT
	if randf() < 0.40:
		type = Constants.DAMAGE_TYPE_LACERATION
	
	var severity = clamp(actual_dmg / 60.0, 0.1, 1.0)
	var cond = Constants.WOUND_STATE_NONE
	if type == Constants.DAMAGE_TYPE_LACERATION:
		cond = Constants.WOUND_STATE_BLEEDING
	elif type == Constants.DAMAGE_TYPE_BLUNT:
		if severity > 0.4 and zone in [Constants.ZONE_FRONT_LEFT, Constants.ZONE_FRONT_RIGHT, Constants.ZONE_BACK_LEFT, Constants.ZONE_BACK_RIGHT]:
			cond = Constants.WOUND_STATE_FRACTURED # Broken bone!
	
	var new_wound = {
		"zone": zone,
		"type": type,
		"severity": severity,
		"condition": cond
	}
	wounds.append(new_wound)
	
	# Head wounds double trauma and increase stress massively
	var head_stress = 0.0
	if zone == Constants.ZONE_HEAD:
		head_stress = severity * 0.35
		record_trauma("head_trauma", severity * 0.8, initiator.global_position)
	
	stress_level = min(1.0, stress_level + (actual_dmg / 80.0) + head_stress)

	record_trauma("was_hit", actual_dmg / 40.0, initiator.global_position)
	update_relationship(initiator, -0.25, 0.3, 0.35)
	if initiator not in known_enemies:
		known_enemies.append(initiator)

	var flee_dir = (global_position - initiator.global_position).normalized()
	move_dir = flee_dir
	ai_state = AIState.WANDER
	# Neurochemistry: adrenaline + endorphin (fight-or-flight + pain analgesia)
	CreatureNeurochemistry.apply_event(self, "attacked", clamp(actual_dmg / 30.0, 0.1, 1.0))
	CreatureNeurochemistry.apply_event(self, "wound_received", clamp(actual_dmg / 50.0, 0.1, 1.0))
	CreatureEpisodicMemory.record_memory(
		self, "attacked",
		initiator.global_position if is_instance_valid(initiator) else global_position,
		clamp(actual_dmg / 30.0, 0.2, 1.0), -1.0
	)
	record_experience("received_hit", false, -1.0)

	if is_instance_valid(initiator):
		var initiator_reward = -0.2
		if initiator.personality == Personality.AGGRESSIVE:
			initiator._emotion = Constants.EMOTION_EXCITEMENT
			initiator.emotion_intensity = 0.7
			initiator_reward = 0.4
		elif initiator in known_enemies:
			initiator._emotion = Constants.EMOTION_ANGER
			initiator.emotion_intensity = 0.65
			initiator_reward = 0.15
		else:
			initiator._emotion = Constants.EMOTION_CONTENTMENT
			initiator.emotion_intensity = 0.3
			initiator.trauma_level = min(1.0, initiator.trauma_level + 0.03)
		initiator._interaction_flash_timer = 0.35
		initiator._interaction_flash_color = Color(1.0, 0.4, 0.1)
		initiator.update_relationship(self, -0.1, 0.1, 0.2)
		initiator.record_experience("hit_other", initiator_reward > 0, initiator_reward)

	interaction_happened.emit(initiator, self, "hit", "damaged:%.1f" % actual_dmg)

# ── MATING REQUEST ───────────────────────────────────────────────────────────
func receive_mating_request(initiator) -> void:
	if not is_instance_valid(initiator) or life_stage == Constants.LIFE_STAGE_DECEASED:
		return

	var rel_trust = 0.0
	if relationships.has(initiator):
		rel_trust = relationships[initiator].get("trust", 0.0)

	var willing = (
		life_stage == Constants.LIFE_STAGE_ADULT
		and repro_drive >= 55.0
		and repro_cooldown <= 0.0
		and health >= 50.0
		and _emotion != Constants.EMOTION_PAIN
		and _emotion != Constants.EMOTION_ANGER
		and initiator not in known_enemies
		and (rel_trust >= -0.2 or initiator in known_friends)
		and trauma_level < 0.65
	)

	var accepted = false
	if willing:
		if personality == Personality.MATERNAL or personality == Personality.SOCIAL:
			accepted = true
		elif personality == Personality.FEARFUL and initiator not in known_friends:
			accepted = randf() < 0.25
		else:
			accepted = randf() < 0.75

	if accepted:
		repro_drive = 0.0
		repro_cooldown = Constants.BREEDING_COOLDOWN_HOURS * Constants.GAME_HOUR_SECONDS
		_emotion = Constants.EMOTION_EXCITEMENT
		emotion_intensity = 0.95
		_interaction_flash_timer = 0.8
		_interaction_flash_color = Color(1.0, 0.5, 0.9)
		update_relationship(initiator, 0.2, -0.1, -0.1)
		if initiator not in known_friends:
			record_social_bond(initiator, "friend", 0.8)
		record_experience("mating_accepted", true, 1.0)
		# Neurochemistry: dopamine + oxytocin surge on successful mating
		CreatureNeurochemistry.apply_event(self, "mate_found", 1.0)
		CreatureEpisodicMemory.record_memory(
			self, "mate_found",
			initiator.global_position if is_instance_valid(initiator) else global_position,
			1.0, 1.0
		)
		wants_reproduce.emit(self, initiator)

		if is_instance_valid(initiator):
			initiator.repro_drive = 0.0
			initiator.repro_cooldown = Constants.BREEDING_COOLDOWN_HOURS * Constants.GAME_HOUR_SECONDS
			initiator._emotion = Constants.EMOTION_EXCITEMENT
			initiator.emotion_intensity = 0.95
			initiator._interaction_flash_timer = 0.8
			initiator._interaction_flash_color = Color(1.0, 0.5, 0.9)
			initiator.update_relationship(self, 0.2, -0.1, -0.1)
			if self not in initiator.known_friends:
				initiator.record_social_bond(self, "friend", 0.8)
			initiator.record_experience("mating_request", true, 1.0)

		interaction_happened.emit(initiator, self, "mating_request", "accepted")
	else:
		_emotion = Constants.EMOTION_EMBARRASSMENT
		emotion_intensity = 0.6
		_interaction_flash_timer = 0.4
		_interaction_flash_color = Color(0.9, 0.8, 0.3)
		if not willing:
			update_relationship(initiator, -0.1, 0.15, 0.1)
			record_experience("rejected_mating", false, -0.2)

		if is_instance_valid(initiator):
			initiator._emotion = Constants.EMOTION_EMBARRASSMENT
			initiator.emotion_intensity = 0.8
			initiator.trauma_level = min(1.0, initiator.trauma_level + 0.06)
			initiator._interaction_flash_timer = 0.5
			initiator._interaction_flash_color = Color(0.8, 0.7, 0.2)
			initiator.update_relationship(self, -0.12, 0.08, 0.05)
			initiator.record_experience("mating_request", false, -0.5)

		interaction_happened.emit(initiator, self, "mating_request", "rejected")

# ═══════════════════════════════════════════════════════════════════════

func _find_nearest_food(sight: float) -> Node2D:
	var best: Node2D = null
	var best_d = sight * sight
	for f in get_tree().get_nodes_in_group("food"):
		if not is_instance_valid(f):
			continue
		var d = global_position.distance_squared_to(f.global_position)
		if d < best_d:
			best_d = d
			best = f
	return best

func _find_nearby_mate(sight: float) -> Node2D:
	var best: Node2D = null
	var best_d = sight * sight * 4.0
	for c in get_tree().get_nodes_in_group("creatures"):
		if c == self or not is_instance_valid(c):
			continue
		if c.life_stage != Constants.LIFE_STAGE_ADULT:
			continue
		if c.repro_cooldown > 0 or c.repro_drive < 60.0:
			continue
		var d = global_position.distance_squared_to(c.global_position)
		if d < best_d:
			best_d = d
			best = c
	return best

func _pick_wander_target() -> void:
	# Creatures use their memory to navigate toward known food/water spots
	# when hungry/thirsty AND they have a positive learned preference.
	#
	# BUG FIX: Old code rolled randf()<0.5 for EACH memory entry in a loop,
	# meaning the BEST (newest) remembered spot was skipped ~50% of the time,
	# and the creature often fell through to random wander despite "knowing" where
	# food was. This completely broke the learning-→-navigation feedback loop.
	# Fix: scan all memories, pick the NEWEST matching entry deterministically.
	# Use episodic memory to navigate toward known food/water spots
	var food_signal := CreatureEpisodicMemory.query_memory(self, "food_found", global_position, 400.0)
	var water_signal := CreatureEpisodicMemory.query_memory(self, "water_found", global_position, 400.0)

	# If hungry and memory says food was nearby, path toward best remembered spot
	if hunger < 75.0 and food_signal > 0.1:
		var best_food_mem = null
		var best_score := -999.0
		for mem in episodic_memory:
			if mem.get("event") == "food_found" and mem.get("valence", 0.0) > 0.0:
				var age: float = age_hours - float(mem.get("time", 0.0))
				var score: float = float(mem.get("magnitude", 0.0)) - age * 0.01
				if score > best_score:
					best_score = score
					best_food_mem = mem
		if best_food_mem != null:
			var remembered_pos: Vector2 = best_food_mem.get("location", Vector2.ZERO)
			if remembered_pos != Vector2.ZERO:
				var dir := remembered_pos - global_position
				if dir.length() > 10.0:
					move_dir = (dir.normalized() + Vector2(randf_range(-0.2, 0.2), randf_range(-0.2, 0.2))).normalized()
					move_timer = randf_range(2.5, 5.0)
					return
	
	# If thirsty and we remember a water spot, head to it
	if thirst < 75.0 and water_signal > 0.2:
		var best_water_mem = null
		var best_time = -1.0
		for mem in memory:
			if mem.get("value") == "water":
				if mem.get("time", 0.0) > best_time:
					best_time = mem.get("time", 0.0)
					best_water_mem = mem
		if best_water_mem != null:
			var remembered_pos = best_water_mem.get("pos", Vector2.ZERO)
			if remembered_pos != Vector2.ZERO:
				var dir = (remembered_pos - global_position)
				if dir.length() > 10.0:
					move_dir = (dir.normalized() + Vector2(randf_range(-0.2, 0.2), randf_range(-0.2, 0.2))).normalized()
					move_timer = randf_range(2.5, 5.0)
					return
	
	# Default: random wander with personality flavour
	var angle = randf() * TAU

	# THERMOTOLERANCE: creatures with low tolerance flee desert/cavern biomes.
	# They pick a direction away from the hot zone rather than fully random.
	var thermo = genome.get_trait_value(Constants.TRAIT_THERMOTOLERANCE) if genome else 1.0
	if thermo < 0.85:
		var world = get_tree().get_first_node_in_group("world")
		if world and world.has_method("get_biome_at"):
			var biome = world.get_biome_at(global_position)
			if biome == Constants.BIOME_DESERT or biome == Constants.BIOME_CAVERN:
				# Point toward screen center (away from edges where desert/cavern tend to be)
				var escape_dir = (get_viewport_rect().size * 0.5 - global_position).normalized()
				# Blend with random noise so it's not purely mechanical
				var noise = Vector2(randf_range(-0.5, 0.5), randf_range(-0.5, 0.5))
				angle = (escape_dir + noise).angle()

	# Explorer/Curious creatures wander more boldly (longer legs)
	var wander_time = randf_range(1.5, 4.0)
	match personality:
		Personality.EXPLORER, Personality.CURIOUS:
			wander_time = randf_range(2.5, 6.0)
		Personality.FEARFUL:
			wander_time = randf_range(0.8, 2.5)
		Personality.LAZY:
			wander_time = randf_range(3.0, 7.0)
	move_dir = Vector2(cos(angle), sin(angle))
	move_timer = wander_time

func _update_emotion() -> void:
	var nc = neurochemicals
	if nc.is_empty():
		return  # neurochemistry not yet initialised

	var mood := CreatureNeurochemistry.compute_mood(nc)

	# Schachter-Singer two-factor: intensity = adrenaline (arousal),
	# type = cognitive appraisal (cortisol=fear vs dopamine=anger)
	if nc["adrenaline"] > 0.5:
		_emotion = Constants.EMOTION_FEAR if nc["cortisol"] > nc["dopamine"] \
				else Constants.EMOTION_ANGER
		emotion_intensity = nc["adrenaline"]

	elif nc["dopamine"] > 0.7 and nc["oxytocin"] > 0.4:
		_emotion = Constants.EMOTION_LOVE
		emotion_intensity = (nc["dopamine"] + nc["oxytocin"]) * 0.5

	elif nc["dopamine"] > 0.6:
		_emotion = Constants.EMOTION_EXCITEMENT
		emotion_intensity = nc["dopamine"]

	elif nc["endorphin"] > 0.5 and nc["cortisol"] < 0.3:
		_emotion = Constants.EMOTION_CONTENTMENT
		emotion_intensity = nc["endorphin"]

	elif nc["cortisol"] > 0.6:
		_emotion = Constants.EMOTION_PAIN if nc["endorphin"] > 0.3 \
				else Constants.EMOTION_FEAR
		emotion_intensity = nc["cortisol"]

	elif nc["boredom"] > 0.6:
		_emotion = Constants.EMOTION_CURIOSITY
		emotion_intensity = nc["boredom"]

	else:
		_emotion = Constants.EMOTION_CONTENTMENT
		emotion_intensity = max(0.1, mood * 0.5 + 0.5)

	emotion_intensity = clamp(emotion_intensity, 0.0, 1.0)

	# Mental disorder effects (unchanged)
	if mental_disorder != MentalDisorder.NONE:
		match mental_disorder:
			MentalDisorder.ANXIETY:
				if _emotion != Constants.EMOTION_FEAR:
					emotion_intensity = min(1.0, emotion_intensity + 0.15)
				personality_modifiers["fear_resist"] = 0.5
			MentalDisorder.DEPRESSION:
				will_to_live = max(0.2, will_to_live - 0.002)
				personality_modifiers["speed"] = 0.7
			MentalDisorder.PTSD:
				if randf() < 0.08:
					_emotion = Constants.EMOTION_FEAR
					emotion_intensity = 0.9
			MentalDisorder.AGGRESSION_DISORDER:
				personality_modifiers["social"] = 0.2
				if _emotion == Constants.EMOTION_CONTENTMENT:
					_emotion = Constants.EMOTION_ANGER

	# Trauma reduces will_to_live over time
	if trauma_level > 0.3:
		will_to_live = max(0.3, will_to_live - trauma_level * 0.001)

	# Chance to develop mental disorder from high trauma
	if trauma_level > 0.6 and mental_disorder == MentalDisorder.NONE and randf() < 0.015:
		mental_disorder = [MentalDisorder.ANXIETY, MentalDisorder.DEPRESSION, MentalDisorder.PTSD][randi() % 3]
		disorder_severity = randf_range(0.4, 0.9)
		record_trauma("mental_breakdown", 0.8)


# ─────────────────────────────────────────────────────────────────────────────
func _update_life_stage() -> void:
	# BUG FIX: Never overwrite DECEASED. Previously an early death (disease /
	# starvation) was silently reverted every frame because the age-based check
	# ran unconditionally, resetting life_stage back to ELDER whenever
	# age_hours < LIFESPAN_HOURS. A dead creature must stay dead.
	if life_stage == Constants.LIFE_STAGE_DECEASED:
		return
	var old_stage = life_stage
	if age_hours < Constants.EMBRYO_DURATION_HOURS:
		life_stage = Constants.LIFE_STAGE_EMBRYO
	elif age_hours < Constants.JUVENILE_DURATION_HOURS:
		life_stage = Constants.LIFE_STAGE_JUVENILE
	elif age_hours < Constants.ADULT_DURATION_HOURS:
		life_stage = Constants.LIFE_STAGE_ADULT
	elif age_hours < Constants.LIFESPAN_HOURS:
		life_stage = Constants.LIFE_STAGE_ELDER
	else:
		life_stage = Constants.LIFE_STAGE_DECEASED
	if old_stage != life_stage:
		_load_creature_sprite()
		queue_redraw()

# ─────────────────────────────────────────────────────────────────────────────
# DRAWING
# ─────────────────────────────────────────────────────────────────────────────
func _draw() -> void:
	var bob = sin(_bob_phase) * 2.0
	if current_sprite != null:
		# Real sprite rendering (visual upgrade)
		var tex = current_sprite
		var sz = tex.get_size()
		var scale_factor = base_scale * (1.0 + sin(_bob_phase) * 0.03)  # gentle breathing
		var draw_pos = Vector2(-sz.x * scale_factor / 2.0, bob - sz.y * scale_factor * 0.75)
		
		if facing_right:
			draw_texture_rect(tex, Rect2(draw_pos, sz * scale_factor), false)
		else:
			# Flip horizontally
			draw_set_transform(Vector2.ZERO, 0, Vector2(-1, 1))
			draw_texture_rect(tex, Rect2(draw_pos * Vector2(-1, 1), sz * scale_factor), false)
			draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)
	else:
		# Fallback procedural (original beautiful vector art)
		match life_stage:
			Constants.LIFE_STAGE_EMBRYO:
				_draw_embryo(bob)
			Constants.LIFE_STAGE_JUVENILE:
				_draw_juvenile(bob)
			Constants.LIFE_STAGE_ADULT:
				_draw_adult(bob)
			Constants.LIFE_STAGE_ELDER:
				_draw_elder(bob)
			Constants.LIFE_STAGE_DECEASED:
				_draw_deceased()
				return

	_draw_health_bar()
	_draw_needs_indicators()
	_draw_emotion_bubble()
	_draw_morphology_details()

func _draw_embryo(bob: float) -> void:
	var y = bob
	draw_circle(Vector2(0, y), 12, Color(1.0, 0.92, 0.86))
	draw_arc(Vector2(0, y), 12, 0, TAU, 32, Color(1.0, 0.71, 0.63), 2)
	draw_circle(Vector2(-3, y - 4), 3, Color(1.0, 0.95, 0.95, 0.6))
	for i in range(3):
		var angle = (i / 3.0) * TAU + _bob_phase * 0.5
		var sp = Vector2(cos(angle), sin(angle)) * 16
		draw_line(sp + Vector2(0,y) - Vector2(3,0), sp + Vector2(0,y) + Vector2(3,0), Color(1.0, 0.90, 0.40, 0.7), 1)
		draw_line(sp + Vector2(0,y) - Vector2(0,3), sp + Vector2(0,y) + Vector2(0,3), Color(1.0, 0.90, 0.40, 0.7), 1)

func _draw_juvenile(bob: float) -> void:
	var hair = HAIR_COLORS[color_variant]
	var eye  = EYE_COLORS[color_variant]
	var dress = DRESS_COLORS[color_variant]
	var y = bob
	var outline = Color(0.24, 0.16, 0.31)
	draw_circle(Vector2(0, y - 14), 12, hair)
	var body_pts = PackedVector2Array([
		Vector2(-8, y - 4), Vector2(8, y - 4),
		Vector2(10, y + 18), Vector2(-10, y + 18)
	])
	draw_colored_polygon(body_pts, dress)
	draw_polyline(body_pts + PackedVector2Array([body_pts[0]]), outline, 1.5)
	draw_circle(Vector2(0, y - 14), 10, Color(1.0, 0.86, 0.76))
	draw_arc(Vector2(0, y - 14), 10, 0, TAU, 32, outline, 1.5)
	draw_circle(Vector2(0, y - 20), 10, hair)
	draw_arc(Vector2(0, y - 20), 10, PI * 0.3, PI * 0.7, 12, outline, 1)
	if _blink_open:
		_draw_eye(Vector2(-4, y - 13), 3.5, eye)
		_draw_eye(Vector2(4, y - 13), 3.5, eye)
	else:
		draw_line(Vector2(-6.5, y - 13), Vector2(-1.5, y - 13), outline, 1.5)
		draw_line(Vector2(1.5, y - 13), Vector2(6.5, y - 13), outline, 1.5)
	draw_circle(Vector2(-6, y - 11), 2.5, Color(1.0, 0.70, 0.70, 0.5))
	draw_circle(Vector2(6, y - 11), 2.5, Color(1.0, 0.70, 0.70, 0.5))
	draw_arc(Vector2(0, y - 10), 3, 0.1, PI - 0.1, 10, outline, 1)
	draw_line(Vector2(-8, y), Vector2(-13, y + 8), Color(1.0, 0.86, 0.76), 3)
	draw_line(Vector2(8, y), Vector2(13, y + 8), Color(1.0, 0.86, 0.76), 3)
	draw_line(Vector2(-4, y + 17), Vector2(-5, y + 26), Color(1.0, 0.86, 0.76), 4)
	draw_line(Vector2(4, y + 17), Vector2(5, y + 26), Color(1.0, 0.86, 0.76), 4)

func _draw_adult(bob: float) -> void:
	var hair = HAIR_COLORS[color_variant]
	var eye  = EYE_COLORS[color_variant]
	var dress = DRESS_COLORS[color_variant]
	var y = bob
	var outline = Color(0.24, 0.16, 0.31)
	var skin = Color(1.0, 0.86, 0.76)
	var hair_back = PackedVector2Array([
		Vector2(-10, y - 22), Vector2(10, y - 22),
		Vector2(14, y + 20), Vector2(-14, y + 20)
	])
	draw_colored_polygon(hair_back, hair)
	var dress_pts = PackedVector2Array([
		Vector2(-7, y - 8), Vector2(7, y - 8),
		Vector2(12, y + 22), Vector2(-12, y + 22)
	])
	draw_colored_polygon(dress_pts, dress)
	draw_polyline(dress_pts + PackedVector2Array([dress_pts[0]]), outline, 1.5)
	draw_colored_polygon(PackedVector2Array([
		Vector2(-7, y - 8), Vector2(0, y - 2), Vector2(7, y - 8)
	]), Color(1, 1, 1, 0.7))
	draw_circle(Vector2(0, y - 18), 10, skin)
	draw_arc(Vector2(0, y - 18), 10, 0, TAU, 32, outline, 1.5)
	draw_circle(Vector2(0, y - 24), 10, hair)
	draw_arc(Vector2(0, y - 24), 10, PI * 0.2, PI * 0.8, 12, outline, 1)
	draw_circle(Vector2(-12, y - 16), 5, hair)
	draw_circle(Vector2(12, y - 16), 5, hair)
	if _blink_open:
		_draw_eye(Vector2(-4, y - 18), 4, eye)
		_draw_eye(Vector2(4, y - 18), 4, eye)
	else:
		draw_line(Vector2(-7, y - 18), Vector2(-1, y - 18), outline, 2)
		draw_line(Vector2(1, y - 18), Vector2(7, y - 18), outline, 2)
	draw_circle(Vector2(-6.5, y - 15), 3, Color(1.0, 0.63, 0.63, 0.45))
	draw_circle(Vector2(6.5, y - 15), 3, Color(1.0, 0.63, 0.63, 0.45))
	draw_circle(Vector2(0, y - 14), 1.2, Color(0.86, 0.67, 0.59))
	draw_arc(Vector2(0, y - 12), 3, 0.2, PI - 0.2, 10, outline, 1)
	draw_line(Vector2(-7, y - 5), Vector2(-14, y + 8), skin, 4)
	draw_circle(Vector2(-15, y + 9), 3, skin)
	draw_line(Vector2(7, y - 5), Vector2(14, y + 8), skin, 4)
	draw_circle(Vector2(15, y + 9), 3, skin)
	draw_line(Vector2(-4, y + 21), Vector2(-5, y + 32), Color(0.94, 0.76, 0.67), 5)
	draw_line(Vector2(4, y + 21), Vector2(5, y + 32), Color(0.94, 0.76, 0.67), 5)
	draw_circle(Vector2(-6, y + 33), 4, Color(0.31, 0.24, 0.39))
	draw_circle(Vector2(6, y + 33), 4, Color(0.31, 0.24, 0.39))
	draw_circle(Vector2(-3, y - 26), 3, Color(1, 1, 1, 0.35))
	# Eating animation
	if _eat_anim > 0:
		draw_circle(Vector2(0, y - 10), 5, Color(1.0, 0.6, 0.2, _eat_anim * 2.0))

func _draw_elder(bob: float) -> void:
	_draw_adult(bob)
	var y = bob
	draw_line(Vector2(2, y - 28), Vector2(4, y - 16), Color(0.90, 0.90, 1.0, 0.8), 2)
	for i in range(4):
		var angle = (i / 4.0) * TAU + _bob_phase * 0.3
		var sp = Vector2(cos(angle), sin(angle)) * 22
		draw_line(sp - Vector2(3, 0), sp + Vector2(3, 0), Color(1.0, 0.86, 0.39, 0.6), 1)
		draw_line(sp - Vector2(0, 3), sp + Vector2(0, 3), Color(1.0, 0.86, 0.39, 0.6), 1)

func _draw_deceased() -> void:
	draw_circle(Vector2(0, 0), 8, Color(0.6, 0.6, 0.7, 0.35))
	draw_arc(Vector2(0, 0), 8, 0, TAU, 32, Color(0.5, 0.5, 0.6, 0.45), 1)
	# Little zzz
	draw_string(ThemeDB.fallback_font, Vector2(6, -10), "✦", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.7,0.7,0.9,0.5))

func _draw_eye(pos: Vector2, size: float, color: Color) -> void:
	_draw_ellipse(pos, Vector2(size, size * 0.65), Color(1, 1, 1))
	draw_circle(pos, size * 0.62, color)
	draw_circle(pos, size * 0.28, Color(0.08, 0.04, 0.12))
	draw_circle(pos + Vector2(-size * 0.25, -size * 0.3), size * 0.22, Color(1, 1, 1))

func _draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
	var pts = PackedVector2Array()
	for i in range(21):
		var a = (i / 20.0) * TAU
		pts.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(pts, color)

func _draw_health_bar() -> void:
	var bar_w = 28.0
	var bar_h = 4.0
	var bar_y = -46.0
	if life_stage == Constants.LIFE_STAGE_JUVENILE:
		bar_y = -38.0
	elif life_stage == Constants.LIFE_STAGE_EMBRYO:
		bar_y = -22.0
	var bx = -bar_w / 2.0
	draw_rect(Rect2(bx - 1, bar_y - 1, bar_w + 2, bar_h + 2), Color(0.12, 0.09, 0.18))
	var pct = clamp(health / 100.0, 0, 1)
	var fill_c = Color(0.39, 0.86, 0.47).lerp(Color(0.86, 0.31, 0.31), 1.0 - pct)
	draw_rect(Rect2(bx, bar_y, bar_w * pct, bar_h), fill_c)

func _draw_needs_indicators() -> void:
	# Small dot indicators below health bar: hunger (orange), thirst (blue), fatigue (purple)
	var bar_y = -40.0
	if life_stage == Constants.LIFE_STAGE_JUVENILE: bar_y = -32.0
	bar_y += 6.0
	var indicators = [
		[hunger,  Color(1.0, 0.65, 0.2)],
		[thirst,  Color(0.3, 0.7,  1.0)],
		[fatigue, Color(0.75, 0.4,  0.9)],
	]
	for i in range(3):
		var v = indicators[i][0] as float
		var col = indicators[i][1] as Color
		var x = -9.0 + i * 9.0
		var full_h = 7.0
		var fill_h = full_h * (v / 100.0)
		draw_rect(Rect2(x - 2, bar_y - full_h, 4, full_h), Color(0,0,0,0.3))
		if fill_h > 0:
			draw_rect(Rect2(x - 2, bar_y - fill_h, 4, fill_h), col * (0.6 if v < 30 else 1.0))

func _draw_emotion_bubble() -> void:
	var top_y = -54.0
	if life_stage == Constants.LIFE_STAGE_JUVENILE: top_y = -46.0
	
	# Emotion / Breakdown / Illness emoji
	var emoji = "😊"
	var has_sepsis = false
	for w in wounds:
		if w.condition == Constants.WOUND_STATE_SEPTIC:
			has_sepsis = true
			break
			
	if active_mental_break != Constants.BREAK_NONE:
		match active_mental_break:
			Constants.BREAK_BERSERK: emoji = "😡"
			Constants.BREAK_DEPRESSIVE: emoji = "😭"
			Constants.BREAK_CATATONIC: emoji = "💤"
			Constants.BREAK_PANIC: emoji = "😱"
	elif viral_infection > 0.25 or parasitical_infection > 0.25 or has_sepsis:
		emoji = "🤒"
	else:
		match _emotion:
			Constants.EMOTION_PAIN:       emoji = "😣"
			Constants.EMOTION_FEAR:       emoji = "😨"
			Constants.EMOTION_EXCITEMENT: emoji = "💕"
			Constants.EMOTION_CURIOSITY:  emoji = "🌟"
			Constants.EMOTION_CONTENTMENT: emoji = "😊"
			Constants.EMOTION_ANGER:      emoji = "😠"
			Constants.EMOTION_LOVE:       emoji = "😍"
			Constants.EMOTION_EMBARRASSMENT: emoji = "😳"
	
	draw_string(ThemeDB.fallback_font, Vector2(-7, top_y), emoji,
		HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1,1,1,0.95))
	
	# Personality icon (small letter or symbol above emotion)
	var pers_icon = ""
	match personality:
		Personality.CURIOUS: pers_icon = "🔍"
		Personality.FEARFUL: pers_icon = "🛡️"
		Personality.AGGRESSIVE: pers_icon = "⚔️"
		Personality.SOCIAL: pers_icon = "👥"
		Personality.MATERNAL: pers_icon = "🍼"
		Personality.LAZY: pers_icon = "💤"
		Personality.EXPLORER: pers_icon = "🗺️"
	if pers_icon != "":
		draw_string(ThemeDB.fallback_font, Vector2(12, top_y - 14), pers_icon,
			HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 0.95, 1.0, 0.85))

func _draw_morphology_details() -> void:
	# Procedural body parts based on genome (7)
	var y = sin(_bob_phase) * 2.0
	var outline = Color(0.24, 0.16, 0.31)
	
	# Horns (from strength)
	if horn_length > 3.0:
		draw_line(Vector2(-6, y - 26), Vector2(-6 - horn_length * 0.4, y - 26 - horn_length * 0.6), outline, 2.5)
		draw_line(Vector2(6, y - 26), Vector2(6 + horn_length * 0.4, y - 26 - horn_length * 0.6), outline, 2.5)
	
	# Ears (from intelligence)
	if ear_size > 1.1:
		draw_line(Vector2(-10, y - 18), Vector2(-14 * ear_size, y - 12), outline, 2)
		draw_line(Vector2(10, y - 18), Vector2(14 * ear_size, y - 12), outline, 2)
	
	# Tail
	if tail_length > 5.0:
		var tail_end = Vector2(18, y + 22)
		draw_line(Vector2(8, y + 20), tail_end, Color(0.4, 0.3, 0.35), 3)
		if tail_length > 12.0:
			draw_circle(tail_end, 3, Color(0.5, 0.35, 0.4))
	
	# Eye glow (from high intelligence)
	if eye_glow > 0.3:
		draw_circle(Vector2(-4, y - 18), 2.5, Color(0.6, 0.9, 1.0, eye_glow * 0.6))
		draw_circle(Vector2(4, y - 18), 2.5, Color(0.6, 0.9, 1.0, eye_glow * 0.6))

# ─────────────────────────────────────────────────────────────────────────────
func _on_area_input_event(_viewport, event, _shape_idx) -> void:
	if event is InputEventMouseButton and event.pressed:
		creature_selected.emit(self)

func _cleanup_dead_references() -> void:
	known_friends  = known_friends.filter(func(f): return is_instance_valid(f))
	known_enemies  = known_enemies.filter(func(e): return is_instance_valid(e))
	known_parents  = known_parents.filter(func(p): return is_instance_valid(p))
	known_children = known_children.filter(func(c): return is_instance_valid(c))

	# Clean relationships dict — erase any key whose node is gone
	for key in relationships.keys():
		if not is_instance_valid(key):
			relationships.erase(key)
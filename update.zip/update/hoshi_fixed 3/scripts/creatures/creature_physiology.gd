class_name CreaturePhysiology
# Handles all physiological needs, wounds, diseases, and health ticks.
# Extracted from creature_visual.gd (was 1873-line monolith) so this logic
# can be read, tested, and tuned independently of drawing or AI code.
#
# Usage: instantiate and call tick(hour_delta, genome, ai_state) each frame.
# The owner node holds all state vars (hunger, health, wounds…) directly —
# this class receives them by reference via a Dictionary context and writes
# results back, keeping Godot's duck-typed style while separating concerns.

# Returns 0.0 at start of elder stage (age 60), 1.0 at age 100.
# Beyond 100 stays at 1.0 (maximum degradation already reached).
# All aging-degradation formulas share this single curve.
static func age_factor(c: Node2D) -> float:
	if c.life_stage != Constants.LIFE_STAGE_ELDER:
		return 0.0
	# LONGEVITY trait stretches the elder window:
	#   value=0.5 → elder_start=50, elder_peak=83  (short-lived)
	#   value=1.0 → elder_start=60, elder_peak=100 (baseline)
	#   value=1.5 → elder_start=70, elder_peak=117 (long-lived)
	var longevity = c.genome.get_trait_value(Constants.TRAIT_LONGEVITY) if c.genome else 1.0
	var elder_start = float(Constants.ELDER_START_YEARS) * longevity
	var elder_peak  = 100.0 * longevity
	return clamp((c.age_hours - elder_start) / (elder_peak - elder_start), 0.0, 1.0)

static func tick(c: Node2D, hour_delta: float) -> void:
	"""Run one physiology frame on creature node `c`."""
	_process_wounds(c, hour_delta)
	_process_diseases(c, hour_delta)
	_process_stress(c, hour_delta)
	_process_mental_break(c, hour_delta)
	_process_needs(c, hour_delta)
	_process_health_damage(c, hour_delta)


static func _process_wounds(c: Node2D, hour_delta: float) -> void:
	var pain_score := 0.0
	var bleed_damage := 0.0
	var sepsis_count := 0
	var active_wounds := []

	# Aging: weaker immune system → wounds infect and worsen faster
	var af = age_factor(c)
	var elder_infection_mult = lerp(1.0, 2.0, af)  # up to 2× infection chance
	var elder_heal_mult      = lerp(1.0, 0.45, af) # wound healing up to 55% slower

	for w in c.wounds:
		var prev_condition = w.condition  # snapshot before any mutations this tick

		if w.condition == Constants.WOUND_STATE_BLEEDING:
			bleed_damage += 15.0 * w.severity
			if randf() < 0.08 * hour_delta:
				w.condition = Constants.WOUND_STATE_NONE

		if (w.type == Constants.DAMAGE_TYPE_LACERATION or w.type == Constants.DAMAGE_TYPE_PUNCTURE) \
				and prev_condition == Constants.WOUND_STATE_NONE:
			var starvation_mod = 2.0 if c.hunger < 40.0 else 1.0
			if randf() < Constants.INFECTION_CHANCE_BASE * w.severity * starvation_mod \
					* elder_infection_mult * hour_delta:
				w.condition = Constants.WOUND_STATE_INFECTED

		if w.condition == Constants.WOUND_STATE_INFECTED:
			if randf() < 0.12 * elder_infection_mult * hour_delta:
				w.condition = Constants.WOUND_STATE_SEPTIC

		if w.condition == Constants.WOUND_STATE_SEPTIC:
			sepsis_count += 1
			bleed_damage += 8.0 * w.severity

		var pain_mult = 1.5 if w.condition == Constants.WOUND_STATE_SEPTIC \
				else (1.2 if w.condition == Constants.WOUND_STATE_FRACTURED else 1.0)
		pain_score += w.severity * pain_mult

		if c.hunger > 40.0 and c.thirst > 40.0:
			var heal_speed = 0.08 * elder_heal_mult
			if c.ai_state == 3:  # AIState.REST
				heal_speed *= 2.0
			w.severity -= heal_speed * hour_delta

		if w.severity > 0.08:
			active_wounds.append(w)
		else:
			if w.condition != Constants.WOUND_STATE_SCARRED and randf() < 0.5:
				w.condition = Constants.WOUND_STATE_SCARRED
				w.severity = 0.08
				active_wounds.append(w)

	c.wounds = active_wounds
	c.health -= bleed_damage * hour_delta
	# Store for use by stress / mental-break passes below
	c.set_meta("_pain_score", pain_score)
	c.set_meta("_sepsis_count", sepsis_count)


static func _process_diseases(c: Node2D, hour_delta: float) -> void:
	var af = age_factor(c)
	# Aging: immune system weakens — viruses progress faster, recovery slower
	var elder_virus_mult    = lerp(1.0, 1.60, af)  # up to 60% faster progression
	var elder_recovery_mult = lerp(1.0, 0.45, af)  # up to 55% slower recovery
	var elder_contagion_mult = lerp(1.0, 1.80, af) # elders catch viruses much more easily

	if c.viral_infection > 0.0:
		c.viral_infection = min(1.0, c.viral_infection + 0.05 * elder_virus_mult * hour_delta)
		c.cough_cooldown -= hour_delta * Constants.GAME_HOUR_SECONDS
		if c.cough_cooldown <= 0.0:
			c.cough_cooldown = randf_range(12.0, 24.0)
			for other in c.get_tree().get_nodes_in_group("creatures"):
				if other != c and is_instance_valid(other) \
						and other.life_stage != Constants.LIFE_STAGE_DECEASED:
					if c.global_position.distance_to(other.global_position) < Constants.CONTAGION_RANGE:
						var other_immunity = other.genome.get_trait_value(Constants.TRAIT_TOXIN_RESISTANCE) \
								if other.genome else 1.0
						# Elders are more susceptible to catching viruses
						var other_susc = lerp(1.0, 1.8, age_factor(other)) \
								if other.life_stage == Constants.LIFE_STAGE_ELDER else 1.0
						if randf() < 0.45 * other_susc / other_immunity:
							other.viral_infection = max(other.viral_infection, 0.15)
			c._interaction_flash_timer = 0.4
			c._interaction_flash_color = Color(0.6, 0.9, 0.3)

		if c.viral_infection >= 1.0:
			c.health -= 5.0 * hour_delta
		if c.hunger > 40.0 and c.thirst > 40.0:
			c.viral_infection = max(0.0, c.viral_infection - 0.08 * elder_recovery_mult * hour_delta)

	if c.parasitical_infection > 0.0:
		# Elders clear parasites more slowly
		var para_clear_mult = lerp(1.0, 0.50, af)
		c.parasitical_infection = min(1.0, c.parasitical_infection + 0.04 * elder_virus_mult * hour_delta)
		if c.fatigue > 60.0:
			c.parasitical_infection = max(0.0, c.parasitical_infection - 0.06 * para_clear_mult * hour_delta)


static func _process_stress(c: Node2D, hour_delta: float) -> void:
	# Stress is now cortisol (chemical system is canonical).
	# Physiological stressors raise cortisol; cortisol syncs back to stress_level.
	var pain_score: float  = c.get_meta("_pain_score", 0.0)
	var sepsis_count: int  = c.get_meta("_sepsis_count", 0)

	var hunger_stress: float  = (40.0 - c.hunger)  / 40.0 if c.hunger  < 40.0 else 0.0
	var thirst_stress: float  = (40.0 - c.thirst)  / 40.0 if c.thirst  < 40.0 else 0.0
	var fatigue_stress: float = (40.0 - c.fatigue) / 40.0 if c.fatigue < 40.0 else 0.0
	var illness_stress := (0.2 if c.viral_infection > 0.2 else 0.0) \
			+ (0.15 if c.parasitical_infection > 0.2 else 0.0) \
			+ (0.3 if sepsis_count > 0 else 0.0)

	var raw_stress_gain: float = pain_score * 0.25 + hunger_stress * 0.10 \
			+ thirst_stress * 0.12 + fatigue_stress * 0.08 \
			+ c.trauma_level * 0.20 + illness_stress

	var stress_mult := 1.0
	match c.personality:
		1: stress_mult = 1.5   # FEARFUL
		2: stress_mult = 1.2   # AGGRESSIVE
		6: stress_mult = 0.6   # LAZY

	var biome_stress := 0.0
	var world := c.get_tree().get_first_node_in_group("world") if c.get_tree() else null
	if world and world.has_method("get_biome_at"):
		var biome: int = world.get_biome_at(c.global_position)
		if biome == Constants.BIOME_DESERT:
			biome_stress = 0.18
		elif biome == Constants.BIOME_CAVERN:
			biome_stress = 0.10
	if biome_stress > 0.0:
		var thermo: float = float(c.genome.get_trait_value(Constants.TRAIT_THERMOTOLERANCE)) if c.genome else 1.0
		biome_stress *= clamp(2.0 - thermo * 2.0, 0.0, 2.0)
	raw_stress_gain += biome_stress

	# Push cortisol up based on physiological stressors
	if raw_stress_gain > 0.0 and "neurochemicals" in c and c.neurochemicals:
		var nc = c.neurochemicals
		nc["cortisol"] = clamp(
			nc["cortisol"] + raw_stress_gain * stress_mult * hour_delta * 0.3,
			0.0, 1.0
		)
		# Good conditions actively lower cortisol
		if c.hunger > 50.0 and c.thirst > 50.0 and pain_score < 0.1:
			nc["cortisol"] = max(0.0, nc["cortisol"] - 0.08 * hour_delta)

	# Sync legacy stress_level ← cortisol (smoothed read-out)
	var target_stress: float
	if "neurochemicals" in c and c.neurochemicals:
		target_stress = c.neurochemicals.get("cortisol", 0.0)
	else:
		target_stress = min(1.0, c.stress_level + raw_stress_gain * stress_mult * hour_delta)
	c.stress_level = lerp(c.stress_level, target_stress, 0.1 * hour_delta)
	c.stress_level = clamp(c.stress_level, 0.0, 1.0)

	# will_to_live driven by mood_score
	if "neurochemicals" in c and c.neurochemicals:
		var mood := CreatureNeurochemistry.compute_mood(c.neurochemicals)
		c.will_to_live = clamp(
			c.will_to_live + (mood - 0.0) * 0.02 * hour_delta,
			0.1, 1.0
		)
	else:
		c.will_to_live = clamp(
			c.will_to_live - (c.stress_level * 0.04 + c.trauma_level * 0.02) * hour_delta,
			0.1, 1.0
		)


static func _process_mental_break(c: Node2D, hour_delta: float) -> void:
	if c.active_mental_break == Constants.BREAK_NONE:
		# Chemical trigger (new): critical mood or cortisol overload
		var chemical_break := false
		if "neurochemicals" in c and c.neurochemicals:
			var mood := CreatureNeurochemistry.compute_mood(c.neurochemicals)
			var cortisol: float = c.neurochemicals.get("cortisol", 0.0)
			if mood < Constants.MOOD_CRITICAL_THRESHOLD or cortisol > 0.85:
				chemical_break = true

		# Legacy stress/trauma trigger (kept for compatibility)
		var stress_trigger: bool = c.stress_level > 0.75 or c.trauma_level > 0.65

		if (stress_trigger or chemical_break) and randf() < 0.08 * hour_delta:
			var roll := randf()
			if c.personality == 2 or c.mental_disorder == 3:  # AGGRESSIVE / AGGRESSION_DISORDER
				if roll < 0.65:   c.active_mental_break = Constants.BREAK_BERSERK
				elif roll < 0.85: c.active_mental_break = Constants.BREAK_PANIC
				else:             c.active_mental_break = Constants.BREAK_CATATONIC
			elif c.mental_disorder == 2 or c.will_to_live < 0.4:  # DEPRESSION
				if roll < 0.65:   c.active_mental_break = Constants.BREAK_DEPRESSIVE
				else:             c.active_mental_break = Constants.BREAK_CATATONIC
			else:
				c.active_mental_break = [
					Constants.BREAK_DEPRESSIVE, Constants.BREAK_BERSERK,
					Constants.BREAK_CATATONIC,  Constants.BREAK_PANIC
				][randi() % 4]

			c.break_duration = randf_range(4.0, 10.0)
			c._emotion = Constants.EMOTION_ANGER \
					if c.active_mental_break == Constants.BREAK_BERSERK \
					else Constants.EMOTION_PAIN
			c.emotion_intensity = 0.95
			c._interaction_flash_timer = 1.0
			c._interaction_flash_color = Color(1.0, 0.0, 0.0) \
					if c.active_mental_break == Constants.BREAK_BERSERK \
					else Color(0.4, 0.4, 0.4)
			print("Hoshi #%d SUFFERED A MENTAL BREAK: %d" % [
				c.get_meta("creature_id") if c.has_meta("creature_id") else 0,
				c.active_mental_break
			])
	else:
		c.break_duration -= hour_delta
		if c.break_duration <= 0.0:
			c.active_mental_break = Constants.BREAK_NONE
			c.stress_level = 0.25
			c.will_to_live = min(1.0, c.will_to_live + 0.3)
			# Cortisol reset on recovery
			if "neurochemicals" in c and c.neurochemicals:
				c.neurochemicals["cortisol"] = 0.25
				c.neurochemicals["serotonin"] = min(1.0, c.neurochemicals.get("serotonin", 0.3) + 0.2)
		else:
			if c.active_mental_break == Constants.BREAK_DEPRESSIVE:
				if randf() < (Constants.SUICIDE_CHANCE_DAILY / 24.0) * hour_delta:
					c.health = 0.0
					c.life_stage = Constants.LIFE_STAGE_DECEASED
					if not c.get_meta("death_processed", false):
						c.set_meta("death_processed", true)
						c._trigger_death_reactions()
						GameManager.unregister_creature(c)
						print("Hoshi #%d committed suicide due to severe depression." % (
							c.get_meta("creature_id") if c.has_meta("creature_id") else 0
						))
						c.queue_free()
			elif c.active_mental_break == Constants.BREAK_PANIC:
				if randf() < 0.15:
					c._pick_wander_target()


static func _process_needs(c: Node2D, hour_delta: float) -> void:
	var sepsis_count: int = c.get_meta("_sepsis_count", 0)
	var meta_mod = c.genome.get_trait_value(Constants.TRAIT_METABOLISM) if c.genome else 1.0
	var h_rate = Constants.DEPLETION_RATES[Constants.NEED_HUNGER] * meta_mod
	var t_rate = Constants.DEPLETION_RATES[Constants.NEED_THIRST] * meta_mod * 1.2
	var r_rate = Constants.DEPLETION_RATES[Constants.NEED_REST]

	if c.parasitical_infection > 0.0:
		h_rate += 12.0 * c.parasitical_infection
	if sepsis_count > 0:
		t_rate += 18.0 * sepsis_count
		r_rate += 10.0 * sepsis_count
	if c.viral_infection > 0.0:
		r_rate += 8.0 * c.viral_infection

	# Aging: digestion slows but thirst and fatigue worsen
	var af = age_factor(c)
	if af > 0.0:
		h_rate *= lerp(1.0, 0.85, af)   # appetite weakens slightly
		t_rate *= lerp(1.0, 1.25, af)   # kidneys less efficient → dehydrates faster
		r_rate *= lerp(1.0, 1.45, af)   # fatigue accumulates faster (weaker muscles)

	c.hunger = max(0.0, c.hunger - h_rate * hour_delta)
	c.thirst = max(0.0, c.thirst - t_rate * hour_delta)

	var rest_drain = r_rate * (0.4 if c.ai_state == 3 else 1.0)  # REST = 3
	c.fatigue = max(0.0, c.fatigue - rest_drain * hour_delta)
	if c.ai_state == 3:
		c.fatigue = min(100.0, c.fatigue + 4.0 * hour_delta)

	# Adults build repro drive; elders retain weak fertility early, fading to zero
	if c.life_stage == Constants.LIFE_STAGE_ADULT:
		var fert_mod = c.genome.get_trait_value(Constants.TRAIT_FERTILITY) if c.genome else 1.0
		c.repro_drive = min(100.0, c.repro_drive + 12.0 * fert_mod * hour_delta)
	elif c.life_stage == Constants.LIFE_STAGE_ELDER:
		var fert_mod = c.genome.get_trait_value(Constants.TRAIT_FERTILITY) if c.genome else 1.0
		var elder_fert = lerp(0.45, 0.0, af) * fert_mod
		if elder_fert > 0.0:
			c.repro_drive = min(100.0, c.repro_drive + 12.0 * elder_fert * hour_delta)


static func _process_health_damage(c: Node2D, hour_delta: float) -> void:
	var damage := 0.0
	if c.hunger < 25.0:
		var f = (25.0 - c.hunger) / 25.0
		damage += 12.0 * f * f
	if c.thirst < 20.0:
		var f = (20.0 - c.thirst) / 20.0
		damage += 16.0 * f * f

	var regen_mod = c.genome.get_trait_value(Constants.TRAIT_REGENERATION) if c.genome else 1.0
	var regen = Constants.HEALING_RATE_NATURAL * regen_mod
	if c.ai_state == 3:  # REST
		regen = Constants.HEALING_RATE_WITH_REST * regen_mod

	# ── Senescence (aging damage) ─────────────────────────────────────────
	# No hard death age. Instead, once elder, the body accumulates damage:
	#   age 60  → 0 HP/yr senescence
	#   age 80  → ~1.5 HP/yr
	#   age 100 → ~6 HP/yr  (likely to die within a year or two)
	#   age 110+→ ~9 HP/yr  (almost certain death very soon)
	# Additionally, each year past 70 there's a small random "organ failure"
	# chance that spikes health to 0 — mimicking heart attacks, strokes, etc.
	var af = age_factor(c)
	if af > 0.0:
		regen  *= lerp(1.0, 0.30, af)              # regen fades to 30% at peak age
		# Senescence damage: quadratic curve so early old age is gentle
		var senescence = 6.0 * af * af             # 0 at af=0, 6 HP/yr at af=1
		damage += senescence

	# Probabilistic "organ failure" death — chance per year, starts at age 70
	# At 70: ~0.5%/yr, at 85: ~5%/yr, at 100: ~25%/yr, at 110: ~60%/yr
	# LONGEVITY scales the threshold proportionally.
	var longevity = c.genome.get_trait_value(Constants.TRAIT_LONGEVITY) if c.genome else 1.0
	var organ_failure_start = 70.0 * longevity
	if c.life_stage == Constants.LIFE_STAGE_ELDER and c.age_hours > organ_failure_start:
		var years_past_70 = c.age_hours - organ_failure_start
		# Exponential hazard function (Gompertz-style)
		var annual_death_chance = 0.005 * exp(years_past_70 * 0.085)
		annual_death_chance = clamp(annual_death_chance, 0.0, 0.95)
		# Convert annual probability to per-tick probability
		var tick_chance = 1.0 - pow(1.0 - annual_death_chance, hour_delta)
		if randf() < tick_chance:
			# Organ failure — health collapses over a short period
			damage += 999.0  # instant death this tick

	c.health += (regen - damage) * hour_delta
	c.health = clamp(c.health, 0.0, 100.0)

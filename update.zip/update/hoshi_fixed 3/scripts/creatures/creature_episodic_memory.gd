class_name CreatureEpisodicMemory
# Episodic memory system for Hoshi no Ko.
# Replaces the old learned_preferences sliding-average approach.
#
# Biological model:
#   Inspired by the hippocampal episodic memory model and Dwarf Fortress-style
#   thought records. Instead of abstract "preference for food = 0.8", the
#   creature remembers "I found berries at (320, 410), two hours ago, it was
#   very satisfying". Each memory has a valence (good/bad), a location, and
#   decays with time and intelligence.
#
# Key properties:
#   - More intelligent creatures remember more events (larger buffer) and
#     remember them for longer (slower time-decay).
#   - When the buffer fills up, the LEAST SIGNIFICANT event is evicted
#     (not the oldest), preserving traumatic or highly rewarding memories.
#   - query_memory() returns a weighted signal that the AI uses for scoring.
#
# Usage:
#   CreatureEpisodicMemory.record_memory(c, event, location, magnitude, valence)
#   CreatureEpisodicMemory.query_memory(c, event_filter, location, radius) -> float


# ── Record a new memory ───────────────────────────────────────────────────────
static func record_memory(
	c: Node2D,
	event: String,
	location: Vector2,
	magnitude: float,
	valence: float,
	include_chemical_snapshot: bool = false
) -> void:
	if not "episodic_memory" in c:
		return

	var genome = c.get("genome")
	var intel: float = float(genome.get_trait_value(Constants.TRAIT_INTELLIGENCE)) if genome else 1.0
	var max_size := Constants.EPISODIC_MEMORY_BASE_SIZE + int(intel * Constants.EPISODIC_MEMORY_INTEL_BONUS)

	var entry := {
		"event":    event,
		"location": location,
		"magnitude": clamp(magnitude, 0.0, 1.0),
		"valence":  clamp(valence, -1.0, 1.0),
		"time":     c.get("age_hours") if "age_hours" in c else 0.0,
		"chemical_snapshot": {}
	}

	# Optionally snapshot the chemical state at the moment of the event.
	# Allows future analysis of "what was I feeling when this happened?"
	if include_chemical_snapshot and "neurochemicals" in c:
		entry["chemical_snapshot"] = c.neurochemicals.duplicate()

	# Evict least-significant memory if buffer is full
	if c.episodic_memory.size() >= max_size:
		_evict_weakest(c)

	c.episodic_memory.append(entry)


# ── Evict the least significant memory ───────────────────────────────────────
# Significance = magnitude × |valence|. We keep intense experiences regardless
# of age — exactly like real traumatic or highly rewarding memories.
static func _evict_weakest(c: Node2D) -> void:
	if c.episodic_memory.is_empty():
		return
	var weakest_idx := 0
	var weakest_sig := 999.0
	for i in range(c.episodic_memory.size()):
		var mem = c.episodic_memory[i]
		var sig: float = mem.magnitude * abs(mem.valence)
		if sig < weakest_sig:
			weakest_sig = sig
			weakest_idx = i
	c.episodic_memory.remove_at(weakest_idx)


# ── Query memory for a weighted influence signal ──────────────────────────────
# Returns a signed float representing the net remembered experience relevant
# to the query. Positive = past positive experiences nearby; negative = bad.
#
# Parameters:
#   event_filter: "" matches all events; otherwise only exact event type
#   location:     where to centre the spatial search
#   radius:       0 = ignore location; > 0 = only memories within radius pixels
#
# The result is used by CreatureAI to bias state scores:
#   e.g. positive food_found memory near current position → extra SEEK_FOOD score.
static func query_memory(
	c: Node2D,
	event_filter: String,
	location: Vector2,
	radius: float
) -> float:
	if not "episodic_memory" in c:
		return 0.0
	var result := 0.0
	var genome = c.get("genome")
	var intel: float = float(genome.get_trait_value(Constants.TRAIT_INTELLIGENCE)) if genome else 1.0
	var age_hours: float = c.get("age_hours") if "age_hours" in c else 0.0

	for mem in c.episodic_memory:
		if event_filter != "" and mem["event"] != event_filter:
			continue

		# Time-decay: smarter creatures remember for longer
		# (MEMORY_DECAY_HOURS is the half-life at intel=1.0)
		var age: float = age_hours - mem["time"]
		var time_decay := exp(-age / (Constants.MEMORY_DECAY_HOURS * intel))

		# Spatial factor: full weight at same location, zero at edge of radius
		var dist_factor := 1.0
		if radius > 0.0:
			var d := location.distance_to(mem["location"])
			if d > radius:
				continue
			dist_factor = 1.0 - d / radius

		result += mem["magnitude"] * mem["valence"] * time_decay * dist_factor

	return result


# ── Summarise memories for debugging / UI ────────────────────────────────────
static func get_summary(c: Node2D) -> String:
	if not "episodic_memory" in c:
		return "No episodic memory"
	var count: int = c.episodic_memory.size()
	var genome = c.get("genome")
	var intel: float = float(genome.get_trait_value(Constants.TRAIT_INTELLIGENCE)) if genome else 1.0
	var cap := Constants.EPISODIC_MEMORY_BASE_SIZE + int(intel * Constants.EPISODIC_MEMORY_INTEL_BONUS)
	return "%d / %d memories" % [count, cap]

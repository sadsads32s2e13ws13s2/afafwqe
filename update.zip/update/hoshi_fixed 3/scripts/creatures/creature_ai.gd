class_name CreatureAI
# Utility-AI decision system — neurochemistry edition.
# Scoring is now driven by chemical signals rather than direct need-floats.
# Behaviour emerges from the chemical state rather than explicit "if hunger > X" checks.
#
# Design principles:
#   - Each score is proportional to a chemical or combination of chemicals.
#   - The AI never directly reads hunger/thirst as scores — it reads ghrelin/leptin/melatonin.
#   - Episodic memory provides a spatial memory modifier (did food work here before?).
#   - FLEE is a new state triggered by adrenaline threshold, not by a fear emotion flag.
#
# Call: CreatureAI.update(c, delta) from creature_visual._process()

static func update(c: Node2D, delta: float) -> void:
	"""Full AI tick: score states → pick best → execute → move."""
	if c.life_stage == Constants.LIFE_STAGE_EMBRYO:
		return

	var vp: Vector2 = c.get_viewport_rect().size
	var margin: float = 20.0
	var sight: float = 80.0 * (float(c.genome.get_trait_value(Constants.TRAIT_SIGHT_RANGE)) if c.genome else 1.0)
	# Aging: eyesight deteriorates up to 40% by end of life
	if c.life_stage == Constants.LIFE_STAGE_ELDER:
		sight *= lerp(1.0, 0.60, CreaturePhysiology.age_factor(c))

	# HEARING_RANGE: expands threat/enemy detection radius independently of sight
	var hearing: float = 60.0 * (float(c.genome.get_trait_value(Constants.TRAIT_HEARING_RANGE)) if c.genome else 1.0)
	# SMELL_RANGE: expands food search radius (noses find food sight can't see)
	var smell: float = 50.0 * (float(c.genome.get_trait_value(Constants.TRAIT_SMELL_RANGE)) if c.genome else 1.0)

	# Attach ranges to creature for use in execute functions
	c.set_meta("_smell_range", smell)
	c.set_meta("_hearing_range", hearing)

	_score_and_pick_state(c, hearing)
	_execute_state(c, sight, smell)
	_move(c, delta, vp, margin)


# ── State scoring ─────────────────────────────────────────────────────────────
static func _score_and_pick_state(c: Node2D, hearing_range: float) -> void:
	var AIState = c.AIState  # сохраняем ссылку на enum для читаемости
	var old_state: int = c.ai_state
	var nc: Dictionary = c.neurochemicals if c.neurochemicals else {}

	# Initialise all states at 0 (or a small wander baseline)
	var scores: Dictionary = {
		AIState.WANDER:     12.0,  # baseline curiosity drive
		AIState.SEEK_FOOD:   0.0,
		AIState.SEEK_WATER:  0.0,
		AIState.REST:        0.0,
		AIState.SEEK_ENEMY:  0.0,
		AIState.REPRODUCE:   0.0,
		AIState.FLEE:        0.0
	}

	# ── FLEE ─────────────────────────────────────────────────────────────
	# Trigger: adrenaline above a threshold indicates perceived danger.
	# The flee vector is computed from all known enemies within hearing range.
	# We do NOT look at emotion_fear here — the chemical IS the signal.
	var flee_vec: Vector2 = Vector2.ZERO
	if nc.get("adrenaline", 0.0) > 0.35:
		for e in c.known_enemies:
			if not is_instance_valid(e):
				continue
			if e.life_stage == Constants.LIFE_STAGE_DECEASED:
				continue
			var d: float = c.global_position.distance_to(e.global_position)
			if d < hearing_range * 2.5:
				# Weight the flee direction by proximity and threat level
				var threat_weight: float = 1.0 - d / (hearing_range * 2.5)
				flee_vec -= (e.global_position - c.global_position).normalized() * threat_weight
		if flee_vec.length_squared() > 0.01:
			c.set_meta("_flee_vector", flee_vec)
		# Score FLEE proportional to adrenaline — more scared = harder to not flee
		scores[AIState.FLEE] = nc["adrenaline"] * 130.0
		# High adrenaline also suppresses wander (exploration becomes risky)
		scores[AIState.WANDER] *= (1.0 - nc["adrenaline"] * 0.7)

	# ── SEEK_FOOD ────────────────────────────────────────────────────────
	# ghrelin = hunger signal; leptin partially suppresses it (satiety).
	# Net hunger drive: high ghrelin with low leptin = maximum urgency.
	var hunger_chem: float = float(nc.get("ghrelin", 0.5)) * (1.0 - float(nc.get("leptin", 0.5)) * 0.6)
	scores[AIState.SEEK_FOOD] = hunger_chem * 120.0

	# Episodic memory bonus: creature remembers where food was → stronger drive
	var food_memory: float = float(CreatureEpisodicMemory.query_memory(c, "food_found", c.global_position, 200.0))
	scores[AIState.SEEK_FOOD] += food_memory * 30.0

	# Legacy hunger sync (backward compat: creatures that didn't eat at all have hunger→0)
	# Give a small boost if legacy hunger is critically low
	if c.get("hunger") != null and c.hunger < 20.0:
		scores[AIState.SEEK_FOOD] += (20.0 - c.hunger) * 1.5

	# ── SEEK_WATER ───────────────────────────────────────────────────────
	# thirst = satiation (100=hydrated, 0=dying). Only significant below 40%.
	var raw_thirst: float = c.thirst if c.get("thirst") != null else 80.0
	var thirst_score: float = 0.0
	if raw_thirst < 40.0:
		thirst_score = (40.0 - raw_thirst) * 2.5          # 0 at 40% → 100 at 0%
		if raw_thirst < 20.0:
			thirst_score += (20.0 - raw_thirst) * 4.0     # sharp spike: +80 extra at 0%
	# Cortisol nudge — dehydration stress adds modest urgency
	thirst_score += float(nc.get("cortisol", 0.0)) * 15.0
	scores[AIState.SEEK_WATER] = thirst_score
	# Hard override: dying of thirst beats everything except active flee
	if raw_thirst < 10.0:
		scores[AIState.SEEK_WATER] = 350.0

	# ── REST ──────────────────────────────────────────────────────────────
	# Fatigue accumulates during activity. When high, creature must rest.
	# Melatonin drives sleep at night (or when tired). If creature breaks pattern,
	# loss of synchrony raises stress and reduces reproductive desire.
	var fatigue: float = float(nc.get("fatigue", 0.0))
	var melatonin: float = float(nc.get("melatonin", 0.0))
	if fatigue > 0.7 or melatonin > 0.6:
		scores[AIState.REST] = (fatigue * 100.0) + (melatonin * 80.0)
		scores[AIState.WANDER] *= 0.3  # very tired → stop exploring

	# ── SEEK_ENEMY (Hunt) ────────────────────────────────────────────────
	# Testosterone + dopamine drive hunting. Only hunt if not desperate.
	var testosterone: float = float(nc.get("testosterone", 0.3))
	var dopamine: float = float(nc.get("dopamine", 0.5))
	# aggression_factor: AGGRESSIVE personality = 1.6, others = 0.6–1.0
	var aggression_factor: float = 1.6 if c.personality == c.Personality.AGGRESSIVE else 0.8
	if hunger_chem < 0.85 and testosterone > 0.5:
		var hunt_drive: float = dopamine * (testosterone - 0.5) * 140.0
		scores[AIState.SEEK_ENEMY] = hunt_drive * aggression_factor

	# ── REPRODUCE ────────────────────────────────────────────────────────
	# Estrogen + testosterone drive mating. Only strong/healthy can afford babies.
	var estrogen: float = float(nc.get("estrogen", 0.1))
	var repro_drive: float = (estrogen * 60.0 + testosterone * 40.0) * (0.5 if hunger_chem > 0.6 else 1.0)
	if hunger_chem < 0.4 and c.life_stage != Constants.LIFE_STAGE_ELDER:
		scores[AIState.REPRODUCE] = repro_drive

	# ── Final Scoring: Personality modifiers ─────────────────────────────
	# Personality enum: CURIOUS=0, FEARFUL=1, AGGRESSIVE=2, SOCIAL=3, MATERNAL=4, LAZY=5, EXPLORER=6
	# curiosity_factor: 0.0–1.0 (how exploratory is this creature)
	var curiosity_factor: float
	match c.personality:
		c.Personality.CURIOUS, c.Personality.EXPLORER: curiosity_factor = 1.0
		c.Personality.FEARFUL:                          curiosity_factor = 0.2
		c.Personality.LAZY:                             curiosity_factor = 0.3
		_:                                              curiosity_factor = 0.6
	scores[AIState.WANDER] *= (0.5 + curiosity_factor)

	# friendliness_factor: high for SOCIAL/MATERNAL, low for AGGRESSIVE
	var friendliness_factor: float
	match c.personality:
		c.Personality.SOCIAL, c.Personality.MATERNAL: friendliness_factor = 0.9
		c.Personality.AGGRESSIVE:                     friendliness_factor = 0.1
		_:                                            friendliness_factor = 0.5
	scores[AIState.SEEK_ENEMY] *= (1.0 - friendliness_factor)

	# parent_tendency: MATERNAL = very high, SOCIAL = medium, others low
	var parent_factor: float
	match c.personality:
		c.Personality.MATERNAL: parent_factor = 0.9
		c.Personality.SOCIAL:   parent_factor = 0.55
		_:                      parent_factor = 0.3
	scores[AIState.REPRODUCE] *= (0.3 + parent_factor)

	# Pick the state with the highest score
	var max_score: float = 0.0
	var best_state: int = AIState.WANDER
	for state in scores:
		if scores[state] > max_score:
			max_score = scores[state]
			best_state = state

	c.ai_state = best_state


# ── State execution ───────────────────────────────────────────────────────────
static func _execute_state(c: Node2D, sight_range: float, smell_range: float) -> void:
	# AIState enum: WANDER=0, SEEK_FOOD=1, SEEK_WATER=2, REST=3,
	#               SEEK_ENEMY=4, REPRODUCE=5, FLEE=6
	match c.ai_state:
		0:  # AIState.WANDER
			_wander(c)
		1:  # AIState.SEEK_FOOD
			_seek_food(c, sight_range, smell_range)
		2:  # AIState.SEEK_WATER
			_seek_water(c, sight_range)
		3:  # AIState.REST
			_rest(c)
		4:  # AIState.SEEK_ENEMY
			_seek_enemy(c, sight_range)
		5:  # AIState.REPRODUCE
			_reproduce(c, sight_range)
		6:  # AIState.FLEE
			_flee(c)
		_:
			_wander(c)


static func _wander(c: Node2D) -> void:
	"""Random walk with inertia."""
	if randf() < 0.05:  # 5% chance each frame to pick a new direction
		c.move_dir = Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized()


static func _seek_food(c: Node2D, sight: float, smell: float) -> void:
	"""Forage for food: check episodic memory, then scan for food items."""
	# First priority: use episodic memory signal to bias toward known food spots
	var food_signal: float = CreatureEpisodicMemory.query_memory(c, "food_found", c.global_position, smell)
	if food_signal > 0.3 and c.get("episodic_memory") != null:
		var best_mem: Variant = null
		var best_score: float = -999.0
		for mem in c.episodic_memory:
			if mem.get("event") == "food_found" and mem.get("valence", 0.0) > 0.0:
				var mem_score: float = float(mem.get("magnitude", 0.0)) * float(mem.get("valence", 0.0))
				if mem_score > best_score:
					best_score = mem_score
					best_mem = mem
		if best_mem != null:
			var food_pos: Vector2 = best_mem.get("location", Vector2.ZERO)
			if food_pos != Vector2.ZERO and c.global_position.distance_to(food_pos) > 10.0:
				c.move_dir = (food_pos - c.global_position).normalized()
				return

	# Second: scan for visible food items within sight range
	var nearest_food: Vector2 = Vector2.INF
	var nearest_dist: float = sight
	for food in c.get_tree().get_nodes_in_group("food"):
		if not is_instance_valid(food):
			continue
		var d: float = c.global_position.distance_to(food.global_position)
		if d < nearest_dist:
			nearest_dist = d
			nearest_food = food.global_position

	if nearest_food != Vector2.INF:
		c.move_dir = (nearest_food - c.global_position).normalized()
	else:
		_wander(c)


static func _seek_water(c: Node2D, sight: float) -> void:
	"""Move toward the nearest water source.
	Priority: (1) water nodes in group, (2) world.get_nearest_water_pos(),
	(3) wander. Also drink when close enough."""

	var nearest_water: Vector2 = Vector2.INF
	var nearest_dist: float = INF

	# First: scan "water" group (placed water items like water_drop food)
	for water in c.get_tree().get_nodes_in_group("water"):
		if not is_instance_valid(water):
			continue
		var d: float = c.global_position.distance_to(water.global_position)
		if d < nearest_dist:
			nearest_dist = d
			nearest_water = water.global_position

	# Second: use world's permanent water source if no group node found nearby
	if nearest_water == Vector2.INF or nearest_dist > sight:
		var world = c.get_tree().get_first_node_in_group("world")
		if world and world.has_method("get_nearest_water_pos"):
			var wp: Vector2 = world.get_nearest_water_pos(c.global_position)
			if wp != Vector2.ZERO:
				var d: float = c.global_position.distance_to(wp)
				if d < nearest_dist:
					nearest_dist = d
					nearest_water = wp

	if nearest_water != Vector2.INF:
		# Only move toward water when thirst is meaningfully low
		var cur_thirst: float = c.thirst if c.get("thirst") != null else 80.0
		if cur_thirst < 70.0:
			c.move_dir = (nearest_water - c.global_position).normalized()
		else:
			_wander(c)  # sated — leave water area

		# Drink when close enough
		if nearest_dist < 50.0 and c.get("thirst") != null and c.thirst < 95.0:
			var fill: float = 75.0 * c.get_process_delta_time() if c.has_method("get_process_delta_time") else 0.5
			c.thirst = minf(100.0, c.thirst + fill)
			if c.thirst >= 92.0:
				CreatureNeurochemistry.apply_event(c, "water_drunk", 1.0)
				CreatureEpisodicMemory.record_memory(
					c, "water_found", nearest_water, 0.9, 1.0)
	else:
		_wander(c)


static func _rest(c: Node2D) -> void:
	"""Stop moving."""
	c.move_dir = Vector2.ZERO


static func _seek_enemy(c: Node2D, sight: float) -> void:
	"""Hunt nearby prey."""
	var nearest_prey: Vector2 = Vector2.INF
	var nearest_dist: float = sight
	# Scan for creatures with prey_type in known_enemies
	for enemy in c.known_enemies:
		if not is_instance_valid(enemy):
			continue
		if enemy.life_stage == Constants.LIFE_STAGE_DECEASED:
			continue
		# Hunt any non-same-type creature (CREATURE_HERBIVORE not defined; use type != self)
		if enemy.get("creature_type") == c.get("creature_type"):
			continue
		var d: float = c.global_position.distance_to(enemy.global_position)
		if d < nearest_dist:
			nearest_dist = d
			nearest_prey = enemy.global_position

	if nearest_prey != Vector2.INF:
		c.move_dir = (nearest_prey - c.global_position).normalized()
	else:
		_wander(c)


static func _reproduce(c: Node2D, sight: float) -> void:
	"""Search for a mate (same species, fertile, within sight)."""
	# Scan known_enemies for other creatures of same type and life stage
	var nearest_mate: Vector2 = Vector2.INF
	var nearest_dist: float = sight
	for other in c.known_enemies:
		if not is_instance_valid(other):
			continue
		if other == c:
			continue
		if other.creature_type != c.creature_type:
			continue
		if other.life_stage == Constants.LIFE_STAGE_EMBRYO or other.life_stage == Constants.LIFE_STAGE_ELDER:
			continue
		var d: float = c.global_position.distance_to(other.global_position)
		if d < nearest_dist and d < sight:
			nearest_dist = d
			nearest_mate = other.global_position

	if nearest_mate != Vector2.INF:
		c.move_dir = (nearest_mate - c.global_position).normalized()
	else:
		_wander(c)


static func _flee(c: Node2D) -> void:
	"""Move in the flee direction (pre-computed in _score_and_pick_state)."""
	var flee_vec: Vector2 = c.get_meta("_flee_vector", Vector2.ZERO)
	if flee_vec.length_squared() > 0.01:
		c.move_dir = flee_vec.normalized()
	else:
		# Fallback: wander if no flee direction set
		_wander(c)


# ── Movement ──────────────────────────────────────────────────────────────────
static func _move(c: Node2D, delta: float, vp: Vector2, margin: float) -> void:
	"""Update velocity and enforce bounds."""
	var AIState = c.AIState
	var speed: float = 40.0  # pixels per second

	# Emotional state modulation
	match c.active_mental_break:
		Constants.BREAK_CATATONIC:  speed = 0.0
		Constants.BREAK_DEPRESSIVE: speed *= 0.5
		Constants.BREAK_PANIC:      speed *= 1.6
		Constants.BREAK_BERSERK:    speed *= 1.4

	# FLEE: adrenaline-boosted sprint
	if c.ai_state == AIState.FLEE:
		var adr: float = float(c.neurochemicals.get("adrenaline", 0.5)) if c.neurochemicals else 0.5
		speed *= 1.4 + adr * 0.4  # up to 1.8× at full adrenaline

	if c.ai_state in [AIState.SEEK_FOOD, AIState.SEEK_WATER]:
		var urgency: float = 2.2 if (c.hunger < 25.0 or c.thirst < 25.0) else 1.8
		speed *= urgency
	if c.ai_state == AIState.REST:
		speed = 0.0
	if c.life_stage == Constants.LIFE_STAGE_EMBRYO:
		speed = 0.0
	if c.life_stage == Constants.LIFE_STAGE_ELDER:
		speed *= lerp(1.0, 0.65, CreaturePhysiology.age_factor(c))

	if c.ai_state != AIState.REST:
		c.position += c.move_dir * speed * delta
		if c.move_dir.x != 0:
			c.facing_right = c.move_dir.x > 0

		var ground_y: float = vp.y * 0.72
		if c.position.y > ground_y - 5:
			c.position.y = ground_y - 8 + sin(c._bob_phase) * 1.5
		if c.position.y < ground_y - 55:
			c.position.y = ground_y - 55

	if c.position.x < margin or c.position.x > vp.x - margin:
		c.move_dir.x *= -1
		c.position.x = clamp(c.position.x, margin, vp.x - margin)
	if c.position.y < margin or c.position.y > vp.y - margin:
		c.move_dir.y *= -1
		c.position.y = clamp(c.position.y, margin, vp.y - margin)

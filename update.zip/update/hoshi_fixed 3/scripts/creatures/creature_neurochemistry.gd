class_name CreatureNeurochemistry
# Chemical state machine.
#
# Neurochemicals represent transient signals in the creature's "brain". They vary
# from 0.0 (absent) to 1.0 (extreme). Each chemical has a decay rate; some are
# boosted by events (hunger → ghrelin, fear → adrenaline) or social cues.
#
# Chemicals do NOT directly set behaviour. Instead, they are read by utility-AI
# scoring in CreatureAI, which uses them as inputs to state utility scores.
#
# Key assumption: neurochemical state is a compressed representation of
# the creature's internal world—what it feels, not what it does.
#
# Update (hourly delta via CreaturePhysiology._tick_neurochemistry):
#   1. Apply decay to all baseline chemicals (they naturally fade to 0).
#   2. Apply boosts from physiology (hunger → ghrelin, fatigue → melatonin).
#   3. Model chemical interactions (high cortisol suppresses serotonin).
#   4. Apply genome modifiers (genes affect baseline levels, sensitivity).
#   5. Clamp all to [0, 1].
#   6. Sync back to legacy physiology variables (hunger/thirst/fatigue floats).

static func tick(c: Node2D, hour_delta: float) -> void:
	"""Update neurochemical state once per physiological tick."""
	# Ensure creature has neurochemical state
	if not c.has_meta("neurochemicals"):
		c.set_meta("neurochemicals", {
			"dopamine":   0.5,
			"serotonin":  0.6,
			"cortisol":   0.1,
			"adrenaline": 0.0,
			"melatonin":  0.3,
			"ghrelin":    0.5,
			"leptin":     0.5,
			"oxytocin":   0.2,
			"endorphin":  0.1,
			"testosterone": 0.3,
			"estrogen":   0.1,
			"fatigue":    0.0,
			"boredom":    0.2
		})

	var nc: Dictionary = c.neurochemicals

	# ── 1. Decay: natural fade-out ────────────────────────────────────────
	# Each chemical has a half-life; apply decay based on global rates
	for chem in Constants.NEURO_CHEMICALS:
		var decay_rate: float = float(Constants.NEURO_DECAY_RATES.get(chem, 0.01))
		nc[chem] *= pow(0.5, decay_rate * hour_delta)

	# ── 2. Physiology → Neurochemistry boost ──────────────────────────────
	# Map primary drives (hunger, fatigue, age) to neuro signals.

	# HUNGER → GHRELIN (hunger hormone)
	# hunger is a SATIATION variable: 100=full, 0=starving.
	# Ghrelin is HIGH when STARVING, LOW when FULL. Hence the inversion.
	if c.get("hunger") != null:
		var hunger_norm: float = clamp(float(c.hunger) / 100.0, 0.0, 1.0)
		var ghrelin_target: float = 1.0 - hunger_norm * 0.8  # starving→1.0, full→0.2
		nc["ghrelin"] = lerp(nc["ghrelin"], ghrelin_target, 0.05 * hour_delta)
		# Leptin (satiety): HIGH when full, LOW when starving
		var leptin_target: float = 0.2 + hunger_norm * 0.8
		nc["leptin"] = lerp(nc["leptin"], leptin_target, 0.04 * hour_delta)

	# THIRST → (no dedicated thirst chemical; instead boost cortisol slightly)
	if c.get("thirst") != null and c.thirst > 75.0:
		nc["cortisol"] += 0.15 * hour_delta

	# FATIGUE → MELATONIN + decreased dopamine
	if c.get("fatigue") != null:
		var fatigue_norm: float = clamp(float(c.fatigue) / 100.0, 0.0, 1.0)
		nc["melatonin"] = lerp(nc["melatonin"], fatigue_norm, 0.08 * hour_delta)
		nc["dopamine"] *= (1.0 - fatigue_norm * 0.4)

	# TIME OF DAY: (if tracking day/night)
	# Melatonin surges at night (SIMPLE model: assume night is hours 20-6 of 24-hour cycle)
	# This is basic; a real model would use the actual time_of_day float if available.
	if c.get("_day_phase") != null:
		var day_phase: float = float(c._day_phase)  # 0.0 = midnight, 0.5 = noon
		var is_night: bool = day_phase < 0.25 or day_phase > 0.75
		if is_night:
			nc["melatonin"] += 0.10 * hour_delta

	# WOUNDS → ENDORPHIN (pain relief), CORTISOL (stress from injury)
	if c.get("integrity") != null and c.integrity < 100.0:
		var injury_severity: float = (100.0 - float(c.integrity)) / 100.0
		nc["endorphin"] += injury_severity * 0.20 * hour_delta
		nc["cortisol"] += injury_severity * 0.25 * hour_delta

	# AGE → testosterone/estrogen shifts (juvenile→adult→elder)
	# NOTE: age is stored in age_hours (game years), not "age".
	# Peaks in adult stage (~18–60 yrs), drops in elder.
	if c.get("age_hours") != null:
		var age_years: float = float(c.age_hours)  # age_hours IS in game-years
		var repro_age: float = clamp(age_years / 5.0, 0.0, 1.0)  # 0-5 yrs = development
		var repro_curve: float = sin(repro_age * PI) * 0.8 + 0.2  # peaks mid-life
		nc["testosterone"] = clamp(0.3 + repro_curve * 0.5, 0.0, 1.0)
		nc["estrogen"]     = clamp(0.1 + repro_curve * 0.3, 0.0, 1.0)

	# ── 3. Chemical interactions (Mood state machine) ─────────────────────
	# High stress suppresses serotonin, dopamine, oxytocin.
	# High boredom boosts dopamine seeking (paradox: boredom makes reward more salient).
	# High melatonin suppresses dopamine.
	# Hunger suppresses oxytocin (antisocial when desperate).

	var cortisol: float = nc["cortisol"]
	var dopamine: float = nc["dopamine"]
	var serotonin: float = nc["serotonin"]

	# Stress suppression effect
	nc["serotonin"] *= (1.0 - cortisol * 0.6)
	nc["oxytocin"] *= (1.0 - cortisol * 0.5)
	nc["dopamine"] = lerp(nc["dopamine"], dopamine * (1.0 - cortisol * 0.4), 0.02)

	# Boredom effect: paradoxical dopamine boost (seeking stimulation)
	if nc["boredom"] > 0.5:
		nc["dopamine"] = lerp(nc["dopamine"], 0.7, nc["boredom"] * 0.15 * hour_delta)

	# Sleep (melatonin) suppresses daytime wakefulness chemicals
	if nc["melatonin"] > 0.6:
		nc["dopamine"] *= 0.7
		nc["adrenaline"] *= 0.5

	# Estrogen/testosterone modulation of mood (hormonal affinity)
	if nc["estrogen"] > 0.4:
		nc["oxytocin"] += 0.08 * hour_delta  # estrogen → bonding

	# Heavy hunger suppresses social bonding
	if nc["ghrelin"] > 0.7:
		nc["oxytocin"] *= (1.0 - nc["ghrelin"] * 0.5)

	# Low satiety (high ghrelin, low leptin) = high cortisol risk
	if nc["leptin"] < 0.2:
		nc["ghrelin"] += 0.10 * hour_delta

	# ── 4. Genome modifier adjustments ────────────────────────────────────
	# Apply per-chemical sensitivity/baseline mods after interactions.
	# These model how DNA affects receptor density and enzyme expression.

	# Serotonin baseline from regeneration trait (healthy physiology → better serotonin)
	var serotonin_target: float = float(get_mods(c).get("serotonin_baseline", 0.5))
	# Gentle pull toward genetic baseline — not a hard set
	nc["serotonin"] = lerp(nc["serotonin"], max(nc["serotonin"], serotonin_target * 0.4), 0.01 * hour_delta)

	# Boredom accumulation rate scales inversely with intelligence
	# (intelligent creatures find stimulation more easily)
	nc["boredom"] += float(get_mods(c).get("boredom_rate", 1.0)) * float(Constants.NEURO_DECAY_RATES.get("boredom", 0.01)) * 0.15 * hour_delta

	# ── 5. Clamp everything ───────────────────────────────────────────────
	for chem in Constants.NEURO_CHEMICALS:
		nc[chem] = clamp(float(nc[chem]), 0.0, 1.0)

	# ── 6. Sync legacy variables (backward-compat) ────────────────────────
	# hunger/thirst/fatigue are kept as canonical physiology drivers.
	# Here we nudge them based on chemistry — they do NOT replace each other.
	# ghrelin/leptin provide a second signal on top of the existing hunger float.
	# This creates interesting divergence: a sick creature can have high ghrelin
	# but the legacy hunger variable may still be moderate.
	# The AI reads chemistry, not physiology—so divergence creates complex behaviour.

	# Hunger sync: ghrelin/leptin are READ by the AI but do NOT modify the
	# legacy hunger float — physiology already depletes it via metabolism.
	# (Removing bidirectional sync prevents ghrelin from fighting metabolism.)

	# Fatigue: when melatonin rises, creature naturally gets tired
	if c.get("fatigue") != null:
		var melatonin_fatigue: float = nc["melatonin"] * 10.0
		c.fatigue += melatonin_fatigue * hour_delta
		c.fatigue = clamp(float(c.fatigue), 0.0, 100.0)

	# Stress feedback: high cortisol boosts fatigue (stress exhausts)
	if nc["cortisol"] > 0.5:
		c.fatigue += nc["cortisol"] * 5.0 * hour_delta

	# ── 7. Emotional state ────────────────────────────────────────────────
	# Compute aggregate mood from chemical state.
	var mood: float = compute_mood(nc)
	c.set_meta("mood", mood)

	# Mental breaks trigger on extreme mood + other factors
	_check_mental_break(c, nc)


# ── Mood Aggregate ────────────────────────────────────────────────────────────
# Single aggregate valence: −1.0 (extreme distress) to +1.0 (euphoric).
# Weights reflect each chemical's net hedonic contribution.
# Positive pool: serotonin (40%) dominates since it is the most stable well-being
# signal; dopamine (30%) is more volatile; endorphin (20%) is pain relief;
# oxytocin (10%) adds social warmth.
# Negative pool: cortisol (50%) is the primary stress driver; adrenaline (30%)
# adds acute arousal penalty; boredom (20%) contributes low-grade dissatisfaction.
static func compute_mood(nc: Dictionary) -> float:
	var positive: float = float(nc.get("dopamine",  0.3)) * 0.30 \
				  + float(nc.get("serotonin", 0.6)) * 0.40 \
				  + float(nc.get("endorphin", 0.1)) * 0.20 \
				  + float(nc.get("oxytocin",  0.2)) * 0.10
	var negative: float = float(nc.get("cortisol",   0.1)) * 0.50 \
				  + float(nc.get("adrenaline", 0.0)) * 0.30 \
				  + float(nc.get("boredom",    0.2)) * 0.20
	return clamp(positive - negative, -1.0, 1.0)


# ── Genome → neuro modifier map ──────────────────────────────────────────────
# Called once per tick to build an ephemeral modifier dictionary.
# These model genetic differences in receptor density and enzymatic efficiency.
static func get_mods(c: Node2D) -> Dictionary:
	"""Compute neurochemical modifiers from genome."""
	var mods: Dictionary = {}

	if not c.genome:
		return mods

	# Regeneration trait → better baseline serotonin (health leads to contentment)
	var regen: float = float(c.genome.get_trait_value(Constants.TRAIT_REGENERATION))
	mods["serotonin_baseline"] = 0.4 + regen * 0.4

	# Strength trait → higher testosterone baseline
	# (TRAIT_AGGRESSION не существует; физическая сила — ближайший прокси агрессии)
	var agg: float = float(c.genome.get_trait_value(Constants.TRAIT_STRENGTH))
	mods["testosterone_baseline"] = 0.2 + agg * 0.6

	# Intelligence → lower boredom accumulation (smarter creatures stay engaged)
	var intel: float = float(c.genome.get_trait_value(Constants.TRAIT_INTELLIGENCE))
	mods["boredom_rate"] = 1.0 - intel * 0.6

	return mods


# ── Mental break state machine ────────────────────────────────────────────────
# A creature enters a mental break when mood becomes extreme for a prolonged time.
# Types: CATATONIC (shutdown), DEPRESSIVE (low energy), PANIC (hypervigilance), BERSERK (rage).
# Breaks are _not_ permanent—recovery depends on chemical state returning to normal.
#
# Duration: ~5 minutes per in-game hour (arbitrary, but means a creature doesn't
# recover instantly; they need time and a reason to feel better).
static func _check_mental_break(c: Node2D, nc: Dictionary) -> void:
	if not c.has_meta("mood_history"):
		c.set_meta("mood_history", [])
	if not c.has_meta("break_timer"):
		c.set_meta("break_timer", 0.0)

	var mood: float = compute_mood(nc)
	var history: Array = c.get_meta("mood_history")
	history.append(mood)
	if history.size() > 10:  # Keep last 10 ticks
		history.pop_front()

	var break_timer: float = float(c.get_meta("break_timer", 0.0))

	# Average mood over history
	var avg_mood: float = 0.0
	for m in history:
		avg_mood += float(m)
	avg_mood /= max(1, history.size())

	# Trigger conditions
	if avg_mood < -0.8:
		if break_timer < 3.0:
			break_timer += 1.0
		if break_timer >= 3.0:
			c.active_mental_break = Constants.BREAK_DEPRESSIVE
	elif avg_mood < -0.6 and nc["cortisol"] > 0.8:
		if break_timer < 2.0:
			break_timer += 1.0
		if break_timer >= 2.0:
			c.active_mental_break = Constants.BREAK_CATATONIC
	elif avg_mood > 0.85 and nc["adrenaline"] > 0.7:
		if break_timer < 2.0:
			break_timer += 1.0
		if break_timer >= 2.0:
			c.active_mental_break = Constants.BREAK_PANIC
	elif avg_mood < -0.5 and nc["testosterone"] > 0.8:
		if break_timer < 3.0:
			break_timer += 1.0
		if break_timer >= 3.0:
			c.active_mental_break = Constants.BREAK_BERSERK
	else:
		# Recovery
		if break_timer > 0.0:
			break_timer -= 0.5
		if break_timer <= 0.0:
			c.active_mental_break = Constants.BREAK_NONE
			break_timer = 0.0

	c.set_meta("break_timer", break_timer)
	c.set_meta("mood_history", history)


# ── init_neurochemicals ───────────────────────────────────────────────────────
# Called once from creature_visual._ready() to initialise the chemical dict.
static func init_neurochemicals(c: Node2D) -> void:
	c.neurochemicals = {
		"dopamine":     0.5,
		"serotonin":    0.6,
		"cortisol":     0.1,
		"adrenaline":   0.0,
		"melatonin":    0.3,
		"ghrelin":      0.5,
		"leptin":       0.5,
		"oxytocin":     0.2,
		"endorphin":    0.1,
		"testosterone": 0.3,
		"estrogen":     0.1,
		"fatigue":      0.0,
		"boredom":      0.2
	}


# ── apply_event ───────────────────────────────────────────────────────────────
# Applies a named neurochemical event to a creature.
# event_type maps to specific chemical boosts / suppressions.
# magnitude is 0.0–1.0 and scales the effect.
static func apply_event(c: Node2D, event_type: String, magnitude: float) -> void:
	if not c.get("neurochemicals"):
		return
	var nc: Dictionary = c.neurochemicals
	var m: float = clamp(magnitude, 0.0, 1.0)

	match event_type:
		"food_eaten":
			nc["dopamine"]  = clamp(nc["dopamine"]  + 0.3 * m, 0.0, 1.0)
			nc["serotonin"] = clamp(nc["serotonin"] + 0.2 * m, 0.0, 1.0)
			nc["ghrelin"]   = clamp(nc["ghrelin"]   - 0.4 * m, 0.0, 1.0)
			nc["leptin"]    = clamp(nc["leptin"]    + 0.3 * m, 0.0, 1.0)
		"water_drunk":
			nc["dopamine"]  = clamp(nc["dopamine"]  + 0.2 * m, 0.0, 1.0)
			nc["cortisol"]  = clamp(nc["cortisol"]  - 0.2 * m, 0.0, 1.0)
		"attacked":
			nc["adrenaline"] = clamp(nc["adrenaline"] + 0.5 * m, 0.0, 1.0)
			nc["cortisol"]   = clamp(nc["cortisol"]   + 0.3 * m, 0.0, 1.0)
		"wound_received":
			nc["endorphin"]  = clamp(nc["endorphin"]  + 0.4 * m, 0.0, 1.0)
			nc["cortisol"]   = clamp(nc["cortisol"]   + 0.2 * m, 0.0, 1.0)
			nc["adrenaline"] = clamp(nc["adrenaline"] + 0.3 * m, 0.0, 1.0)
		"successfully_fled":
			nc["adrenaline"] = clamp(nc["adrenaline"] - 0.2 * m, 0.0, 1.0)
			nc["dopamine"]   = clamp(nc["dopamine"]   + 0.2 * m, 0.0, 1.0)
			nc["cortisol"]   = clamp(nc["cortisol"]   - 0.1 * m, 0.0, 1.0)
		"mate_found":
			nc["dopamine"]      = clamp(nc["dopamine"]      + 0.4 * m, 0.0, 1.0)
			nc["oxytocin"]      = clamp(nc["oxytocin"]      + 0.5 * m, 0.0, 1.0)
			nc["testosterone"]  = clamp(nc["testosterone"]  - 0.1 * m, 0.0, 1.0)
			nc["estrogen"]      = clamp(nc["estrogen"]      - 0.1 * m, 0.0, 1.0)
		"social_touch":
			nc["oxytocin"]  = clamp(nc["oxytocin"]  + 0.3 * m, 0.0, 1.0)
			nc["cortisol"]  = clamp(nc["cortisol"]  - 0.1 * m, 0.0, 1.0)
			nc["serotonin"] = clamp(nc["serotonin"] + 0.1 * m, 0.0, 1.0)
		_:
			# Generic positive/negative event based on sign of magnitude
			if m > 0.0:
				nc["dopamine"] = clamp(nc["dopamine"] + 0.15 * m, 0.0, 1.0)
			else:
				nc["cortisol"] = clamp(nc["cortisol"] + 0.15 * abs(m), 0.0, 1.0)

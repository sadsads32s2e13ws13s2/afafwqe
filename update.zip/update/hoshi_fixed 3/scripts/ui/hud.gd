extends CanvasLayer
# HUD — time, population, selected creature needs

var selected_creature: Node2D = null
# FIX: removed local `game_time` float that accumulated independently of
# GameManager.game_time_hours, causing the two clocks to diverge.
# All time display now reads directly from GameManager.

var _time_lbl: Label
var _pop_lbl: Label
var _pause_lbl: Label
var _biome_lbl: Label

# Creature panel labels
var _name_lbl: Label
var _stage_lbl: Label
var _health_lbl: Label
var _hunger_lbl: Label
var _thirst_lbl: Label
var _fatigue_lbl: Label
var _age_lbl: Label
var _state_lbl: Label
var _genome_lbl: Label

# Psyche labels
var _emotion_lbl: Label
var _personality_lbl: Label
var _trauma_lbl: Label
var _will_lbl: Label
var _social_lbl: Label
var _mem_lbl: Label
var _stress_lbl: Label
var _break_lbl: Label
var _sick_lbl: Label
var _wounds_lbl: Label

const STAGE_NAMES = ["🥚 Embryo","🌱 Juvenile","🌸 Adult","🌙 Elder","💀 Deceased"]
const STATE_ICONS = {
	0: "🌀 Wandering",    # AIState.WANDER
	1: "🍓 Seeking Food", # AIState.SEEK_FOOD
	2: "💧 Seeking Water",# AIState.SEEK_WATER
	3: "😴 Resting",      # AIState.REST
	4: "⚔️ Hunting",      # AIState.SEEK_ENEMY
	5: "💕 Seeking Mate", # AIState.REPRODUCE
}

func init_refs() -> void:
	var tp = get_node_or_null("TimePanel")
	if tp:
		_time_lbl = tp.get_node_or_null("VBoxContainer/TimeLabel")
		if not _time_lbl:
			_time_lbl = tp.find_child("TimeLabel", true, false)
		_pop_lbl  = tp.get_node_or_null("VBoxContainer/PopLabel")
		if not _pop_lbl:
			_pop_lbl = tp.find_child("PopLabel", true, false)

	var cp = get_node_or_null("CreaturePanel")
	if cp:
		var vb = cp.get_node_or_null("VBox")
		if vb:
			_name_lbl   = vb.get_node_or_null("NameLabel")
			_stage_lbl  = vb.get_node_or_null("StageLabel")
			_health_lbl = vb.get_node_or_null("HealthLabel")
			_hunger_lbl = vb.get_node_or_null("HungerLabel")
			_thirst_lbl = vb.get_node_or_null("ThirstLabel")
			_fatigue_lbl= vb.get_node_or_null("FatigueLabel")
			_age_lbl    = vb.get_node_or_null("AgeLabel")
			_state_lbl  = vb.get_node_or_null("StateLabel")
			_genome_lbl = vb.get_node_or_null("GenomeLabel")
			_emotion_lbl    = vb.get_node_or_null("EmotionLabel")
			_personality_lbl= vb.get_node_or_null("PersonalityLabel")
			_trauma_lbl     = vb.get_node_or_null("TraumaLabel")
			_will_lbl       = vb.get_node_or_null("WillLabel")
			_stress_lbl     = vb.get_node_or_null("StressLabel")
			_break_lbl      = vb.get_node_or_null("BreakLabel")
			_sick_lbl       = vb.get_node_or_null("SickLabel")
			_wounds_lbl     = vb.get_node_or_null("WoundsLabel")
			_social_lbl     = vb.get_node_or_null("SocialLabel")
			_mem_lbl        = vb.get_node_or_null("MemoryLabel")

	_pause_lbl = get_node_or_null("PauseOverlay")
	_biome_lbl = get_node_or_null("BiomeLabel")
	if _pause_lbl:
		_pause_lbl.visible = false

func _process(_delta: float) -> void:
	if GameManager.is_paused:
		if _pause_lbl: _pause_lbl.visible = true
		return
	if _pause_lbl: _pause_lbl.visible = false

	# FIX: read canonical time from GameManager — no local accumulation
	var total_game_hours = GameManager.game_time_hours
	var day = int(total_game_hours / 24) + 1
	var hour = int(total_game_hours) % 24
	var minute = int((total_game_hours - int(total_game_hours)) * 60)
	if _time_lbl:
		_time_lbl.text = "⏱ Day %d  %02d:%02d" % [day, hour, minute]
	if _pop_lbl:
		_pop_lbl.text = "Population: %d" % GameManager.creatures.size()

	# Selected creature info
	if is_instance_valid(selected_creature) and \
			selected_creature.life_stage != Constants.LIFE_STAGE_DECEASED:
		_update_creature_panel(selected_creature)
	else:
		selected_creature = null

func _update_creature_panel(c: Node2D) -> void:
	var cid = c.get_meta("creature_id") if c.has_meta("creature_id") else 0
	if _name_lbl:
		_name_lbl.text = "Hoshi #%04d" % cid
	if _stage_lbl:
		_stage_lbl.text = STAGE_NAMES[c.life_stage] if c.life_stage < STAGE_NAMES.size() else ""
	if _health_lbl:
		var hp = int(c.health)
		var col = Color(0.50, 0.95, 0.55) if hp > 60 else (Color(1.0, 0.8, 0.2) if hp > 30 else Color(0.95, 0.35, 0.35))
		_health_lbl.add_theme_color_override("font_color", col)
		_health_lbl.text = "❤ Health: %d%%" % hp
	if _hunger_lbl:
		var h = int(c.hunger)
		_hunger_lbl.text = "🍓 Hunger: %d%%" % h
		_hunger_lbl.add_theme_color_override("font_color",
			Color(1.0, 0.75, 0.40) if h > 30 else Color(1.0, 0.35, 0.35))
	if _thirst_lbl:
		var t = int(c.thirst)
		_thirst_lbl.text = "💧 Thirst: %d%%" % t
		_thirst_lbl.add_theme_color_override("font_color",
			Color(0.45, 0.80, 1.00) if t > 30 else Color(1.0, 0.35, 0.35))
	if _fatigue_lbl:
		var f = int(c.fatigue)
		_fatigue_lbl.text = "😴 Rest: %d%%" % f
		_fatigue_lbl.add_theme_color_override("font_color",
			Color(0.75, 0.55, 0.95) if f > 30 else Color(1.0, 0.35, 0.35))
	if _age_lbl:
		_age_lbl.text = "🕐 Age: %.1f hrs" % c.age_hours
	if _state_lbl and c.has_method("get") and c.get("ai_state") != null:
		var s = c.ai_state as int
		_state_lbl.text = STATE_ICONS.get(s, "🌀 Wandering")
	if _genome_lbl and c.genome:
		var spd = "%.2f" % c.genome.get_trait_value(Constants.TRAIT_SPEED)
		var str2 = "%.2f" % c.genome.get_trait_value(Constants.TRAIT_STRENGTH)
		var intel = "%.2f" % c.genome.get_trait_value(Constants.TRAIT_INTELLIGENCE)
		_genome_lbl.text = "Spd:%s Str:%s Int:%s" % [spd, str2, intel]

	# === Psyche Information (Deep Life Simulation) ===
	if _emotion_lbl:
		var emo_names = ["Fear", "Anger", "Curiosity", "Contentment", "Pain", "Excitement", "Love", "Embarrassment"]
		var emo = c.get("_emotion") if c.has_method("get") else 3
		var inten = c.get("emotion_intensity") if c.has_method("get") else 0.5
		_emotion_lbl.text = "😊 %s (%.0f%%)" % [emo_names[emo] if emo < emo_names.size() else "Unknown", inten * 100]

	if _personality_lbl:
		var pers_names = ["Curious", "Fearful", "Aggressive", "Social", "Maternal", "Lazy", "Explorer"]
		var pers = c.get("personality") if c.has_method("get") else 0
		_personality_lbl.text = "🔍 %s" % (pers_names[pers] if pers < pers_names.size() else "Unknown")

	if _trauma_lbl:
		var tr = c.get("trauma_level") if c.has_method("get") else 0.0
		_trauma_lbl.text = "💔 Trauma: %.0f%%" % (tr * 100)

	if _will_lbl:
		var wl = c.get("will_to_live") if c.has_method("get") else 1.0
		_will_lbl.text = "❤️ Will to Live: %.0f%%" % (wl * 100)

	if _stress_lbl:
		var stress = c.get("stress_level") if "stress_level" in c else 0.0
		_stress_lbl.text = "💔 Stress: %.0f%%" % (stress * 100)

	if _break_lbl:
		var brk = c.get("active_mental_break") if "active_mental_break" in c else Constants.BREAK_NONE
		var break_names = {
			Constants.BREAK_NONE: "None",
			Constants.BREAK_DEPRESSIVE: "Depressive",
			Constants.BREAK_BERSERK: "Berserk",
			Constants.BREAK_CATATONIC: "Catatonic",
			Constants.BREAK_PANIC: "Panic"
		}
		var break_name = break_names.get(brk, "None")
		_break_lbl.text = "🔥 Break: %s" % break_name
		if brk != Constants.BREAK_NONE:
			_break_lbl.add_theme_color_override("font_color", Color(1.0, 0.3, 0.1))
		else:
			_break_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))

	if _sick_lbl:
		var flu = c.get("viral_infection") if "viral_infection" in c else 0.0
		var para = c.get("parasitical_infection") if "parasitical_infection" in c else 0.0
		var has_sepsis = false
		if "wounds" in c:
			for w in c.wounds:
				if w.condition == Constants.WOUND_STATE_SEPTIC:
					has_sepsis = true
					break
		var diseases = []
		if flu > 0.15: diseases.append("Flu")
		if para > 0.1: diseases.append("Parasites")
		if has_sepsis: diseases.append("Sepsis")
		if diseases.size() > 0:
			_sick_lbl.text = "🤒 Sick: %s" % ", ".join(diseases)
			_sick_lbl.add_theme_color_override("font_color", Color(0.9, 0.85, 0.3))
		else:
			_sick_lbl.text = "🤒 Sick: No"
			_sick_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))

	if _wounds_lbl:
		if "wounds" in c and c.wounds.size() > 0:
			var wound_strings = []
			for w in c.wounds:
				var zone_name = Constants.ZONE_NAMES.get(w.zone, "Unknown")
				var cond_name = Constants.WOUND_STATE_NAMES.get(w.condition, "")
				if cond_name == "Healthy" or cond_name == "":
					wound_strings.append("%s" % zone_name)
				else:
					wound_strings.append("%s (%s)" % [zone_name, cond_name])
			var text = "🩹 Wounds: " + ", ".join(wound_strings)
			if text.length() > 32:
				text = text.substr(0, 29) + "..."
			_wounds_lbl.text = text
			_wounds_lbl.add_theme_color_override("font_color", Color(1.0, 0.6, 0.6))
		else:
			_wounds_lbl.text = "🩹 Wounds: None"
			_wounds_lbl.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))

	if _social_lbl:
		var fr = c.get("known_friends").size() if c.has_method("get") and c.get("known_friends") != null else 0
		var en = c.get("known_enemies").size() if c.has_method("get") and c.get("known_enemies") != null else 0
		_social_lbl.text = "👥 Friends: %d | Enemies: %d" % [fr, en]

	if _mem_lbl:
		var m_size = c.memory.size() if "memory" in c else 0
		var m_max = c.get_max_memory_size() if c.has_method("get_max_memory_size") else 60
		_mem_lbl.text = "🧠 Memory: %d/%d" % [m_size, m_max]

func select_creature(creature: Node2D) -> void:
	selected_creature = creature

func set_biome(biome: int) -> void:
	if _biome_lbl:
		var name = Constants.BIOME_NAMES.get(biome, "")
		_biome_lbl.text = name

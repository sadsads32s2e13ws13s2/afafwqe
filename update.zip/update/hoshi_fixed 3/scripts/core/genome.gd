class_name Genome
# Genetic system for creature inheritance and mutation

var genes: Dictionary = {}  # Dictionary of traits -> gene values (0.5 to 1.5)
var parent_genes: Array = [] # Array of parent genomes for inheritance tracking

func _init(parent1: Genome = null, parent2: Genome = null):
	"""Initialize genome with random traits or inherit from parents."""
	
	if parent1 == null and parent2 == null:
		# Create random starting genome
		_initialize_random_genome()
	else:
		# Inherit from parents with mutation
		_inherit_from_parents(parent1, parent2)
		parent_genes = [parent1, parent2]


func _initialize_random_genome() -> void:
	"""Create a random genome with all traits."""
	var all_traits = Constants.TRAIT_NAMES.keys()
	
	for trait_id in all_traits:
		# Random value between TRAIT_RANGE_MIN and TRAIT_RANGE_MAX
		genes[trait_id] = randf_range(
			Constants.TRAIT_RANGE_MIN,
			Constants.TRAIT_RANGE_MAX
		)


func _inherit_from_parents(parent1: Genome, parent2: Genome) -> void:
	"""Inherit genes from two parents with proper Mendelian inheritance and mutation.
	FIX: Old code averaged genes → population converged to identical mean over generations.
	New code: randomly picks one parent's allele per gene (like real genetics),
	then applies mutation. This preserves genetic diversity across generations.
	"""
	var all_traits = Constants.TRAIT_NAMES.keys()
	
	for trait_id in all_traits:
		var parent1_allele = parent1.genes[trait_id]
		var parent2_allele = parent2.genes[trait_id]
		
		# FIX: Proper Mendelian inheritance - randomly pick one parent's gene
		# (vs old: simple average which kills diversity).
		# 50/50 chance from each parent, with 10% blending for polygenic traits.
		var inherited_gene: float
		if randf() < 0.5:
			inherited_gene = parent1_allele
		else:
			inherited_gene = parent2_allele
		
		# Small blending effect (10%) to simulate polygenic traits
		if randf() < 0.1:
			inherited_gene = (parent1_allele + parent2_allele) / 2.0
		
		# Apply mutation
		if randf() * 100 < Constants.MUTATION_RATE:
			var mutation = randf_range(
				-Constants.MUTATION_MAGNITUDE,
				Constants.MUTATION_MAGNITUDE
			)
			inherited_gene += mutation
		
		# Clamp to valid range
		inherited_gene = clamp(
			inherited_gene,
			Constants.TRAIT_RANGE_MIN,
			Constants.TRAIT_RANGE_MAX
		)
		
		genes[trait_id] = inherited_gene


func get_trait_value(trait_id: int) -> float:
	"""Get the normalized value of a trait (0.5 to 1.5)."""
	if trait_id in genes:
		return genes[trait_id]
	return Constants.TRAIT_NEUTRAL


func get_trait_effectiveness(trait_id: int) -> float:
	"""Get trait effectiveness for game mechanics (0 to 2 scale)."""
	var value = get_trait_value(trait_id)
	# Map 0.5-1.5 range to 0-2 range
	return (value - Constants.TRAIT_RANGE_MIN) * 2.0 / (
		Constants.TRAIT_RANGE_MAX - Constants.TRAIT_RANGE_MIN
	)


func get_phenotype_description() -> String:
	"""Return a human-readable description of the creature's phenotype."""
	var description = ""
	
	var size_val = get_trait_effectiveness(Constants.TRAIT_SIZE)
	var strength_val = get_trait_effectiveness(Constants.TRAIT_STRENGTH)
	var speed_val = get_trait_effectiveness(Constants.TRAIT_SPEED)
	var _intel_val = get_trait_effectiveness(Constants.TRAIT_INTELLIGENCE)
	
	# Size description
	if size_val < 0.5:
		description += "Tiny, "
	elif size_val < 1.0:
		description += "Small, "
	elif size_val < 1.5:
		description += "Medium, "
	else:
		description += "Large, "
	
	# Speed description
	if speed_val > 1.5:
		description += "swift, "
	elif speed_val > 0.5:
		description += "agile, "
	
	# Build description
	if strength_val > 1.5:
		description += "powerful creature"
	elif strength_val < 0.5:
		description += "fragile creature"
	else:
		description += "balanced creature"
	
	return description


func get_genetic_diversity(other: Genome) -> float:
	"""Calculate genetic distance to another genome (0.0 = identical, 1.0 = completely different)."""
	var total_distance = 0.0
	var all_traits = Constants.TRAIT_NAMES.keys()
	
	for trait_id in all_traits:
		var distance = abs(genes[trait_id] - other.genes[trait_id])
		total_distance += distance / (Constants.TRAIT_RANGE_MAX - Constants.TRAIT_RANGE_MIN)
	
	return total_distance / all_traits.size()


func to_dict() -> Dictionary:
	"""Serialize genome to dictionary for saving."""
	return {
		"genes": genes.duplicate(),
		"parent_genes": parent_genes
	}


func from_dict(data: Dictionary) -> void:
	"""Deserialize genome from dictionary."""
	genes = data.get("genes", {})
	parent_genes = data.get("parent_genes", [])


func mutate() -> void:
	"""Apply random mutations to this genome in place."""
	var all_traits = Constants.TRAIT_NAMES.keys()
	for trait_id in all_traits:
		if randf() * 100 < Constants.MUTATION_RATE * 2.0:
			var mutation = randf_range(
				-Constants.MUTATION_MAGNITUDE,
				Constants.MUTATION_MAGNITUDE
			)
			genes[trait_id] = clamp(
				genes.get(trait_id, Constants.TRAIT_NEUTRAL) + mutation,
				Constants.TRAIT_RANGE_MIN,
				Constants.TRAIT_RANGE_MAX
			)

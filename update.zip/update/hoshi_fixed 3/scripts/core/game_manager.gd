extends Node
# Global game manager for simulation control

var game_time_hours: float = 0.0
var time_scale: float = Constants.TIME_SCALE_NORMAL
var is_paused: bool = false
var creatures: Array = []
var world_data: Dictionary = {}

# ── Circadian rhythm ──────────────────────────────────────────────────────────
var time_of_day: float = 0.25   # 0.0=midnight, 0.25=dawn, 0.5=noon, 0.75=dusk
var day_count: int = 0

# ── Spatial hash (O(1) proximity queries, replaces O(N²) get_nodes_in_group) ──
var _spatial: Dictionary = {}   # Vector2i → Array[Node2D]

signal time_changed(hours: float)
signal creature_spawned(creature)
signal creature_died(creature)
signal game_paused
signal game_resumed


func _ready() -> void:
	set_process(true)
	set_process_input(true)


func _process(delta: float) -> void:
	if is_paused:
		return

	var game_delta = delta * time_scale / Constants.GAME_HOUR_SECONDS
	game_time_hours += game_delta

	# Update circadian cycle
	var prev_tod := time_of_day
	time_of_day = fmod(
		time_of_day + delta * time_scale / Constants.GAME_DAY_SECONDS,
		1.0
	)
	if time_of_day < prev_tod:
		day_count += 1

	time_changed.emit(game_time_hours)


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_pause"):
		toggle_pause()
	elif event.is_action_pressed("ui_speed_up"):
		time_scale = Constants.TIME_SCALE_FAST
	elif event.is_action_pressed("ui_slow_down"):
		time_scale = Constants.TIME_SCALE_SLOW


func toggle_pause() -> void:
	is_paused = !is_paused
	if is_paused:
		game_paused.emit()
	else:
		game_resumed.emit()


func register_creature(creature: Node) -> void:
	if creature not in creatures:
		creatures.append(creature)
		creature_spawned.emit(creature)


func unregister_creature(creature: Node) -> void:
	if creature in creatures:
		creatures.erase(creature)
		creature_died.emit(creature)
	# Also remove from spatial hash on death
	var prev_key: Vector2i = creature.get_meta("_spatial_key", Vector2i(-99999, -99999))
	if _spatial.has(prev_key):
		_spatial[prev_key].erase(creature)
		if _spatial[prev_key].is_empty():
			_spatial.erase(prev_key)


func get_game_time_string() -> String:
	var hours = int(game_time_hours)
	var minutes = int((game_time_hours - hours) * 60)
	return "%02d:%02d" % [hours % 24, minutes]


# ── Circadian helpers ─────────────────────────────────────────────────────────

## Returns 1.0 at solar noon, 0.0 at midnight — smooth sinusoid.
## Used by neurochemistry to drive melatonin and by renderer for lighting.
func get_day_factor() -> float:
	return 0.5 + 0.5 * sin(time_of_day * TAU - PI * 0.5)


## Returns 0.0 (dark) to 1.0 (full light) — alias of get_day_factor().
func get_light_level() -> float:
	return get_day_factor()


# ── Spatial hash ──────────────────────────────────────────────────────────────

## Register or update a creature's cell in the spatial hash.
## Call each frame (or on significant movement) from creature_visual._process().
func update_spatial(creature: Node2D) -> void:
	var prev_key: Vector2i = creature.get_meta("_spatial_key", Vector2i(-99999, -99999))
	if _spatial.has(prev_key):
		_spatial[prev_key].erase(creature)
		if _spatial[prev_key].is_empty():
			_spatial.erase(prev_key)

	var new_key := Vector2i(
		int(creature.global_position.x / Constants.SPATIAL_CELL),
		int(creature.global_position.y / Constants.SPATIAL_CELL)
	)
	creature.set_meta("_spatial_key", new_key)
	if not _spatial.has(new_key):
		_spatial[new_key] = []
	_spatial[new_key].append(creature)


## Return all valid creatures within `radius` pixels of `pos`.
## At most (2*ceil(radius/CELL)+1)^2 cells are scanned — O(1) for typical radii.
func get_nearby(pos: Vector2, radius: float, exclude: Node2D = null) -> Array:
	var result: Array = []
	var cells := int(ceil(radius / Constants.SPATIAL_CELL)) + 1
	var cx := int(pos.x / Constants.SPATIAL_CELL)
	var cy := int(pos.y / Constants.SPATIAL_CELL)
	var r2 := radius * radius
	for dx in range(-cells, cells + 1):
		for dy in range(-cells, cells + 1):
			var key := Vector2i(cx + dx, cy + dy)
			for creature in _spatial.get(key, []):
				if creature == exclude:
					continue
				if is_instance_valid(creature) \
						and pos.distance_squared_to(creature.global_position) <= r2:
					result.append(creature)
	return result

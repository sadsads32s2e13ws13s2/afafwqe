extends Node2D
# World - biome rendering + food spawning

const BIOME_COLORS = {
	Constants.BIOME_GRASSLAND: Color(0.45, 0.72, 0.35),
	Constants.BIOME_FOREST:    Color(0.18, 0.45, 0.20),
	Constants.BIOME_DESERT:    Color(0.88, 0.78, 0.52),
	Constants.BIOME_CAVERN:    Color(0.22, 0.20, 0.28),
	Constants.BIOME_WATER:     Color(0.28, 0.58, 0.82),
}
const BIOME_ACCENT = {
	Constants.BIOME_GRASSLAND: Color(0.55, 0.85, 0.42),
	Constants.BIOME_FOREST:    Color(0.25, 0.60, 0.28),
	Constants.BIOME_DESERT:    Color(0.95, 0.88, 0.65),
	Constants.BIOME_CAVERN:    Color(0.35, 0.32, 0.42),
	Constants.BIOME_WATER:     Color(0.50, 0.78, 0.95),
}

# Food spawning constants (must be at top level)
# FIX: Was MAX=12 / INTERVAL=48s — creatures starved before they could learn anything.
# Now MAX=22 / INTERVAL=7s so food is scarce but learnable.
const MAX_FOOD_ITEMS = 22
const FOOD_SPAWN_INTERVAL = 7.0
var food_spawn_timer: float = 2.0

var biome_regions: Array = []
var viewport_size: Vector2

# Permanent water source (nice pond on the ground - Phase 2 improvement)
var water_source_pos: Vector2 = Vector2.ZERO
var water_source_radius: float = 90.0

func _ready() -> void:
	add_to_group("world")
	viewport_size = get_viewport_rect().size
	_generate_biome_regions()
	queue_redraw()
	
	# Place permanent water source on the ground (side-view)
	water_source_pos = Vector2(viewport_size.x * 0.75, viewport_size.y * 0.68 + 20)
	
	# Spawn initial food
	for i in range(24):
		_spawn_food_random()

func _generate_biome_regions() -> void:
	var cols = 3
	var rows = 2
	var bw = viewport_size.x / cols
	var bh = viewport_size.y / rows
	var biome_list = [
		Constants.BIOME_GRASSLAND, Constants.BIOME_FOREST, Constants.BIOME_WATER,
		Constants.BIOME_DESERT, Constants.BIOME_CAVERN, Constants.BIOME_GRASSLAND,
	]
	biome_regions.clear()
	for r in range(rows):
		for c in range(cols):
			var idx = r * cols + c
			biome_regions.append({
				"rect": Rect2(c * bw, r * bh, bw, bh),
				"biome": biome_list[idx % biome_list.size()],
			})

func _process(delta: float) -> void:
	if GameManager.is_paused:
		return
	food_spawn_timer -= delta * GameManager.time_scale
	if food_spawn_timer <= 0:
		food_spawn_timer = FOOD_SPAWN_INTERVAL
		var current = get_tree().get_nodes_in_group("food").size()
		if current < MAX_FOOD_ITEMS:
			_spawn_food_random()
			if current < MAX_FOOD_ITEMS / 2:
				_spawn_food_random()
	
	# Rotting food (disappears after 120 seconds)
	# FIX: Was 45s — food vanished before creatures navigated to it, making
	# location memory useless. 120s gives time to learn and revisit spots.
	var now = Time.get_ticks_msec() / 1000.0
	for f in get_tree().get_nodes_in_group("food"):
		if f.has_meta("spawn_time"):
			if now - f.get_meta("spawn_time") > 120.0:
				f.queue_free()

func _spawn_food_random() -> void:
	var vp = get_viewport_rect().size
	var ground_y = vp.y * 0.72
	# Spawn near ground (side-view style)
	var pos = Vector2(
		randf_range(40, vp.x - 40),
		ground_y + randf_range(-25, 8)   # slightly above or on ground
	)
	var biome = get_biome_at(pos)
	# More food in forest and grassland
	if biome == Constants.BIOME_DESERT and randf() > 0.15:
		return
	_spawn_food_at(pos, biome)

func _spawn_food_at(pos: Vector2, biome: int) -> void:
	var food = Node2D.new()
	food.add_to_group("food")
	food.position = pos
	food.set_meta("spawn_time", Time.get_ticks_msec() / 1000.0)  # for rotting

	# Assign food type by biome
	var ftype = "berry"
	var fvalue = 30.0
	match biome:
		Constants.BIOME_FOREST:
			ftype = "mushroom" if randf() > 0.5 else "berry"
			fvalue = 35.0
		Constants.BIOME_WATER:
			ftype = "water_drop"
			fvalue = 0.0   # gives thirst, not hunger
		Constants.BIOME_DESERT:
			ftype = "star_fragment"
			fvalue = 20.0
		Constants.BIOME_CAVERN:
			ftype = "mushroom"
			fvalue = 28.0
		_:
			ftype = "berry"
			fvalue = 30.0

	food.set_meta("food_type", ftype)
	food.set_meta("food_value", fvalue)
	food.set_script(_make_food_script(ftype, fvalue))
	add_child(food)

# Returns an inline script for drawing the food item
func _make_food_script(ftype: String, fvalue: float) -> GDScript:
	var script_src = """extends Node2D
var food_type = \"""" + ftype + """\"
var food_value = """ + str(fvalue) + """
var _phase: float = 0.0
func _process(delta):
	_phase += delta * 2.0
	queue_redraw()
func _draw():
	var bob = sin(_phase) * 1.5
	match food_type:
		\"berry\":
			draw_circle(Vector2(0, bob), 5, Color(0.90, 0.25, 0.35))
			draw_circle(Vector2(0, bob), 5, Color(0.95, 0.35, 0.45, 0.5))
			draw_line(Vector2(0, bob - 5), Vector2(2, bob - 9), Color(0.3, 0.6, 0.2), 1.5)
		\"mushroom\":
			draw_colored_polygon(PackedVector2Array([
				Vector2(-6, bob + 3), Vector2(6, bob + 3),
				Vector2(4, bob - 1), Vector2(-4, bob - 1)
			]), Color(0.9, 0.5, 0.3))
			draw_colored_polygon(PackedVector2Array([
				Vector2(-7, bob - 1), Vector2(7, bob - 1),
				Vector2(5, bob - 8), Vector2(-5, bob - 8)
			]), Color(0.85, 0.30, 0.20))
			draw_circle(Vector2(-2, bob - 4), 1.5, Color(1,1,1,0.8))
		\"water_drop\":
			var pts = PackedVector2Array()
			for i in range(24):
				var a = i / 11.0 * PI
				pts.append(Vector2(sin(a) * 4, bob + cos(a) * 6 - 2))
			draw_colored_polygon(pts, Color(0.4, 0.75, 1.0, 0.85))
			draw_circle(Vector2(-1, bob - 4), 1.5, Color(1,1,1,0.7))
		\"star_fragment\":
			for i in range(5):
				var a = (i / 5.0) * TAU - PI/2
				var inner_a = a + PI / 5
				var op = Vector2(cos(a), sin(a)) * 6 + Vector2(0, bob)
				var ip = Vector2(cos(inner_a), sin(inner_a)) * 2.5 + Vector2(0, bob)
				draw_line(op, ip, Color(1.0, 0.9, 0.3, 0.9), 1.5)
"""
	var gs = GDScript.new()
	gs.source_code = script_src
	gs.reload()
	return gs

func _draw() -> void:
	var vp = get_viewport_rect().size
	
	# === SIDE-VIEW IMMERSIVE BACKGROUND (Phase 1 Visual Upgrade) ===
	# Sky gradient (top = day sky, bottom = horizon glow)
	var sky_top = Color(0.35, 0.55, 0.85)
	var sky_bottom = Color(0.65, 0.75, 0.55)
	draw_rect(Rect2(0, 0, vp.x, vp.y * 0.65), sky_top)
	for i in range(20):
		var t = i / 20.0
		var y = vp.y * 0.3 + t * vp.y * 0.4
		var c = sky_top.lerp(sky_bottom, t)
		draw_rect(Rect2(0, y, vp.x, vp.y * 0.02), c)
	
	# Horizon line + distant hills (parallax feel)
	draw_line(Vector2(0, vp.y * 0.62), Vector2(vp.x, vp.y * 0.62), Color(0.25, 0.35, 0.25), 3)
	for i in range(5):
		var hx = (i * 180 + sin(Time.get_ticks_msec() / 8000.0 + i) * 30) 
		var hy = vp.y * 0.58 - i * 8
		draw_circle(Vector2(hx, hy), 80 + i * 10, Color(0.2, 0.35, 0.22, 0.6))
	
	# Ground layer (side-view style)
	var ground_y = vp.y * 0.68
	draw_rect(Rect2(0, ground_y, vp.x, vp.y - ground_y), Color(0.28, 0.22, 0.18))
	
	# Biome-specific ground details (now as horizontal layers)
	for region in biome_regions:
		var b: int = region["biome"]
		var rect: Rect2 = region["rect"]
		var accent = BIOME_ACCENT[b]
		
		# Draw as "terrain strip" at ground level
		var strip_y = ground_y + (region["rect"].position.y / vp.y) * 80
		draw_rect(Rect2(0, strip_y, vp.x, 60), BIOME_COLORS[b] * 0.7)
		
		# Trees / details rising from ground (side-view trees)
		if b == Constants.BIOME_FOREST:
			for i in range(8):
				var tx = fmod(region["rect"].position.x + i * 90, vp.x)
				var th = 45 + randf() * 30
				draw_line(Vector2(tx, strip_y + 30), Vector2(tx, strip_y - th), Color(0.15, 0.35, 0.15), 4)
				draw_circle(Vector2(tx, strip_y - th * 0.7), 22, accent)
		elif b == Constants.BIOME_GRASSLAND:
			for i in range(25):
				var gx = fmod(i * 45 + region["rect"].position.x * 0.3, vp.x)
				draw_line(Vector2(gx, strip_y + 10), Vector2(gx + randf_range(-4,4), strip_y - randf_range(12,28)), accent, 2)
		elif b == Constants.BIOME_WATER:
			draw_rect(Rect2(0, strip_y, vp.x, 55), Color(0.2, 0.45, 0.7, 0.6))
			for i in range(12):
				var wx = i * 70
				draw_arc(Vector2(wx, strip_y + 25), 18, 0, PI, 12, Color(1,1,1,0.4), 2)
		elif b == Constants.BIOME_DESERT:
			for i in range(4):
				var dx = region["rect"].position.x + i * 120
				draw_line(Vector2(dx, strip_y + 5), Vector2(dx + 25, strip_y - 35), Color(0.9, 0.8, 0.5), 3)
	
	# Subtle vignette for depth
	draw_rect(Rect2(0, 0, vp.x, vp.y), Color(0.05, 0.03, 0.08, 0.15))
	
	# === PERMANENT WATER SOURCE (Pond on ground) ===
	if water_source_pos != Vector2.ZERO:
		var pond_y = water_source_pos.y
		# Water body
		draw_circle(water_source_pos, water_source_radius, Color(0.25, 0.55, 0.85, 0.85))
		draw_circle(water_source_pos + Vector2(15, -10), water_source_radius * 0.75, Color(0.35, 0.65, 0.95, 0.6))
		
		# Waves / ripples
		for i in range(5):
			var wave_y = pond_y + sin(Time.get_ticks_msec() / 600.0 + i) * 4
			draw_arc(water_source_pos + Vector2(0, i * 8 - 15), water_source_radius * (0.6 + i * 0.08), 
				0.2, PI - 0.2, 16, Color(1, 1, 1, 0.35), 2.5)
		
		# Shore / rocks
		draw_circle(water_source_pos + Vector2(-water_source_radius + 10, 25), 18, Color(0.4, 0.35, 0.3))
		draw_circle(water_source_pos + Vector2(water_source_radius - 15, 20), 14, Color(0.45, 0.38, 0.32))
	
	# NOTE: _draw_biome_detail() removed — was a duplicate pass over biome_regions
	# that rendered on top of the new side-view strips, causing visual double-draw.

func _draw_biome_detail(rect: Rect2, biome: int) -> void:
	var accent = BIOME_ACCENT[biome]
	var rng = RandomNumberGenerator.new()
	rng.seed = int(rect.position.x + rect.position.y * 1000)
	match biome:
		Constants.BIOME_GRASSLAND:
			for i in range(60):
				var x = rect.position.x + rng.randf() * rect.size.x
				var y = rect.position.y + rect.size.y * 0.6 + rng.randf() * rect.size.y * 0.4
				var h = rng.randf_range(6, 18)
				draw_line(Vector2(x, y), Vector2(x + rng.randf_range(-3,3), y - h), accent, 1.5)
			for i in range(10):
				var px = rect.position.x + rng.randf() * rect.size.x
				var py = rect.position.y + rng.randf() * rect.size.y
				draw_circle(Vector2(px, py), 3, Color(1.0, 0.75, 0.85, 0.8))
		Constants.BIOME_FOREST:
			for i in range(24):
				var tx = rect.position.x + rng.randf() * rect.size.x
				var ty = rect.position.y + rng.randf() * rect.size.y * 0.7
				var tree_r = rng.randf_range(18, 35)
				draw_circle(Vector2(tx, ty), tree_r, accent)
				draw_circle(Vector2(tx, ty), tree_r * 0.6, BIOME_ACCENT[biome] * 1.1)
			draw_rect(Rect2(rect.position.x, rect.position.y + rect.size.y * 0.75,
				rect.size.x, rect.size.y * 0.25), Color(0.30, 0.55, 0.25))
		Constants.BIOME_DESERT:
			for i in range(6):
				var y2 = rect.position.y + (i / 6.0) * rect.size.y
				var pts = PackedVector2Array()
				for x_step in range(0, int(rect.size.x), 20):
					var nx = rect.position.x + x_step
					var ny = y2 + sin(x_step * 0.05) * 12
					pts.append(Vector2(nx, ny))
				if pts.size() > 1:
					draw_polyline(pts, accent * 0.85, 1.5)
			for i in range(4):
				var cx = rect.position.x + rng.randf() * rect.size.x
				var cy = rect.position.y + rng.randf() * rect.size.y * 0.6 + rect.size.y * 0.3
				draw_line(Vector2(cx, cy), Vector2(cx, cy - 30), Color(0.35, 0.65, 0.30), 5)
				draw_line(Vector2(cx - 12, cy - 12), Vector2(cx, cy - 12), Color(0.35, 0.65, 0.30), 3)
		Constants.BIOME_CAVERN:
			for i in range(0, int(rect.size.x), 24):
				var sx = rect.position.x + i + rng.randf_range(0, 12)
				var sh = rng.randf_range(12, 40)
				draw_line(Vector2(sx, rect.position.y),
					Vector2(sx + rng.randf_range(-4,4), rect.position.y + sh),
					Color(0.45, 0.42, 0.55), 4)
			for i in range(8):
				var kx = rect.position.x + rng.randf() * rect.size.x
				var ky = rect.position.y + rng.randf() * rect.size.y
				draw_circle(Vector2(kx, ky), 4, Color(0.6, 0.5, 0.9, 0.7))
				draw_circle(Vector2(kx, ky), 2, Color(0.8, 0.7, 1.0, 0.9))
		Constants.BIOME_WATER:
			for i in range(20):
				var wx = rect.position.x + rng.randf() * rect.size.x
				var wy = rect.position.y + rng.randf() * rect.size.y
				draw_arc(Vector2(wx, wy), rng.randf_range(8, 22), 0, PI, 20, accent, 1.5)
			for i in range(15):
				var sx = rect.position.x + rng.randf() * rect.size.x
				var sy = rect.position.y + rng.randf() * rect.size.y
				draw_line(Vector2(sx-4, sy), Vector2(sx+4, sy), Color(0.9, 0.97, 1.0, 0.7), 1)
				draw_line(Vector2(sx, sy-4), Vector2(sx, sy+4), Color(0.9, 0.97, 1.0, 0.7), 1)

func get_biome_at(pos: Vector2) -> int:
	for region in biome_regions:
		if region["rect"].has_point(pos):
			return region["biome"]
	return Constants.BIOME_GRASSLAND

# New: creatures can drink from the permanent pond
func get_nearest_water_pos(from_pos: Vector2) -> Vector2:
	if water_source_pos == Vector2.ZERO:
		return from_pos
	return water_source_pos

extends Node2D
# Main scene — world + creatures + HUD + reproduction

const CREATURE_COUNT_START = 8
const SPAWN_INTERVAL = 20.0
const MAX_CREATURES = 500   # Almost no limit - let the ecosystem grow naturally

# Mirror of creature_visual MentalDisorder enum so _spawn_creature can reference it
# (GDScript enums are not exported from scripts, so we redeclare locally)
enum MentalDisorder { NONE, ANXIETY, DEPRESSION, PTSD, AGGRESSION_DISORDER }

var world_node: Node2D
var hud_node: CanvasLayer
var camera: Camera2D
var spawn_timer: float = 0.0
var next_creature_id: int = 1
var camera_zoom: float = 1.0
var is_panning: bool = false
var pan_start: Vector2 = Vector2.ZERO

func _ready() -> void:
	_build_world()
	_build_hud()
	hud_node.init_refs()
	_spawn_initial_creatures()
	
	# Initial camera position - center of world
	camera.position = get_viewport_rect().size / 2

func _build_world() -> void:
	world_node = Node2D.new()
	world_node.set_script(load("res://scripts/core/world.gd"))
	world_node.name = "World"
	add_child(world_node)
	
	# === VISUAL UPGRADE: Immersive Side-View Camera ===
	camera = Camera2D.new()
	camera.name = "MainCamera"
	camera.enabled = true
	camera.zoom = Vector2(camera_zoom, camera_zoom)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 5.0
	add_child(camera)
	camera.make_current()

func _build_hud() -> void:
	hud_node = CanvasLayer.new()
	hud_node.name = "HUD"

	# Time panel (top-left)
	var time_panel = PanelContainer.new()
	time_panel.name = "TimePanel"
	_style_panel(time_panel)
	var vbox_t = VBoxContainer.new()
	var time_lbl = Label.new(); time_lbl.name = "TimeLabel"; time_lbl.text = "⏱ Day 1  00:00"
	time_lbl.add_theme_color_override("font_color", Color(1, 0.95, 0.8))
	var pop_lbl = Label.new(); pop_lbl.name = "PopLabel"; pop_lbl.text = "Population: 0"
	pop_lbl.add_theme_color_override("font_color", Color(0.8, 1.0, 0.85))
	vbox_t.add_child(time_lbl); vbox_t.add_child(pop_lbl)
	time_panel.add_child(vbox_t)
	time_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	time_panel.position = Vector2(12, 12)
	hud_node.add_child(time_panel)

	# Controls hint (top-center)
	var hint = Label.new(); hint.name = "HintLabel"
	hint.text = "SPACE: Pause  |  T: Fast  |  G: Slow  |  Scroll: Zoom  |  Middle Drag: Pan  |  Click: Select"
	hint.add_theme_color_override("font_color", Color(0.7, 0.7, 0.85, 0.7))
	hint.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.position.y = 14
	hud_node.add_child(hint)

	# Creature info panel (top-right) — extended with needs
	var cpanel = PanelContainer.new(); cpanel.name = "CreaturePanel"
	cpanel.custom_minimum_size = Vector2(220, 0)
	_style_panel(cpanel)
	var vbox_c = VBoxContainer.new(); vbox_c.name = "VBox"
	vbox_c.add_theme_constant_override("separation", 3)
	var label_defs = [
		["NameLabel",   "Hoshi #0000",       Color(1.00, 0.90, 0.65)],
		["StageLabel",  "🌸 Adult",           Color(0.85, 0.72, 1.00)],
		["HealthLabel", "❤ Health: 100%",     Color(0.50, 0.95, 0.55)],
		["HungerLabel", "🍓 Hunger: 100%",    Color(1.00, 0.75, 0.40)],
		["ThirstLabel", "💧 Thirst: 100%",    Color(0.45, 0.80, 1.00)],
		["FatigueLabel","😴 Rest: 100%",      Color(0.75, 0.55, 0.95)],
		["AgeLabel",    "🕐 Age: 0.0 hrs",   Color(0.70, 0.88, 1.00)],
		["StateLabel",  "🌀 Wandering",       Color(0.80, 0.85, 0.80)],
		["GenomeLabel", "Spd - Str - Int",    Color(0.75, 0.75, 0.88)],
		# Psyche / Deep Life Simulation info
		["EmotionLabel", "😊 Emotion: Content", Color(0.9, 0.7, 0.95)],
		["PersonalityLabel", "🔍 Personality: Curious", Color(0.7, 0.9, 1.0)],
		["TraumaLabel", "💔 Trauma: 0%", Color(0.95, 0.6, 0.6)],
		["WillLabel", "❤️ Will to Live: 100%", Color(1.0, 0.8, 0.8)],
		["StressLabel", "💔 Stress: 0%", Color(0.9, 0.4, 0.4)],
		["BreakLabel", "🔥 Break: None", Color(1.0, 0.3, 0.1)],
		["SickLabel", "🤒 Sick: No", Color(0.7, 0.9, 0.4)],
		["WoundsLabel", "🩹 Wounds: None", Color(0.9, 0.7, 0.6)],
		["SocialLabel", "👥 Friends: 0 | Enemies: 0", Color(0.7, 0.85, 0.95)],
		["MemoryLabel", "🧠 Memory: 0/60", Color(0.75, 0.9, 0.85)],
	]
	for ld in label_defs:
		var lbl = Label.new(); lbl.name = ld[0]; lbl.text = ld[1]
		lbl.add_theme_color_override("font_color", ld[2])
		vbox_c.add_child(lbl)
	cpanel.add_child(vbox_c)
	cpanel.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	cpanel.position = Vector2(-240, 12)
	hud_node.add_child(cpanel)

	# Pause overlay
	var pause_lbl = Label.new(); pause_lbl.name = "PauseOverlay"
	pause_lbl.text = "⏸ PAUSED"
	pause_lbl.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	pause_lbl.add_theme_font_size_override("font_size", 48)
	pause_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	pause_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_node.add_child(pause_lbl)

	# Biome label (bottom-center)
	var biome_lbl = Label.new(); biome_lbl.name = "BiomeLabel"; biome_lbl.text = ""
	biome_lbl.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	biome_lbl.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	biome_lbl.position = Vector2(-60, -36)
	hud_node.add_child(biome_lbl)

	hud_node.set_script(load("res://scripts/ui/hud.gd"))
	add_child(hud_node)

func _style_panel(panel: PanelContainer) -> void:
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.10, 0.08, 0.16, 0.82)
	sb.set_corner_radius_all(8)
	sb.set_border_width_all(1)
	sb.border_color = Color(0.55, 0.40, 0.75, 0.6)
	sb.content_margin_left   = 10
	sb.content_margin_right  = 10
	sb.content_margin_top    = 8
	sb.content_margin_bottom = 8
	panel.add_theme_stylebox_override("panel", sb)

func _spawn_initial_creatures() -> void:
	var vp = get_viewport_rect().size
	var start_ages = [0.0, 5.0, 10.0, 26.0, 50.0]
	for i in range(CREATURE_COUNT_START):
		var ground_y = vp.y * 0.72
		var pos = Vector2(randf_range(60, vp.x - 60), ground_y + randf_range(-20, 5))
		_spawn_creature(pos, i % 4, start_ages[i % start_ages.size()])

func _spawn_creature(pos: Vector2, variant: int = 0, start_age: float = 0.0,
		parent_genome1: Genome = null, parent_genome2: Genome = null, parent: Node2D = null) -> Node2D:
	var creature = Node2D.new()
	creature.set_script(load("res://scripts/creatures/creature_visual.gd"))
	creature.position = pos
	add_child(creature)
	creature.age_hours = start_age
	creature.color_variant = variant % 4

	# Genome: inherit or random
	if parent_genome1:
		var child_genome = Genome.new(parent_genome1, parent_genome2 if parent_genome2 else parent_genome1)  # proper deep inheritance
		creature.genome = child_genome
	else:
		creature.genome = Genome.new()

	# === Multi-generational personality inheritance ===
	# BUG FIX: creature.has_method("personality") → personality is a VAR not a method,
	# so this always returned false and personality was NEVER inherited.
	if parent and is_instance_valid(parent):
		# 40% chance to inherit parent's personality archetype
		if randf() < 0.40:
			creature.personality = parent.personality
		# Inherit safe zones from parent (territorial memory)
		if parent.safe_zones.size() > 0 and randf() < 0.5:
			creature.safe_zones = parent.safe_zones.duplicate()

	# === COMPLEX REPRODUCTION: Risk of miscarriage ===
	var miscarriage_chance = 0.0
	if parent:
		if parent.health < 50.0 or parent.trauma_level > 0.4:
			miscarriage_chance += 0.35
		if parent._emotion == Constants.EMOTION_FEAR or parent._emotion == Constants.EMOTION_PAIN:
			miscarriage_chance += 0.25
	
	if randf() < miscarriage_chance:
		creature.queue_free()
		return null

	# === MENTAL DISORDERS INHERITANCE ===
	# BUG FIX: has_method("mental_disorder") → mental_disorder is a VAR not a method,
	# always false → mental disorders were NEVER inherited despite 45% stated chance.
	if parent and is_instance_valid(parent):
		if parent.mental_disorder != MentalDisorder.NONE and randf() < 0.30:
			creature.mental_disorder = parent.mental_disorder
			creature.disorder_severity = parent.disorder_severity * randf_range(0.5, 0.9)

	creature.creature_selected.connect(_on_creature_selected)
	creature.wants_reproduce.connect(_on_creature_reproduce)
	GameManager.register_creature(creature)

	# Clickable area
	var area = Area2D.new()
	var col = CollisionShape2D.new()
	var shape = CircleShape2D.new()
	shape.radius = 24
	col.shape = shape
	area.add_child(col)
	area.input_pickable = true
	area.input_event.connect(creature._on_area_input_event)
	creature.add_child(area)

	next_creature_id += 1
	creature.set_meta("creature_id", next_creature_id)
	return creature

var _cleanup_timer: float = 0.0

func _process(delta: float) -> void:
	if GameManager.is_paused:
		return

	# Auto-spawn wanderers (safety net against total extinction)
	spawn_timer -= delta * GameManager.time_scale
	if spawn_timer <= 0 and GameManager.creatures.size() < 12:
		spawn_timer = SPAWN_INTERVAL
		var vp = get_viewport_rect().size
		var ground_y = vp.y * 0.72
		_spawn_creature(
			Vector2(randf_range(60, vp.x - 60), ground_y + randf_range(-20, 5)),
			randi() % 4, 0.0
		)

	# Biome label
	if world_node and world_node.has_method("get_biome_at"):
		var mp = get_viewport().get_mouse_position()
		var biome = world_node.get_biome_at(mp)
		if hud_node and hud_node.has_method("set_biome"):
			hud_node.set_biome(biome)

	# BUG FIX: dead-creature cleanup was inside _unhandled_input — it only ran
	# when the player pressed a key or clicked, so deceased creatures lingered in
	# GameManager.creatures for potentially hours. Moved here and throttled to
	# every 2s so it runs constantly without hammering the list every frame.
	_cleanup_timer -= delta
	if _cleanup_timer <= 0.0:
		_cleanup_timer = 2.0
		for c in GameManager.creatures.duplicate():
			if not is_instance_valid(c) or c.life_stage == Constants.LIFE_STAGE_DECEASED:
				GameManager.unregister_creature(c)
				if is_instance_valid(c):
					c.queue_free()

func _unhandled_input(event: InputEvent) -> void:
	# === CAMERA CONTROLS (Side-View Immersive Mode) ===
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			camera_zoom = clamp(camera_zoom * 1.1, 0.3, 4.0)
			camera.zoom = Vector2(camera_zoom, camera_zoom)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			camera_zoom = clamp(camera_zoom / 1.1, 0.3, 4.0)
			camera.zoom = Vector2(camera_zoom, camera_zoom)
		elif event.button_index == MOUSE_BUTTON_MIDDLE:
			is_panning = event.pressed
			if is_panning:
				pan_start = event.position
		elif event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			# Click to center camera on creature (if any)
			pass  # handled in creature selection

	elif event is InputEventMouseMotion and is_panning:
		var delta_pos = event.position - pan_start
		camera.position -= delta_pos / camera_zoom
		pan_start = event.position

	elif event is InputEventKey:
		if event.pressed:
			if event.keycode == KEY_C:  # Center on random creature
				var creatures = get_tree().get_nodes_in_group("creatures")
				if creatures.size() > 0:
					var target = creatures[randi() % creatures.size()]
					camera.position = target.global_position
			elif event.keycode == KEY_R:  # Reset camera
				camera.position = get_viewport_rect().size / 2
				camera_zoom = 1.0
				camera.zoom = Vector2.ONE

func _on_creature_selected(creature: Node2D) -> void:
	if hud_node and hud_node.has_method("select_creature"):
		hud_node.select_creature(creature)

func _on_creature_reproduce(parent1: Node2D, parent2: Node2D = null) -> void:
	if not is_instance_valid(parent1):
		return
	if GameManager.creatures.size() >= MAX_CREATURES:
		return
	# Spawn baby nearby (on ground)
	var vp = get_viewport_rect().size
	var ground_y = vp.y * 0.72
	var offset = Vector2(randf_range(-40, 40), randf_range(-15, 5))
	var baby_pos = Vector2(parent1.position.x + offset.x, ground_y + offset.y)
	baby_pos = baby_pos.clamp(Vector2(40, ground_y - 30), Vector2(vp.x - 40, ground_y + 10))
	var gen2 = parent2.genome if is_instance_valid(parent2) else parent1.genome
	var baby = _spawn_creature(baby_pos, parent1.color_variant, 0.0, parent1.genome, gen2, parent1)
	# Visual birth sparkle effect via brief health pulse
	if is_instance_valid(baby):
		baby.health = 100.0

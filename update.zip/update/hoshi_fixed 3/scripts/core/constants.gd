extends Node
# Global constants for Hoshi no Ko

# ============================================================================
# LIFECYCLE & AGE CONSTANTS
# ============================================================================

const LIFE_STAGE_EMBRYO = 0
const LIFE_STAGE_JUVENILE = 1
const LIFE_STAGE_ADULT = 2
const LIFE_STAGE_ELDER = 3
const LIFE_STAGE_DECEASED = 4

# Age is measured in "years" (1 year = GAME_HOUR_SECONDS real seconds at 1x speed).
# There is NO hard death cap — creatures die from accumulated senescence damage.
# Degradation begins at 60 (ADULT_DURATION_HOURS) and intensifies toward ~100.
# Real-time: 1 year ≈ 6 sec (GAME_HOUR_SECONDS=60 / 10x time factor via scale).
#   Embryo    0→2 yrs   (~12 sec real at 1x)
#   Juvenile  2→18 yrs  (~1.5 min real)
#   Adult    18→60 yrs  (~4 min real)
#   Elder    60+  yrs   (slow senescence, typically dies 70-100)
const EMBRYO_DURATION_HOURS   = 2    # years
const JUVENILE_DURATION_HOURS = 18   # years
const ADULT_DURATION_HOURS    = 60   # years (elder stage begins here)
const ELDER_START_YEARS       = 60   # alias used in physiology
const LIFESPAN_HOURS          = 9999 # no hard cap — death via senescence damage

# ============================================================================
# DAMAGE SYSTEM - ANATOMICAL ZONES
# ============================================================================

const ZONE_HEAD = 0
const ZONE_TORSO = 1
const ZONE_FRONT_LEFT = 2
const ZONE_FRONT_RIGHT = 3
const ZONE_BACK_LEFT = 4
const ZONE_BACK_RIGHT = 5
const ZONE_TAIL = 6

const ZONE_NAMES = {
    ZONE_HEAD: "Head",
    ZONE_TORSO: "Torso",
    ZONE_FRONT_LEFT: "Front Left Limb",
    ZONE_FRONT_RIGHT: "Front Right Limb",
    ZONE_BACK_LEFT: "Back Left Limb",
    ZONE_BACK_RIGHT: "Back Right Limb",
    ZONE_TAIL: "Tail"
}

const ZONE_VITALITY = {
    ZONE_HEAD: 0.8,         # Lethal if too damaged
    ZONE_TORSO: 1.0,        # Most vital
    ZONE_FRONT_LEFT: 0.3,
    ZONE_FRONT_RIGHT: 0.3,
    ZONE_BACK_LEFT: 0.3,
    ZONE_BACK_RIGHT: 0.3,
    ZONE_TAIL: 0.1
}

# ============================================================================
# DAMAGE SYSTEM - DAMAGE TYPES
# ============================================================================

const DAMAGE_TYPE_LACERATION = 0    # Cut/slash - causes bleeding
const DAMAGE_TYPE_BLUNT = 1         # Blunt impact - causes fracture/pain
const DAMAGE_TYPE_PUNCTURE = 2      # Pierce - internal damage + infection risk
const DAMAGE_TYPE_BURN = 3          # Heat/chemical - tissue damage
const DAMAGE_TYPE_TOXIN = 4         # Poison/venom - systemic damage

const DAMAGE_TYPE_NAMES = {
    DAMAGE_TYPE_LACERATION: "Laceration",
    DAMAGE_TYPE_BLUNT: "Blunt Trauma",
    DAMAGE_TYPE_PUNCTURE: "Puncture",
    DAMAGE_TYPE_BURN: "Burn",
    DAMAGE_TYPE_TOXIN: "Toxin"
}

# ============================================================================
# DAMAGE SYSTEM - WOUND CONDITIONS
# ============================================================================

const WOUND_STATE_NONE = 0
const WOUND_STATE_BLEEDING = 1       # Blood loss
const WOUND_STATE_INFECTED = 2       # Infection developing
const WOUND_STATE_SEPTIC = 3         # Systemic infection
const WOUND_STATE_FRACTURED = 4      # Bone damage
const WOUND_STATE_SCARRED = 5        # Healed but scarred

const WOUND_STATE_NAMES = {
    WOUND_STATE_NONE: "Healthy",
    WOUND_STATE_BLEEDING: "Bleeding",
    WOUND_STATE_INFECTED: "Infected",
    WOUND_STATE_SEPTIC: "Septic",
    WOUND_STATE_FRACTURED: "Fractured",
    WOUND_STATE_SCARRED: "Scarred"
}

# Bleeding rates (% health per game hour)
const BLEED_RATE_LIGHT = 1.0
const BLEED_RATE_MODERATE = 3.0
const BLEED_RATE_SEVERE = 8.0

# Infection progression (hours before state change)
const INFECTION_ONSET_HOURS = 6
const SEPSIS_ONSET_HOURS = 24

# ============================================================================
# PHYSIOLOGICAL NEEDS
# ============================================================================

const NEED_HUNGER = 0           # Hunger/food
const NEED_THIRST = 1           # Hydration
const NEED_OXYGEN = 2           # Breath (internal)
const NEED_TEMPERATURE = 3      # Thermoregulation
const NEED_REST = 4             # Sleep/energy
const NEED_REPRODUCTION = 5     # Biological urge
const NEED_SHELTER = 6          # Safety/comfort

const NEED_NAMES = {
    NEED_HUNGER: "Hunger",
    NEED_THIRST: "Thirst",
    NEED_OXYGEN: "Oxygen",
    NEED_TEMPERATURE: "Temperature",
    NEED_REST: "Rest",
    NEED_REPRODUCTION: "Reproduction",
    NEED_SHELTER: "Shelter"
}

# Depletion rates (% per game hour at baseline)
const DEPLETION_RATES = {
    NEED_HUNGER: 2.0,
    NEED_THIRST: 3.0,
    NEED_OXYGEN: 5.0,
    NEED_TEMPERATURE: 1.5,
    NEED_REST: 1.0,
    NEED_REPRODUCTION: 0.3,
    NEED_SHELTER: 0.5
}

# Critical thresholds (% below which damage occurs)
const CRITICAL_THRESHOLD = 25.0   # Higher = creatures start dying earlier from hunger/thirst

# ============================================================================
# BIOME TYPES & PARAMETERS
# ============================================================================

const BIOME_GRASSLAND = 0
const BIOME_FOREST = 1
const BIOME_DESERT = 2
const BIOME_CAVERN = 3
const BIOME_WATER = 4

const BIOME_NAMES = {
    BIOME_GRASSLAND: "Grassland",
    BIOME_FOREST: "Forest",
    BIOME_DESERT: "Desert",
    BIOME_CAVERN: "Cavern",
    BIOME_WATER: "Water"
}

# Temperature ranges (in game units, 0-100)
const BIOME_TEMP_RANGES = {
    BIOME_GRASSLAND: Vector2(40, 70),
    BIOME_FOREST: Vector2(35, 65),
    BIOME_DESERT: Vector2(60, 100),
    BIOME_CAVERN: Vector2(45, 55),
    BIOME_WATER: Vector2(30, 70)
}

# Humidity ranges (0-100%)
const BIOME_HUMIDITY_RANGES = {
    BIOME_GRASSLAND: Vector2(30, 60),
    BIOME_FOREST: Vector2(70, 95),
    BIOME_DESERT: Vector2(5, 20),
    BIOME_CAVERN: Vector2(40, 80),
    BIOME_WATER: Vector2(85, 100)
}

# Oxygen levels (0-100%)
const BIOME_OXYGEN_LEVELS = {
    BIOME_GRASSLAND: 95.0,
    BIOME_FOREST: 98.0,
    BIOME_DESERT: 90.0,
    BIOME_CAVERN: 60.0,
    BIOME_WATER: 40.0
}

# Food availability (items per square per cycle)
const BIOME_FOOD_ABUNDANCE = {
    BIOME_GRASSLAND: 3,
    BIOME_FOREST: 5,
    BIOME_DESERT: 1,
    BIOME_CAVERN: 2,
    BIOME_WATER: 4
}

# ============================================================================
# GENETIC TRAITS
# ============================================================================

const TRAIT_SIZE = 0                # Body size (affects movement, storage)
const TRAIT_STRENGTH = 1             # Muscle power (affects damage dealt)
const TRAIT_SPEED = 2                # Movement speed
const TRAIT_INTELLIGENCE = 3         # Problem-solving ability
const TRAIT_SIGHT_RANGE = 4          # Vision distance
const TRAIT_HEARING_RANGE = 5        # Sound detection
const TRAIT_SMELL_RANGE = 6          # Scent detection
const TRAIT_METABOLISM = 7           # Food efficiency (lower = less hunger)
const TRAIT_THERMOTOLERANCE = 8      # Temperature resistance
const TRAIT_REGENERATION = 9         # Healing rate
const TRAIT_TOXIN_RESISTANCE = 10    # Poison immunity
const TRAIT_FERTILITY = 11           # Reproductive success
const TRAIT_LONGEVITY = 12           # Lifespan extension
const TRAIT_SOCIAL = 13                # Social tendency (affects bonding, alliances, group behavior)

const TRAIT_NAMES = {
    TRAIT_SIZE: "Size",
    TRAIT_STRENGTH: "Strength",
    TRAIT_SPEED: "Speed",
    TRAIT_INTELLIGENCE: "Intelligence",
    TRAIT_SIGHT_RANGE: "Sight Range",
    TRAIT_HEARING_RANGE: "Hearing Range",
    TRAIT_SMELL_RANGE: "Smell Range",
    TRAIT_METABOLISM: "Metabolism",
    TRAIT_THERMOTOLERANCE: "Thermo-tolerance",
    TRAIT_REGENERATION: "Regeneration",
    TRAIT_TOXIN_RESISTANCE: "Toxin Resistance",
    TRAIT_FERTILITY: "Fertility",
    TRAIT_LONGEVITY: "Longevity",
    TRAIT_SOCIAL: "Social"
}

# Trait ranges (0.5 = recessive max, 1.5 = dominant max)
const TRAIT_RANGE_MIN = 0.5
const TRAIT_RANGE_MAX = 1.5
const TRAIT_NEUTRAL = 1.0

# Mutation probability per gene per generation (%)
const MUTATION_RATE = 2.0

# Maximum mutation magnitude (how much a gene can change)
const MUTATION_MAGNITUDE = 0.15

# ============================================================================
# AI SYSTEM - PERCEPTION & EMOTIONS
# ============================================================================

const EMOTION_FEAR = 0
const EMOTION_ANGER = 1
const EMOTION_CURIOSITY = 2
const EMOTION_CONTENTMENT = 3
const EMOTION_PAIN = 4
const EMOTION_EXCITEMENT = 5
const EMOTION_LOVE = 6
const EMOTION_EMBARRASSMENT = 7

const EMOTION_NAMES = {
    EMOTION_FEAR: "Fear",
    EMOTION_ANGER: "Anger",
    EMOTION_CURIOSITY: "Curiosity",
    EMOTION_CONTENTMENT: "Contentment",
    EMOTION_PAIN: "Pain",
    EMOTION_EXCITEMENT: "Excitement",
    EMOTION_LOVE: "Love",
    EMOTION_EMBARRASSMENT: "Embarrassment"
}

# ============================================================================
# AI SYSTEM - MEMORY
# ============================================================================

const MEMORY_TYPE_LOCATION = 0      # "Food here", "Predator was here"
const MEMORY_TYPE_ENTITY = 1        # Individual creature properties
const MEMORY_TYPE_EXPERIENCE = 2    # "Fire burns", "This plant poisons"

const MEMORY_DECAY_HOURS = 12       # How long memories last

# ============================================================================
# INFECTION & DISEASE
# ============================================================================

const INFECTION_SEVERITY_MILD = 0.3
const INFECTION_SEVERITY_MODERATE = 0.6
const INFECTION_SEVERITY_SEVERE = 1.0

# Resistance to infection (genetic + immunity)
const BASE_INFECTION_RESISTANCE = 0.5

# ============================================================================
# HEALING & MEDICINE
# ============================================================================

const HEALING_RATE_NATURAL = 2.0    # % per game hour
const HEALING_RATE_WITH_REST = 4.0  # % per game hour at rest
const HEALING_RATE_WITH_HERBS = 6.0 # % per game hour with healing herbs

# ============================================================================
# TIME & SIMULATION
# ============================================================================

const GAME_HOUR_SECONDS = 6.0       # 1 game year = 6 real seconds (100 yrs ≈ 10 min at 1x)
const TIME_SCALE_NORMAL = 1.0
const TIME_SCALE_SLOW = 0.5
const TIME_SCALE_FAST = 2.0

# ============================================================================
# CREATURE PARAMETERS
# ============================================================================

const BASE_HEALTH = 100.0
const BASE_SPEED = 100.0            # pixels per second
const BASE_STRENGTH = 10.0          # damage multiplier

# ============================================================================
# REPRODUCTION
# ============================================================================

const BREEDING_AGE_HOURS = 5        # Hours until adult can breed
const BREEDING_COOLDOWN_HOURS = 4   # Hours between breeding events
const GESTATION_HOURS = 1           # Pregnancy duration
const LITTER_SIZE_MIN = 1
const LITTER_SIZE_MAX = 4

# ============================================================================
# SURVIVAL, STRESS & DISEASE CONSTANTS
# ============================================================================

const CONTAGION_RANGE = 50.0          # Range for virus spread (pixels)
const SUICIDE_CHANCE_DAILY = 0.05      # Daily suicide chance during depressive break
const INFECTION_CHANCE_BASE = 0.25     # Base chance for open wound to get infected

# Mental breakdown states
const BREAK_NONE = 0
const BREAK_DEPRESSIVE = 1             # Self-starvation and suicide risk
const BREAK_BERSERK = 2                # Violent madness, attacks anything
const BREAK_CATATONIC = 3              # Comatose stupor
const BREAK_PANIC = 4                  # Erratic panic run

# ============================================================
# НЕЙРОХИМИЯ
# ============================================================
const NEURO_CHEMICALS = [
	"dopamine", "serotonin", "cortisol", "adrenaline",
	"endorphin", "oxytocin", "ghrelin", "leptin", "melatonin", "boredom"
]

const NEURO_DECAY_RATES = {
	"dopamine":   0.15,
	"serotonin":  0.05,
	"cortisol":   0.10,
	"adrenaline": 0.40,
	"endorphin":  0.20,
	"oxytocin":   0.08,
	"ghrelin":    0.04,
	"leptin":     0.06,
	"melatonin":  0.12,
	"boredom":    0.03
}

const NEURO_BASELINE = {
	"dopamine":   0.30,
	"serotonin":  0.60,
	"cortisol":   0.10,
	"adrenaline": 0.00,
	"endorphin":  0.10,
	"oxytocin":   0.20,
	"ghrelin":    0.30,
	"leptin":     0.70,
	"melatonin":  0.20,
	"boredom":    0.20
}

const MOOD_POSITIVE_THRESHOLD =  0.3
const MOOD_NEGATIVE_THRESHOLD = -0.3
const MOOD_CRITICAL_THRESHOLD = -0.7

const EPISODIC_MEMORY_BASE_SIZE   = 10
const EPISODIC_MEMORY_INTEL_BONUS = 20

const SPATIAL_CELL = 100.0
const GAME_DAY_SECONDS = 144.0

extends Node
# Database tracking genetic lineages and population statistics

var all_creatures: Array = []
var genetic_tree: Dictionary = {}  # creature_id -> parent_ids
var species_variants: Dictionary = {}  # phenotype_hash -> list of creature_ids

# FIX: store genome references so _calculate_diversity() can compute real distances
# (previously stored only IDs and returned a constant 0.5 placeholder)
var genome_registry: Dictionary = {}  # creature_id -> Genome


func register_creature(creature_id: int, genome: Genome, parents: Array = []) -> void:
	"""Register a creature in the genetic database."""
	genetic_tree[creature_id] = parents
	all_creatures.append(creature_id)
	genome_registry[creature_id] = genome

	# Track genetic variants
	var phenotype = _hash_phenotype(genome)
	if phenotype not in species_variants:
		species_variants[phenotype] = []
	species_variants[phenotype].append(creature_id)


func unregister_creature(creature_id: int) -> void:
	"""Remove a dead creature from the database to prevent stale entries."""
	all_creatures.erase(creature_id)
	genome_registry.erase(creature_id)
	# Leave genetic_tree and species_variants intact for lineage history


func _hash_phenotype(genome: Genome) -> String:
	"""Create a hash of the phenotype for clustering similar creatures."""
	var traits = [
		int(genome.get_trait_effectiveness(Constants.TRAIT_SIZE) * 10),
		int(genome.get_trait_effectiveness(Constants.TRAIT_SPEED) * 10),
		int(genome.get_trait_effectiveness(Constants.TRAIT_STRENGTH) * 10)
	]
	return "%d_%d_%d" % traits


func get_population_stats() -> Dictionary:
	"""Calculate current population statistics."""
	return {
		"total_creatures": all_creatures.size(),
		"species_count": species_variants.size(),
		"genetic_diversity": _calculate_diversity()
	}


func _calculate_diversity() -> float:
	"""Calculate average pairwise genetic distance across a random sample.
	FIX: Old code returned a constant 0.5 placeholder on every call.
	New code samples up to 50 random pairs and computes real Genome distances.
	Uses Genome.get_genetic_diversity() which averages per-trait distances
	across all 14 traits, returning 0.0 (identical) … 1.0 (maximally different).
	"""
	var live_ids = all_creatures  # already pruned by unregister_creature
	if live_ids.size() < 2:
		return 0.0

	var sample_size = mini(live_ids.size(), 50)
	var total_diversity = 0.0
	var pair_count = 0

	for _i in range(sample_size):
		var idx1 = randi() % live_ids.size()
		var idx2 = randi() % live_ids.size()
		if idx1 == idx2:
			continue
		var g1: Genome = genome_registry.get(live_ids[idx1])
		var g2: Genome = genome_registry.get(live_ids[idx2])
		if g1 == null or g2 == null:
			continue
		total_diversity += g1.get_genetic_diversity(g2)
		pair_count += 1

	return total_diversity / pair_count if pair_count > 0 else 0.0

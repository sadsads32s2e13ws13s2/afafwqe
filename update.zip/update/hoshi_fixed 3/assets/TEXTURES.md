# Hoshi no Ko - Texture & Sprite Assets

Anime-style pixel art sprites generated for the evolution simulator.

## Creature Sprites (`sprites/creatures/`)

### Life Stages × 4 Variants

| Stage | Size | Description |
|-------|------|-------------|
| `embryo_*.png` | 32×32 | Glowing egg with sparkle effect |
| `juvenile_*.png` | 48×48 | Chibi proportions, big eyes, tiny body |
| `adult_*.png` | 64×64 | Full anime girl with flowing hair, dress |
| `elder_*.png` | 64×64 | Golden highlights, wisdom sparkles |

### Color Variants
- `pink_blue` — Pink hair, blue eyes, pink dress
- `lilac_violet` — Lilac hair, violet eyes, lilac dress  
- `teal_green` — Teal hair, green eyes, mint dress
- `gold_red` — Gold hair, red eyes, gold dress

All sprites also have `@2x` versions (double resolution, pixel-perfect).

## Item Sprites (`sprites/items/`)

| File | Item | Use |
|------|------|-----|
| `berry.png` | Red berry | Food (hunger) |
| `mushroom.png` | Spotted mushroom | Food / potential toxin |
| `herb_healing.png` | Green herb with cross | Healing herb (+regeneration) |
| `water_drop.png` | Blue teardrop | Water (thirst) |
| `star_fragment.png` | Gold star | Rare collectible |
| `egg.png` | Speckled egg | Reproduction item |
| `poison_orb.png` | Purple orb | Toxin hazard |

## Biome Tiles (`sprites/biomes/`)

| File | Biome | Style |
|------|-------|-------|
| `tile_grassland.png` | Grassland | Green with grass blades |
| `tile_forest.png` | Forest | Dark green, tree canopies |
| `tile_desert.png` | Desert | Sandy with dune ripples |
| `tile_cavern.png` | Cavern | Dark stone, stalactites |
| `tile_water.png` | Water | Blue with wave sparkles |

## UI Elements (`sprites/ui/`)

### Health Bars
- `healthbar_frame.png` — 80×12 rounded frame (purple outline)
- `healthbar_full.png` — Green→yellow gradient fill
- `healthbar_half.png` — 50% fill
- `healthbar_low.png` — 10% fill (danger red)

### Emotion Icons (20×20)
Matches `Constants.EMOTION_*`: `fear`, `anger`, `curiosity`, `contentment`, `pain`, `excitement`

### Need Icons (20×20)  
Matches `Constants.NEED_*`: `hunger`, `thirst`, `oxygen`, `temperature`, `rest`, `reproduction`, `shelter`

### Damage Zone Icons (16×16)
Matches `Constants.ZONE_*`: `head`, `torso`, `limb`, `tail`

## Effects (`sprites/effects/`)

| File | Use |
|------|-----|
| `sparkle.png` | Healing / level up particle |
| `blood_drop.png` | Bleeding wound indicator |
| `heal_cross.png` | Healing effect |
| `infection_mist.png` | Infection spreading effect |
| `level_up.png` | Evolution / growth indicator |

## Usage in Godot

```gdscript
# Load a creature sprite by variant and life stage
func get_creature_sprite(life_stage: int, variant: String) -> Texture2D:
    var stage_names = ["embryo", "juvenile", "adult", "elder"]
    var stage = stage_names[min(life_stage, 3)]
    return load("res://assets/sprites/creatures/%s_%s.png" % [stage, variant])

# Load a need icon
func get_need_icon(need_id: int) -> Texture2D:
    var need_name = Constants.NEED_NAMES[need_id].to_lower()
    return load("res://assets/sprites/ui/need_%s.png" % need_name)
```

I need to load the ability that helps with comprehensive analysis and architecture design for complex systems. Let me start by examining your repository structure to understand the current implementation.Похоже, репозиторий только что создан и пуст. Однако вы предоставили подробное техническое задание по переписыванию AI-системы для игры **Hoshi** на Godot 4.6.3. 

Я создам вам **полный архитектурный документ** с дорожной картой внедрения, опираясь на обозначенные проблемы и требования. Это будет технический blueprint, готовый к внедрению в существующий проект.

---

# AI-АРХИТЕКТУРА HOSHI: Полный техдизайн

## ЧАСТЬ 1: ДИАГНОЗ ТЕКУЩЕЙ СИСТЕМЫ

### Выявленные проблемы (по приоритету)

| Проблема | Причина | Результат |
|----------|---------|-----------|
| **Существа умирают от голода** | AI начинает поиск ресурсов при критическом уровне голода | Недостаточно времени на навигацию → смерть |
| **Память не влияет на навигацию** | Episodic memory хранится, но при выборе действия игнорируется | Существа не ходят к известным источникам еды |
| **Wander доминирует** | Нет конкурирующих целей с адекватным приоритетом | Существа блуждают вместо целевого поиска |
| **Нет долгосрочных целей** | Goal выбирается каждый кадр заново | Невозможно планировать маршруты и целеустремлённое поведение |
| **Случайный спавн ресурсов** | Food spawn полностью random без кластеризации | Экосистема не стабилизируется; память о местах не имеет смысла |
| **Интеллект не влияет на поведение** | Neurochemistry и personality только влияют на score, не на logic | High-intelligence существа ведут себя так же, как низкоинтеллектуальные |
| **Нет социального обучения** | Отсутствует механизм transmitting knowledge между особями | Каждое существо учится заново; lineage не наследует успешные стратегии |
| **Нестабильная экосистема** | Ресурсы то в избытке, то в дефиците; существа вымирают волнами | Популяция не растёт; невозможна долгосрочная эволюция |

### Корневые причины архитектуры

```
ТЕКУЩАЯ АРХИТЕКТУРА (неправильная):

Perception (biome checks)
    ↓
Utility Score (hunger%, thirst%, fatigue%)  ← но выбирается ЭТО действие
    ↓
Action Select (wander/search/eat/drink)  ← детерминированная выборка
    ↓
Behavior Execute (move, consume)
    ↓
State Update (hunger -= X)
    ↓
Episodic Memory (record event) ← СОХРАНЯЕТСЯ, НО НЕ ИСПОЛЬЗУЕТСЯ
    ↓
Score Update (+reward)
    ✗ LOOP ЗАМЫКАЕТСЯ НА SCORE, НЕ НА ПОВЕДЕНИЕ
```

**Ключевая ошибка:** Memory → Score (учётно-аналитическая функция), но не Memory → Goal → Action (поведенческая функция).

---

## ЧАСТЬ 2: СРАВНИТЕЛЬНАЯ ТАБЛИЦА ПОДХОДОВ

| Подход | Сильные стороны | Слабые стороны | Пригодность для Hoshi |
|--------|-----------------|----------------|----------------------|
| **Utility AI** | Простая, понятная, быстрая | Не выбирает между похожими целями; нет плана; short-term bias | ✓ БАЗИС (как Layer 1) |
| **Behavior Trees** | Композиционна, читаема, модульна | Нет обучения; статичный приоритет; brittle при сложных условиях | ✓ ИСПОЛНЕНИЕ (как Layer 3) |
| **GOAP/HTN** | Генерирует планы; flexible; учитывает pre-conditions | Сложная для real-time; дорогая по CPU; нужна хорошая domain model | ◐ PARTIAL (для долгосрочных целей только) |
| **Homeostatic RL** | Естественная мотивация; предпочитает баланс | Дорогая обучение; нужны большие наборы данных | ◐ LONG-TERM (для эволюции и тюнинга) |
| **Active Inference** | Агент активно ищет info; curiosity-driven; Bayesian | Очень сложна для реализации в real-time; нужна вероятностная модель | ✗ СЛИШКОМ СЛОЖНО |
| **World Models** | Предсказывает будущее; планирует на основе прогноза | Дорогая обучение; нужна достаточно точная модель | ◐ MEDIUM-TERM (упрощённая версия) |
| **Episodic Memory** | Хранит конкретные события; basis для recognition | Не обобщает; требует агрегации для семантики | ✓ ОСНОВНОЙ МЕХАНИЗМ |
| **Curiosity-driven** | Увеличивает exploration; естественный learning | Может отвлечь от survival; нужны правильные веса | ✓ SECONDARY MOTIVATION |
| **Neuroevolution** | Эволюционирует сети; находит ниши | Медленная сходимость; нужны поколения | ✓ BACKBONE (для long-term) |

### Рекомендация: Гибридный стек

```
┌─────────────────────────────────────────┐
│  LAYER 0: Internal State (homeostasis)  │  ← Физиология & нужды
├─────────────────────────────────────────┤
│  LAYER 1: Utility AI (need prioritizer) │  ← Что нужно в данный момент?
├─────────────────────────────────────────┤
│  LAYER 2: World Model (predictor)       │  ← Где это найти и за сколько?
├─────────────────────────────────────────┤
│  LAYER 3: Memory Query (navigation)     │  ← Что я помню об этом?
├─────────────────────────────────────────┤
│  LAYER 4: Goal & Planner (sequencer)    │  ← Какой план действий?
├─────────────────────────────────────────┤
│  LAYER 5: Behavior Tree (executor)      │  ← Как действовать сейчас?
├─────────────────────────────────────────┤
│  LAYER 6: Learning & Evolution (updater)│  ← Что извлечь из исхода?
└─────────────────────────────────────────┘
```

---

## ЧАСТЬ 3: НОВАЯ DATA MODEL ДЛЯ CREATURE STATE

### 3.1 Internal Needs (Homeostatic State)

```gdscript
class_name CreatureNeeds

var hunger: float = 50.0           # 0-100, target = 30-50
var thirst: float = 50.0           # 0-100, target = 30-50
var fatigue: float = 20.0          # 0-100, target = 5-20
var temperature: float = 37.0      # 35-39 (°C), target = 37.0
var stress: float = 10.0           # 0-100, target = 0-20
var pain: float = 0.0              # 0-100, target = 0
var oxygen: float = 100.0          # 0-100, target = 90-100
var social_need: float = 30.0      # 0-100 (зависит от personality.sociability)

# Predicting internal dynamics
var hunger_rate: float = 0.5       # units/sec
var thirst_rate: float = 0.3       # units/sec
var fatigue_recovery: float = 0.2  # units/sec when resting
var stress_recovery: float = 0.1   # units/sec when safe

# Homeostatic setpoints (зависят от genetics и personality)
var hunger_threshold_critical: float = 85.0
var hunger_threshold_moderate: float = 60.0
var hunger_threshold_mild: float = 40.0

# Time horizon for prediction
var predicted_survival_seconds: float = 300.0  # est time until critical hunger

func update_predicted_survival(world_model: WorldModel) -> void:
	# survival_seconds = (100.0 - hunger) / hunger_rate
	# но с поправкой на расстояние до известных источников еды
	var est_time_to_food = world_model.estimate_time_to_nearest_food_source()
	predicted_survival_seconds = (100.0 - hunger) / hunger_rate
	if est_time_to_food > predicted_survival_seconds:
		predicted_survival_seconds *= 0.8  # risk multiplier
```

### 3.2 Episodic Memory

```gdscript
class_name EpisodicMemory

class MemoryEntry:
	var timestamp: float
	var location: Vector2
	var biome_type: String
	var event_type: String  # "found_food", "found_water", "danger", "met_creature"
	var details: Dictionary
	var emotional_valence: float  # -1 (negative) to +1 (positive)
	var confidence: float = 1.0    # decreases with time
	
	func age(current_time: float) -> float:
		return current_time - timestamp
	
	func confidence_decay(current_time: float, half_life: float = 300.0) -> float:
		var age = age(current_time)
		return confidence * pow(0.5, age / half_life)

var entries: Array[MemoryEntry] = []
var max_entries: int = 500

func record_event(event_type: String, location: Vector2, biome: String, 
                  details: Dictionary, valence: float) -> void:
	var entry = MemoryEntry()
	entry.timestamp = Time.get_ticks_msec() / 1000.0
	entry.location = location
	entry.biome_type = biome
	entry.event_type = event_type
	entry.details = details
	entry.emotional_valence = valence
	
	entries.append(entry)
	if entries.size() > max_entries:
		entries.pop_front()  # FIFO для простоты

func query_locations(event_type: String, current_time: float) -> Array[MemoryEntry]:
	# Вернуть все места, где произошло событие, с поправкой на confidence
	var results: Array[MemoryEntry] = []
	for entry in entries:
		if entry.event_type == event_type:
			var conf = entry.confidence_decay(current_time)
			if conf > 0.1:  # threshold
				results.append(entry)
	return results

func query_nearest_location(event_type: String, from_pos: Vector2, 
                            current_time: float) -> MemoryEntry:
	var candidates = query_locations(event_type, current_time)
	if candidates.is_empty():
		return null
	candidates.sort_custom(func(a, b): 
		return a.location.distance_to(from_pos) < b.location.distance_to(from_pos)
	)
	return candidates[0]
```

### 3.3 Semantic Memory (Places & Routes)

```gdscript
class_name SemanticMemory

class PlaceRecord:
	var location: Vector2
	var biome_type: String
	var place_type: String  # "food_patch", "water_source", "nest", "safe_zone"
	var visits: int = 0
	var last_visit: float = 0.0
	var average_reward: float = 0.0  # how good this place is
	var reputation: float = 0.5      # 0-1, starts neutral
	var resource_abundance: float = 0.0  # estimated remaining resources
	
	func update_reputation(reward: float, learning_rate: float = 0.1) -> void:
		reputation = lerp(reputation, clamp(reward / 100.0, 0.0, 1.0), learning_rate)

class RouteRecord:
	var from_place: Vector2
	var to_place: Vector2
	var distance: float
	var danger_level: float = 0.0  # 0-1
	var traversal_time: float
	var successful_traversals: int = 0
	var failed_traversals: int = 0
	var confidence: float = 0.0  # successful / (successful + failed)
	
	func update_success() -> void:
		successful_traversals += 1
		confidence = float(successful_traversals) / (successful_traversals + failed_traversals)
	
	func update_failure() -> void:
		failed_traversals += 1
		confidence = float(successful_traversals) / (successful_traversals + failed_traversals)

var places: Dictionary[Vector2, PlaceRecord] = {}  # key = grid position
var routes: Array[RouteRecord] = []

func register_place(location: Vector2, place_type: String, biome: String) -> void:
	var key = location.round()
	if not places.has(key):
		var place = PlaceRecord()
		place.location = key
		place.place_type = place_type
		place.biome_type = biome
		places[key] = place

func get_places_by_type(place_type: String) -> Array[PlaceRecord]:
	var results: Array[PlaceRecord] = []
	for place in places.values():
		if place.place_type == place_type:
			results.append(place)
	return results

func register_route(from_pos: Vector2, to_pos: Vector2, 
                    time_taken: float, danger: float) -> void:
	var route = RouteRecord()
	route.from_place = from_pos.round()
	route.to_place = to_pos.round()
	route.distance = from_pos.distance_to(to_pos)
	route.traversal_time = time_taken
	route.danger_level = danger
	routes.append(route)
```

### 3.4 Current Goal & Planning

```gdscript
class_name CreatureGoal

enum GoalType { FIND_FOOD, FIND_WATER, REST, EXPLORE, SOCIAL, FLEE }
enum GoalState { INACTIVE, ACTIVE, COMPLETED, FAILED, CANCELLED }

class Goal:
	var goal_type: GoalType
	var target_location: Vector2
	var priority: float  # 0-1
	var timeout: float  # seconds until goal expires
	var confidence: float  # 0-1, how sure we are about success
	var state: GoalState = GoalState.ACTIVE
	var created_time: float
	var completion_condition: Callable  # func that returns bool
	
	func is_expired(current_time: float) -> bool:
		return (current_time - created_time) > timeout
	
	func is_completed() -> bool:
		return state == GoalState.COMPLETED or completion_condition.call()

var current_goal: Goal = null
var goal_history: Array[Goal] = []  # for learning

func set_goal(goal_type: GoalType, target: Vector2, 
              priority: float, timeout: float = 60.0,
              confidence: float = 0.5) -> void:
	var new_goal = Goal()
	new_goal.goal_type = goal_type
	new_goal.target_location = target
	new_goal.priority = priority
	new_goal.timeout = timeout
	new_goal.confidence = confidence
	new_goal.created_time = Time.get_ticks_msec() / 1000.0
	
	if current_goal and current_goal.state == GoalState.ACTIVE:
		goal_history.append(current_goal)
	
	current_goal = new_goal

func cancel_goal(reason: String) -> void:
	if current_goal:
		current_goal.state = GoalState.CANCELLED
		print("%s cancelled goal: %s" % [reason, current_goal.goal_type])
```

### 3.5 Planned Action Sequence

```gdscript
class_name ActionPlan

class ActionStep:
	var action_type: String  # "move_to", "search", "eat", "rest", "wait"
	var target_location: Vector2
	var duration_estimate: float  # seconds
	var prerequisite_state: Dictionary  # e.g., {"hunger": "<60"}
	
	func is_satisfied(needs: CreatureNeeds) -> bool:
		# Check if prerequisites are met
		if prerequisite_state.has("hunger"):
			if prerequisite_state["hunger"] > needs.hunger:
				return false
		return true

var steps: Array[ActionStep] = []
var current_step_index: int = 0
var plan_created_time: float = 0.0

func add_step(action_type: String, target: Vector2, duration: float) -> void:
	var step = ActionStep()
	step.action_type = action_type
	step.target_location = target
	step.duration_estimate = duration
	steps.append(step)

func get_current_step() -> ActionStep:
	if current_step_index < steps.size():
		return steps[current_step_index]
	return null

func advance_step() -> bool:
	current_step_index += 1
	return current_step_index < steps.size()

func is_plan_complete() -> bool:
	return current_step_index >= steps.size()

func is_plan_stale(current_time: float, max_age: float = 120.0) -> bool:
	return (current_time - plan_created_time) > max_age
```

### 3.6 Learning & Reinforcement

```gdscript
class_name CreatureLearning

class BehaviorWeight:
	var behavior_id: String  # "go_to_food", "search_radius_100"
	var weight: float = 0.5  # 0-1
	var success_count: int = 0
	var failure_count: int = 0
	var last_used_time: float = 0.0
	
	func update_weight(success: bool, learning_rate: float = 0.1) -> void:
		if success:
			success_count += 1
			weight = lerp(weight, 1.0, learning_rate)
		else:
			failure_count += 1
			weight = lerp(weight, 0.0, learning_rate)
	
	func get_reliability() -> float:
		var total = success_count + failure_count
		if total == 0:
			return 0.5
		return float(success_count) / total

var behavior_weights: Dictionary[String, BehaviorWeight] = {}
var recent_outcomes: Array[Dictionary] = []  # for analysis

func record_outcome(goal_type: String, success: bool, 
                    reward: float, context: Dictionary) -> void:
	var outcome = {
		"timestamp": Time.get_ticks_msec() / 1000.0,
		"goal_type": goal_type,
		"success": success,
		"reward": reward,
		"context": context
	}
	recent_outcomes.append(outcome)
	if recent_outcomes.size() > 100:
		recent_outcomes.pop_front()

func reinforce_behavior(behavior_id: String, success: bool, 
                        learning_rate: float = 0.1) -> void:
	if not behavior_weights.has(behavior_id):
		var bw = BehaviorWeight()
		bw.behavior_id = behavior_id
		behavior_weights[behavior_id] = bw
	
	behavior_weights[behavior_id].update_weight(success, learning_rate)

func get_behavior_weight(behavior_id: String) -> float:
	if not behavior_weights.has(behavior_id):
		return 0.5
	return behavior_weights[behavior_id].weight

func analyze_learning_progress() -> Dictionary:
	# Return stats about what this creature has learned
	var total_outcomes = recent_outcomes.size()
	if total_outcomes == 0:
		return {"success_rate": 0.0}
	
	var successes = recent_outcomes.filter(func(o): return o["success"]).size()
	return {
		"success_rate": float(successes) / total_outcomes,
		"total_experiences": total_outcomes,
		"average_reward": recent_outcomes.map(func(o): return o["reward"]).reduce(func(a, b): return a + b) / total_outcomes
	}
```

### 3.7 Full Creature Brain State

```gdscript
class_name CreatureBrainState

var creature_id: String
var genetics: CreatureGenetics
var personality: CreaturePersonality
var physiology: CreaturePhysiology

# LAYER 0: Homeostasis
var needs: CreatureNeeds

# LAYER 3: Memory
var episodic_memory: EpisodicMemory
var semantic_memory: SemanticMemory

# LAYER 4: Goals
var goal_system: CreatureGoal
var action_plan: ActionPlan

# LAYER 6: Learning
var learning: CreatureLearning

# World context (updated each frame)
var current_position: Vector2
var current_biome: String
var nearby_creatures: Array[Node2D] = []
var nearby_threats: Array[Node2D] = []
var nearby_food: Array[Node2D] = []
var last_decision_time: float = 0.0
```

---

## ЧАСТЬ 4: UPDATE LOOP ПО ШАГАМ

### 4.1 Frame Update Architecture

```
┌─────────────────────────────────────────┐
│  STEP 0: Perception                     │
│  - Update nearby_creatures, food, threats│
│  - Update current_biome, temperature    │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 1: Homeostatic Update             │
│  - hunger += hunger_rate * delta         │
│  - thirst += thirst_rate * delta         │
│  - fatigue changes based on activity     │
│  - Check for critical needs              │
│  - Update predicted_survival_seconds     │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 2: Memory Query                   │
│  - Query known food/water sources        │
│  - Calculate confidence in locations     │
│  - Get known safe routes                 │
│  - Sense "anomalies" in environment      │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 3: World Model Predict             │
│  - est_time_to_food = distance / speed   │
│  - est_risk_on_path = biome_danger + ... │
│  - est_survival_with_plan = f(...)       │
│  - curiosity_bonus = novelty_score       │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 4: Need Prioritization (Utility)  │
│  - Calculate need_score for each need    │
│  - Select PRIMARY NEED based on utility  │
│  - Determine if need is CRITICAL         │
│  - Override with SURVIVAL INSTINCT if cr │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 5: Goal Selection                 │
│  - Check if current_goal is still valid  │
│  - If not, generate new goal from need   │
│  - Query memory for target_location      │
│  - Update goal.confidence based on memory│
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 6: Action Planning                │
│  - If no plan or plan is stale: replan  │
│  - Generate action sequence to goal      │
│  - Include contingencies (alternate food)│
│  - Mark plan as current                  │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 7: Behavior Execution             │
│  - Get current_step from plan           │
│  - Execute action (move, search, eat)   │
│  - Update animation state               │
│  - Check for step completion            │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 8: Outcome Detection              │
│  - Check if goal_reached                │
│  - Check if threat detected             │
│  - Check if resource found              │
│  - Determine success/failure             │
└─────────────────────────────────────────┘
                ↓
┌─────────────────────────────────────────┐
│  STEP 9: Learning & Memory Update       │
│  - Record episodic event if significant │
│  - Update behavior weights (reinforce)  │
│  - Update place reputation              │
│  - Update route success metrics         │
│  - Broadcast discovery to nearby peers  │
└─────────────────────────────────────────┘
```

### 4.2 GDScript Implementation: Main Loop

```gdscript
# in creature.gd
extends Node2D
class_name Creature

var brain: CreatureBrainState
var dt_decision: float = 0.2  # decision every 200ms
var time_since_decision: float = 0.0

func _physics_process(delta: float) -> void:
	# STEP 0: Perception (every frame)
	_update_perception()
	
	# STEP 1: Homeostatic Update (every frame)
	_update_homeostasis(delta)
	
	# STEP 2-9: Decision making (throttled)
	time_since_decision += delta
	if time_since_decision >= dt_decision:
		_make_decision()
		time_since_decision = 0.0
	
	# STEP 7: Execute current action (every frame)
	_execute_action(delta)
	
	# Check for death
	if brain.needs.hunger >= 100.0 or brain.needs.thirst >= 100.0:
		_die("starvation")

func _update_perception() -> void:
	var vision_range = 50.0 * (1.0 + brain.genetics.search_radius_modifier)
	var space_state = get_world_2d().direct_space_state
	
	# Update nearby creatures
	var shape_query = PhysicsShapeQueryParameters2D.new()
	shape_query.shape = CircleShape2D.new()
	shape_query.shape.radius = vision_range
	shape_query.transform = global_transform
	
	var results = space_state.intersect_shape(shape_query)
	brain.nearby_creatures.clear()
	brain.nearby_food.clear()
	brain.nearby_threats.clear()
	
	for result in results:
		var collider = result["collider"]
		if collider is Creature and collider != self:
			brain.nearby_creatures.append(collider)
		elif collider.is_in_group("food"):
			brain.nearby_food.append(collider)
		elif collider.is_in_group("threat"):
			brain.nearby_threats.append(collider)
	
	# Update biome
	var biome_area = get_biome_at(global_position)
	brain.current_biome = biome_area.biome_type if biome_area else "unknown"
	brain.current_position = global_position

func _update_homeostasis(delta: float) -> void:
	# Apply metabolic costs
	brain.needs.hunger += brain.needs.hunger_rate * delta
	brain.needs.thirst += brain.needs.thirst_rate * delta
	
	# Activity modifier (if moving, hunger increases)
	if velocity.length() > 10.0:
		brain.needs.fatigue += 0.5 * delta
	else:
		brain.needs.fatigue -= brain.needs.fatigue_recovery * delta
	
	# Stress from threats
	if not brain.nearby_threats.is_empty():
		brain.needs.stress += 2.0 * delta
	else:
		brain.needs.stress -= brain.needs.stress_recovery * delta
	
	# Clamp values
	brain.needs.hunger = clamp(brain.needs.hunger, 0.0, 100.0)
	brain.needs.thirst = clamp(brain.needs.thirst, 0.0, 100.0)
	brain.needs.fatigue = clamp(brain.needs.fatigue, 0.0, 100.0)
	brain.needs.stress = clamp(brain.needs.stress, 0.0, 100.0)
	
	# Update predicted survival
	brain.needs.update_predicted_survival(_get_world_model())

func _make_decision() -> void:
	# STEP 2: Query memory
	var food_memories = brain.episodic_memory.query_locations("found_food", _current_time())
	var water_memories = brain.episodic_memory.query_locations("found_water", _current_time())
	
	# STEP 3: World model
	var world_model = _get_world_model()
	var est_time_to_food = world_model.estimate_time_to_nearest_food()
	var est_survival_time = brain.needs.predicted_survival_seconds
	
	# STEP 4: Prioritize needs
	var primary_need = _select_primary_need()
	
	# STEP 5: Select goal
	_select_goal(primary_need, food_memories, water_memories, world_model)
	
	# STEP 6: Plan
	_generate_action_plan()

func _select_primary_need() -> String:
	# Returns: "hunger", "thirst", "fatigue", "social", "explore"
	
	var need_scores: Dictionary = {
		"hunger": _score_need("hunger"),
		"thirst": _score_need("thirst"),
		"fatigue": _score_need("fatigue"),
		"social": _score_need("social"),
		"explore": _score_need("explore")
	}
	
	# Safety check: if critical need, override everything
	if brain.needs.hunger >= brain.needs.hunger_threshold_critical:
		return "hunger"
	if brain.needs.thirst >= 80.0:
		return "thirst"
	
	# Otherwise, select highest score
	var max_need = "explore"
	var max_score = 0.0
	for need_name in need_scores:
		if need_scores[need_name] > max_score:
			max_score = need_scores[need_name]
			max_need = need_name
	
	return max_need

func _score_need(need_name: String) -> float:
	# Utility formula: urgency * (intelligence bonus) - (recent_satisfaction)
	var urgency = 0.0
	var recent_success_penalty = 0.0
	
	match need_name:
		"hunger":
			urgency = (brain.needs.hunger / 100.0) * \
			          (1.0 + brain.genetics.intelligence_modifier * 0.5)
			# If we recently found food, reduce score
			var recent_food = brain.episodic_memory.query_locations("found_food", _current_time())
			if not recent_food.is_empty():
				recent_success_penalty = 0.2
		
		"thirst":
			urgency = (brain.needs.thirst / 100.0) * \
			          (1.0 + brain.genetics.intelligence_modifier * 0.3)
		
		"fatigue":
			urgency = (brain.needs.fatigue / 100.0)
		
		"social":
			urgency = (brain.personality.sociability / 100.0) * \
			          (1.0 if not brain.nearby_creatures.is_empty() else 0.5)
		
		"explore":
			# Curiosity driven (but only when other needs are low)
			var base_curiosity = (1.0 - brain.needs.hunger / 100.0) * \
			                     (brain.genetics.curiosity_modifier)
			urgency = base_curiosity * 0.3  # explore is secondary
	
	return max(urgency - recent_success_penalty, 0.0)

func _select_goal(primary_need: String, 
                  food_memories: Array[EpisodicMemory.MemoryEntry],
                  water_memories: Array[EpisodicMemory.MemoryEntry],
                  world_model: WorldModel) -> void:
	
	var target: Vector2 = Vector2.ZERO
	var goal_type: CreatureGoal.GoalType
	var confidence: float = 0.5
	
	match primary_need:
		"hunger":
			goal_type = CreatureGoal.GoalType.FIND_FOOD
			
			# Strategy 1: If remember food location, go there
			if not food_memories.is_empty():
				target = food_memories[0].location
				confidence = 0.8
			# Strategy 2: Otherwise, search nearby or expand radius
			else:
				var search_radius = 40.0 * (1.0 + brain.genetics.search_radius_modifier)
				target = global_position + Vector2.from_angle(randf() * TAU) * search_radius
				confidence = 0.3
		
		"thirst":
			goal_type = CreatureGoal.GoalType.FIND_WATER
			if not water_memories.is_empty():
				target = water_memories[0].location
				confidence = 0.8
			else:
				target = global_position + Vector2.from_angle(randf() * TAU) * 50.0
				confidence = 0.3
		
		"fatigue":
			goal_type = CreatureGoal.GoalType.REST
			# Find known safe zone
			var safe_zones = brain.semantic_memory.get_places_by_type("safe_zone")
			if not safe_zones.is_empty():
				target = safe_zones[0].location
				confidence = 0.7
			else:
				target = global_position
				confidence = 0.5
		
		_:
			goal_type = CreatureGoal.GoalType.EXPLORE
			target = global_position + Vector2.from_angle(randf() * TAU) * 60.0
			confidence = 0.4
	
	brain.goal_system.set_goal(goal_type, target, 0.8, 60.0, confidence)

func _generate_action_plan() -> void:
	# Simple plan for now: move to target
	var plan = ActionPlan.new()
	plan.plan_created_time = _current_time()
	
	if brain.goal_system.current_goal:
		var target = brain.goal_system.current_goal.target_location
		var distance = global_position.distance_to(target)
		var speed = 50.0  # pixels/sec
		var est_time = distance / speed
		
		plan.add_step("move_to", target, est_time)
		
		# Add action based on goal type
		match brain.goal_system.current_goal.goal_type:
			CreatureGoal.GoalType.FIND_FOOD:
				plan.add_step("search", target, 5.0)
				plan.add_step("eat", target, 2.0)
			
			CreatureGoal.GoalType.FIND_WATER:
				plan.add_step("search", target, 5.0)
				plan.add_step("drink", target, 2.0)
			
			CreatureGoal.GoalType.REST:
				plan.add_step("rest", target, 10.0)
	
	brain.action_plan = plan

func _execute_action(delta: float) -> void:
	var step = brain.action_plan.get_current_step()
	if not step:
		return
	
	match step.action_type:
		"move_to":
			var direction = (step.target_location - global_position).normalized()
			velocity = direction * 50.0  # speed
			position += velocity * delta
		
		"search":
			# Check if found food
			if not brain.nearby_food.is_empty():
				brain.action_plan.advance_step()
		
		"eat":
			# Consume nearby food
			if not brain.nearby_food.is_empty():
				var food = brain.nearby_food[0]
				brain.needs.hunger = max(brain.needs.hunger - 20.0, 0.0)
				
				# Record success
				brain.learning.record_outcome(
					"find_food", true, 20.0,
					{"location": global_position, "biome": brain.current_biome}
				)
				
				# Record memory
				brain.episodic_memory.record_event(
					"found_food", global_position, brain.current_biome,
					{"food_type": "standard"},
					1.0
				)
				
				food.queue_free()
				brain.action_plan.advance_step()
		
		"rest":
			brain.needs.fatigue = max(brain.needs.fatigue - 5.0 * delta, 0.0)
			velocity = Vector2.ZERO

func _current_time() -> float:
	return Time.get_ticks_msec() / 1000.0

func _get_world_model() -> WorldModel:
	# Simplified: query GameManager for current resource distribution
	return GameManager.world_model
```

---

## ЧАСТЬ 5: КЛЮЧЕВЫЕ GDScript ПАТТЕРНЫ

### 5.1 Scoring Needs с Предсказанием

```gdscript
func _calculate_need_urgency_with_prediction(need_name: String, 
                                              world_model: WorldModel) -> float:
	"""
	Не просто текущее значение, а: текущее + предсказанное + риск
	"""
	match need_name:
		"hunger":
			var current_urgency = brain.needs.hunger / 100.0
			
			# Predict: сколько времени до критического уровня?
			var time_to_critical = (brain.needs.hunger_threshold_critical - brain.needs.hunger) / \
			                       brain.needs.hunger_rate
			
			# Query world model: насколько быстро я могу найти еду?
			var est_time_to_food = world_model.estimate_time_to_nearest_food()
			
			# If predicted time to food > time to critical: BOOST URGENCY
			var risk_factor = 1.0
			if est_time_to_food > time_to_critical * 0.8:
				risk_factor = 2.0  # DANGER: may not reach food in time
			
			# Intelligence bonus: smart creatures start searching earlier
			var intelligence_bonus = 1.0 + brain.genetics.intelligence_modifier * 0.3
			
			var predicted_urgency = current_urgency * risk_factor * intelligence_bonus
			
			return predicted_urgency
	
	return 0.0

# Usage:
var urgency = _calculate_need_urgency_with_prediction("hunger", world_model)
```

### 5.2 Memory as Navigation Goal

```gdscript
func _select_target_from_memory(need_type: String) -> Vector2:
	"""
	Вместо random wandering, query episodic memory для целей
	"""
	var event_type = "found_" + need_type  # "found_food" или "found_water"
	var candidates = brain.episodic_memory.query_locations(event_type, _current_time())
	
	if candidates.is_empty():
		# No memory, fallback to random search
		return global_position + Vector2.from_angle(randf() * TAU) * 50.0
	
	# Find nearest remembered location with highest confidence
	candidates.sort_custom(func(a, b):
		var conf_a = a.confidence_decay(_current_time())
		var dist_a = a.location.distance_to(global_position)
		
		var conf_b = b.confidence_decay(_current_time())
		var dist_b = b.location.distance_to(global_position)
		
		# Prefer: high confidence + near distance
		var score_a = conf_a - dist_a / 200.0
		var score_b = conf_b - dist_b / 200.0
		
		return score_a > score_b
	)
	
	return candidates[0].location

# Usage:
var food_target = _select_target_from_memory("food")
```

### 5.3 Reinforcement Learning: Outcome → Weight Update

```gdscript
func _record_goal_outcome(goal: CreatureGoal, success: bool, reward: float) -> void:
	"""
	После завершения goal, обновить веса поведения и память мест
	"""
	var behavior_id = _get_behavior_id_for_goal(goal)
	brain.learning.reinforce_behavior(behavior_id, success, learning_rate = 0.15)
	
	# Record outcome for analysis
	brain.learning.record_outcome(
		goal.goal_type,
		success,
		reward,
		{
			"location": goal.target_location,
			"biome": brain.current_biome,
			"time_taken": _current_time() - goal.created_time,
			"intelligence": brain.genetics.intelligence_modifier
		}
	)
	
	# Update place reputation in semantic memory
	var place_key = goal.target_location.round()
	if brain.semantic_memory.places.has(place_key):
		var place = brain.semantic_memory.places[place_key]
		place.update_reputation(reward, learning_rate = 0.2)
		place.visits += 1

func _get_behavior_id_for_goal(goal: CreatureGoal) -> String:
	match goal.goal_type:
		CreatureGoal.GoalType.FIND_FOOD:
			return "go_to_remembered_food_%d" % int(goal.confidence * 10)
		CreatureGoal.GoalType.FIND_WATER:
			return "go_to_remembered_water_%d" % int(goal.confidence * 10)
		_:
			return "explore"
```

### 5.4 Social Broadcasting: Share Discovery

```gdscript
func _broadcast_discovery(event_type: String, location: Vector2, quality: float) -> void:
	"""
	Существо нашло что-то хорошее → рассказать соседям
	Social learning: другие существа могут "услышать" об этом
	"""
	var broadcast_range = 80.0 * (1.0 + brain.personality.sociability / 100.0)
	
	for nearby_creature in brain.nearby_creatures:
		var distance = global_position.distance_to(nearby_creature.global_position)
		if distance > broadcast_range:
			continue
		
		# Probability of successful transmission depends on:
		# - Social personality of both creatures
		# - Intelligence of receiver
		var transmission_chance = 0.5 + \
		                         brain.personality.sociability / 200.0 + \
		                         nearby_creature.brain.genetics.intelligence_modifier * 0.2
		
		if randf() < transmission_chance:
			# Add memory entry to neighbor's episodic memory
			nearby_creature.brain.episodic_memory.record_event(
				event_type,
				location,
				brain.current_biome,
				{"learned_from": self.brain.creature_id},
				quality / 100.0  # convert to 0-1
			)
			
			# Mark as "socially learned"
			print("%s learned about %s from %s (%.1f%% confidence)" % \
			      [nearby_creature.brain.creature_id, event_type, 
			       brain.creature_id, transmission_chance * 100.0])

# Usage: after eating
_broadcast_discovery("found_food", global_position, 80.0)
```

### 5.5 Persistent Resource Patches & Regeneration

```gdscript
# in world.gd or game_manager.gd

class_name ResourcePatch

var location: Vector2
var resource_type: String  # "food" or "water"
var resource_count: int = 5
var regeneration_rate: float = 0.5  # resources/sec
var last_harvest_time: float = 0.0
var biome_type: String

func spawn_resource() -> Node2D:
	resource_count -= 1
	# Return actual food/water node to be added to scene
	var food = Food.new()
	food.global_position = location + Vector2.from_angle(randf() * TAU) * 10.0
	food.patch = self
	return food

func regenerate(delta: float) -> void:
	resource_count += int(regeneration_rate * delta)
	resource_count = min(resource_count, 10)  # max capacity

var patches: Array[ResourcePatch] = []

func initialize_world() -> void:
	# Create persistent resource patches instead of random spawn
	var patch_locations = [
		Vector2(100, 200),  # forest patch
		Vector2(400, 150),  # water source
		Vector2(300, 400),  # desert patch
	]
	
	for loc in patch_locations:
		var patch = ResourcePatch()
		patch.location = loc
		patch.resource_type = "food" if randf() > 0.3 else "water"
		patch.resource_count = randi_range(3, 8)
		patch.biome_type = get_biome_at(loc).type
		patches.append(patch)
		
		# Spawn initial resources
		for i in range(patch.resource_count):
			var resource = patch.spawn_resource()
			add_child(resource)

func _process(delta: float) -> void:
	# Regenerate patches
	for patch in patches:
		patch.regenerate(delta)
		
		# Spawn new resources if capacity available
		if patch.resource_count > 0 and randf() < 0.1:  # 10% chance per frame
			var resource = patch.spawn_resource()
			add_child(resource)

# Broadcast patch locations to creatures periodically
func _on_creature_enters_patch(creature: Creature, patch: ResourcePatch) -> void:
	creature.brain.semantic_memory.register_place(
		patch.location,
		"food_patch" if patch.resource_type == "food" else "water_source",
		patch.biome_type
	)
	
	# Broadcast to others
	creature._broadcast_discovery(
		"found_" + patch.resource_type,
		patch.location,
		80.0
	)
```

### 5.6 Route Learning & Confidence

```gdscript
func _record_route_taken(from_pos: Vector2, to_pos: Vector2, 
                         time_taken: float, success: bool) -> void:
	"""
	После успешного перемещения, зарегистрировать маршрут как надежный
	"""
	var existing_route = null
	for route in brain.semantic_memory.routes:
		if route.from_place.distance_to(from_pos) < 10.0 and \
		   route.to_place.distance_to(to_pos) < 10.0:
			existing_route = route
			break
	
	if existing_route:
		if success:
			existing_route.update_success()
		else:
			existing_route.update_failure()
	else:
		var route = SemanticMemory.RouteRecord()
		route.from_place = from_pos.round()
		route.to_place = to_pos.round()
		route.distance = from_pos.distance_to(to_pos)
		route.traversal_time = time_taken
		route.danger_level = _estimate_danger_on_route(from_pos, to_pos)
		
		if success:
			route.update_success()
		else:
			route.update_failure()
		
		brain.semantic_memory.routes.append(route)

func _select_safest_route_to_target(target: Vector2) -> SemanticMemory.RouteRecord:
	"""
	Умное выбирание маршрута, предпочитая безопасные и проверенные
	"""
	var candidate_routes = brain.semantic_memory.routes.filter(
		func(r): return r.to_place.distance_to(target) < 20.0
	)
	
	if candidate_routes.is_empty():
		return null
	
	# Score routes: confidence * (1 - danger_level)
	candidate_routes.sort_custom(func(a, b):
		var score_a = a.confidence * (1.0 - a.danger_level)
		var score_b = b.confidence * (1.0 - b.danger_level)
		return score_a > score_b
	)
	
	return candidate_routes[0]
```

### 5.7 Place Reputation System

```gdscript
func _update_place_reputation(location: Vector2, success: bool, reward: float) -> void:
	"""
	После посещения места, обновить его репутацию
	Места с хорошей репутацией выбираются чаще
	"""
	var place_key = location.round()
	if not brain.semantic_memory.places.has(place_key):
		brain.semantic_memory.register_place(
			location, "unknown", brain.current_biome
		)
	
	var place = brain.semantic_memory.places[place_key]
	
	# Update metrics
	place.visits += 1
	place.last_visit = _current_time()
	
	if success:
		place.average_reward = lerp(place.average_reward, reward, 0.2)
		place.update_reputation(reward, learning_rate = 0.15)
		place.resource_abundance = min(place.resource_abundance + 10.0, 100.0)
	else:
		place.update_reputation(-30.0, learning_rate = 0.1)
		place.resource_abundance = max(place.resource_abundance - 20.0, 0.0)
	
	print("Place %s reputation: %.2f, visits: %d" % 
	      [place_key, place.reputation, place.visits])

func _select_best_known_place(place_type: String) -> SemanticMemory.PlaceRecord:
	"""
	Выбрать место с лучшей репутацией и достаточной доступностью ресурсов
	"""
	var candidates = brain.semantic_memory.get_places_by_type(place_type)
	if candidates.is_empty():
		return null
	
	# Score: reputation * resource_abundance
	candidates.sort_custom(func(a, b):
		var score_a = a.reputation * (a.resource_abundance / 100.0)
		var score_b = b.reputation * (b.resource_abundance / 100.0)
		return score_a > score_b
	)
	
	return candidates[0]
```

---

## ЧАСТЬ 6: ROADMAP ВНЕДРЕНИЯ (5 этапов)

### PHASE 0: Diagnostics (День 1)

**Цель:** Понять текущее состояние кода

```
□ Запустить текущий проект
□ Включить debug визуализацию (hunger/thirst levels)
□ Включить логирование всех решений AI
□ Собрать метрики: avg survival time, wander %, memory usage
□ Выявить: где существа умирают? Что игнорируется?
```

**Результат:** Baseline metrics

### PHASE 1: Memory Integration (Дни 2-3)

**Цель:** Замкнуть цикл memory → navigation

```
□ Создать SemanticMemory.gd с PlaceRecord и RouteRecord
□ Добавить _select_target_from_memory() в creature decision
□ Добавить episodic_memory.record_event() при еде/питье
□ Добавить _record_route_taken() при успешном перемещении
□ Добавить ui debug: показать запомненные места на экране
□ Тест: существа должны начать ходить к запомненным местам
```

**Ожидаемый результат:**
- Survival time +30-50%
- Wander % -20%
- Повторное использование маршрутов

### PHASE 2: Proactive Need Scoring (Дни 4-5)

**Цель:** Существа начнут действовать до критического состояния

```
□ Заменить simple need scoring на _calculate_need_urgency_with_prediction()
□ Добавить time_to_critical prediction
□ Добавить est_time_to_resource из world model
□ Добавить risk_factor если нет известных источников
□ Добавить intelligence_bonus: умные существа ищут раньше
□ Тест: проверить, что голодные существа начинают искать до критички
```

**Ожидаемый результат:**
- Critical hunger deaths -80%
- Survival time +50-100%

### PHASE 3: Resource Clustering & Regeneration (Дни 6-7)

**Цель:** Стабилизировать экосистему

```
□ Заменить random food spawn на persistent patches
□ Создать ResourcePatch class с regeneration
□ Разместить 5-10 patches в разных biomes
□ Добавить _broadcast_discovery() для социального обучения
□ Добавить place_reputation система
□ Тест: проверить, что популяция не вымирает
```

**Ожидаемый результат:**
- Population stability +200%
- Ecosystem cycles become predictable
- Memory becomes meaningful (patches actually persist)

### PHASE 4: Goal Persistence & Planning (Дни 8-10)

**Цель:** Замкнуть goal → plan → execution → learning

```
□ Внедрить CreatureGoal.gd с timeout и state tracking
□ Внедрить ActionPlan.gd с multi-step sequences
□ Добавить goal validity checking (don't abandon goals too easily)
□ Добавить simple planner: goal → sequence of move/search/consume
□ Добавить _record_goal_outcome() с weight reinforcement
□ Добавить behavior weight tracking
□ Тест: проверить, что цели persists и обучение работает
```

**Ожидаемый результат:**
- Goal persistence >60% (goals completed, not abandoned)
- Learning visible: repetition of successful behaviors
- Route reuse +80%

### PHASE 5: Evolution & Genetic Tuning (Дни 11-14)

**Цель:** Популяция эволюционирует в разных стратегиях

```
□ Связать genetics напрямую с AI параметрами
□ High intelligence → выбирает раньше, помнит лучше
□ High sociability → лучше делится информацией
□ High curiosity → explores при сытости
□ High search_radius → ищет дальше
□ Добавить генетический отбор: успешные существа оставляют потомков
□ Тест: проверить, что разные линии развивают разные стратегии
```

**Ожидаемый результат:**
- Population branches into specialized phenotypes
- Average fitness improves over generations
- Emergent behaviors (territorial, nomadic, social etc)

---

## ЧАСТЬ 7: КОНФИГУРИРУЕМЫЕ ПАРАМЕТРЫ

```gdscript
# constants.gd (or creature_config.gd)

class_name CreatureAIConstants

# ============ HOMEOSTATIC PARAMETERS ============
const HUNGER_RATE = 0.5                    # units/sec
const THIRST_RATE = 0.3                    # units/sec
const FATIGUE_RECOVERY_RATE = 0.2          # units/sec while resting
const STRESS_RECOVERY_RATE = 0.1           # units/sec while safe

const HUNGER_THRESHOLD_CRITICAL = 85.0     # trigger panic
const HUNGER_THRESHOLD_MODERATE = 60.0     # increase urgency
const HUNGER_THRESHOLD_MILD = 40.0         # start looking

const THIRST_THRESHOLD_CRITICAL = 80.0
const THIRST_THRESHOLD_MODERATE = 55.0

# ============ DECISION PARAMETERS ============
const DECISION_THROTTLE_DELTA = 0.2        # decision every 200ms

const NEED_SCORE_HUNGER_WEIGHT = 1.0
const NEED_SCORE_THIRST_WEIGHT = 0.9
const NEED_SCORE_FATIGUE_WEIGHT = 0.3
const NEED_SCORE_SOCIAL_WEIGHT = 0.2
const NEED_SCORE_EXPLORE_WEIGHT = 0.15

# ============ MEMORY PARAMETERS ============
const EPISODIC_MEMORY_MAX_ENTRIES = 500
const EPISODIC_MEMORY_HALF_LIFE = 300.0    # seconds until confidence halves
const SEMANTIC_MEMORY_CONFIDENCE_THRESHOLD = 0.1

# ============ GOAL & PLANNING ============
const GOAL_DEFAULT_TIMEOUT = 60.0          # seconds
const GOAL_PROACTIVE_MARGIN = 1.2          # multiply est_time_to_food by this
const PLAN_MAX_AGE = 120.0                 # replan if older

# ============ WORLD MODEL ============
const CREATURE_SPEED = 50.0                # pixels/sec
const VISION_RANGE_BASE = 50.0             # pixels
const VISION_RANGE_MODIFIER_PER_INTELLIGENCE = 0.3

# ============ RESOURCE CLUSTERING ============
const RESOURCE_PATCHES_COUNT = 8
const RESOURCE_PATCH_REGENERATION_RATE = 0.5  # resources/sec
const RESOURCE_PATCH_MAX_CAPACITY = 10

# ============ SOCIAL LEARNING ============
const SOCIAL_BROADCAST_RANGE_BASE = 80.0
const SOCIAL_BROADCAST_TRANSMISSION_CHANCE_BASE = 0.5
const SOCIAL_TRANSMISSION_MULTIPLIER_PER_SOCIABILITY = 0.002
const SOCIAL_TRANSMISSION_MULTIPLIER_PER_INTELLIGENCE = 0.2

# ============ LEARNING & REINFORCEMENT ============
const BEHAVIOR_WEIGHT_LEARNING_RATE = 0.1
const PLACE_REPUTATION_LEARNING_RATE = 0.15
const ROUTE_CONFIDENCE_LEARNING_RATE = 0.2

# ============ CURIOSITY ============
const CURIOSITY_BONUS_MULTIPLIER = 0.3
const CURIOSITY_NOVELTY_THRESHOLD = 50.0  # min distance for "new" location
const CURIOSITY_ACTIVATION_HUNGER_LEVEL = 30.0  # only when hunger below this

# ============ GENETICS INFLUENCE RANGES ============
# These determine how much genetics affect AI behavior
const INTELLIGENCE_EFFECT_MIN = 0.7
const INTELLIGENCE_EFFECT_MAX = 1.5
const SOCIABILITY_EFFECT_MIN = 0.5
const SOCIABILITY_EFFECT_MAX = 1.5
const CURIOSITY_EFFECT_MIN = 0.0
const CURIOSITY_EFFECT_MAX = 2.0
const SEARCH_RADIUS_EFFECT_MIN = 0.5
const SEARCH_RADIUS_EFFECT_MAX = 2.0

# ============ DEBUGING ============
const DEBUG_DRAW_MEMORY = true
const DEBUG_DRAW_GOALS = true
const DEBUG_LOG_DECISIONS = false
const DEBUG_LOG_LEARNING = false
const DEBUG_DRAW_ROUTES = false
```

---

## ЧАСТЬ 8: МЕТРИКИ И ТЕСТИРОВАНИЕ

### 8.1 Метрики выживания и обучения

```gdscript
class_name CreatureMetrics

var creature_id: String
var birth_time: float
var death_time: float = -1.0

# Homeostatic metrics
var avg_hunger_over_lifetime: float = 0.0
var avg_thirst_over_lifetime: float = 0.0
var critical_hunger_events: int = 0
var starvation_deaths: int = 0

# Behavior metrics
var total_distance_traveled: float = 0.0
var goals_completed: int = 0
var goals_failed: int = 0
var average_goal_duration: float = 0.0
var wander_time_percent: float = 0.0
var goal_directed_time_percent: float = 0.0

# Memory metrics
var episodic_memories_recorded: int = 0
var places_discovered: int = 0
var routes_learned: int = 0
var memory_to_navigation_conversions: int = 0  # times memory led to successful goal

# Learning metrics
var behaviors_learned: int = 0
var average_learning_rate: float = 0.0
var successful_strategies: Array[String] = []
var failed_strategies: Array[String] = []

# Social metrics
var discoveries_broadcasted: int = 0
var discoveries_received: int = 0
var social_learning_rate: float = 0.0

# Evolutionary metrics
var offspring_count: int = 0
var genetic_distance_from_parent: float = 0.0
var behavioral_distance_from_parent: float = 0.0

func calculate_lifetime() -> float:
	if death_time > 0:
		return death_time - birth_time
	else:
		return Time.get_ticks_msec() / 1000.0 - birth_time

func success_rate() -> float:
	var total = goals_completed + goals_failed
	if total == 0:
		return 0.0
	return float(goals_completed) / total

func calculate_fitness_score() -> float:
	# Holistic fitness: how well is this creature doing?
	var survival_score = calculate_lifetime() / 300.0  # 5 min = 1.0
	var goal_success_score = success_rate()
	var learning_score = float(behaviors_learned) / 10.0
	var memory_utilization = float(memory_to_navigation_conversions) / max(goals_completed, 1)
	
	# Weighted average
	var fitness = (survival_score * 0.4 +
	              goal_success_score * 0.3 +
	              learning_score * 0.2 +
	              memory_utilization * 0.1)
	
	return clamp(fitness, 0.0, 1.0)

func print_summary() -> void:
	print("=== Creature %s ===" % creature_id)
	print("Lifetime: %.1f sec" % calculate_lifetime())
	print("Goal Success Rate: %.1f%%" % (success_rate() * 100.0))
	print("Goals Completed: %d" % goals_completed)
	print("Memories Recorded: %d" % episodic_memories_recorded)
	print("Routes Learned: %d" % routes_learned)
	print("Discoveries Shared: %d" % discoveries_broadcasted)
	print("Fitness Score: %.2f" % calculate_fitness_score())
	print("Average Hunger: %.1f%%" % avg_hunger_over_lifetime)
```

### 8.2 Ecosystem Metrics

```gdscript
class_name EcosystemMetrics

var population_history: Array[int] = []
var avg_lifetime_history: Array[float] = []
var avg_fitness_history: Array[float] = []
var resource_patch_utilization_history: Array[float] = []
var social_learning_rate_history: Array[float] = []
var generation_count: int = 0

func update(all_creatures: Array[Creature], patches: Array[ResourcePatch]) -> void:
	var current_pop = all_creatures.size()
	population_history.append(current_pop)
	
	if current_pop == 0:
		avg_lifetime_history.append(0.0)
		avg_fitness_history.append(0.0)
		return
	
	var total_lifetime = 0.0
	var total_fitness = 0.0
	for creature in all_creatures:
		total_lifetime += creature.metrics.calculate_lifetime()
		total_fitness += creature.metrics.calculate_fitness_score()
	
	avg_lifetime_history.append(total_lifetime / current_pop)
	avg_fitness_history.append(total_fitness / current_pop)
	
	# Patch utilization: how many patches are being visited?
	var visited_patches = 0
	for patch in patches:
		if patch.last_visit_time > Time.get_ticks_msec() / 1000.0 - 60.0:
			visited_patches += 1
	
	resource_patch_utilization_history.append(float(visited_patches) / max(patches.size(), 1))

func is_ecosystem_stable() -> bool:
	if population_history.size() < 10:
		return false
	
	# Check if population variance is low (not spiking/crashing)
	var recent_pop = population_history.slice(-10)
	var avg_pop = 0.0
	for p in recent_pop:
		avg_pop += p
	avg_pop /= recent_pop.size()
	
	var variance = 0.0
	for p in recent_pop:
		variance += pow(p - avg_pop, 2)
	variance /= recent_pop.size()
	
	var std_dev = sqrt(variance)
	var cv = std_dev / avg_pop if avg_pop > 0 else 999.0  # coefficient of variation
	
	return cv < 0.3  # Stable if < 30% variation

func print_report() -> void:
	print("=== ECOSYSTEM REPORT (Generation %d) ===" % generation_count)
	print("Population: %d creatures" % population_history.back())
	print("Avg Lifetime: %.1f sec" % avg_lifetime_history.back())
	print("Avg Fitness: %.2f" % avg_fitness_history.back())
	print("Patch Utilization: %.1f%%" % (resource_patch_utilization_history.back() * 100.0))
	print("Ecosystem Stable: %s" % is_ecosystem_stable())
```

### 8.3 Test Scenarios

```gdscript
# in tests/test_creature_ai.gd

func test_memory_navigation() -> void:
	"""
	Test: Creature finds food once, then navigates there again
	Expected: Second journey should be faster and more direct
	"""
	var creature = create_test_creature()
	
	# Scenario 1: Random search
	spawn_food_at(Vector2(200, 200))
	simulate_until_goal_reached(creature, 30.0)
	var first_journey_time = creature.metrics.total_distance_traveled
	
	# Wait for memory to settle
	await get_tree().create_timer(5.0).timeout
	
	# Scenario 2: Second food spawn at same location
	spawn_food_at(Vector2(200, 200))
	creature.global_position = Vector2(100, 100)  # reset position
	simulate_until_goal_reached(creature, 30.0)
	var second_journey_time = creature.metrics.total_distance_traveled
	
	# Second journey should be faster
	assert(second_journey_time < first_journey_time * 1.2, 
	       "Memory not improving navigation: %.1f > %.1f" % 
	       [second_journey_time, first_journey_time * 1.2])

func test_proactive_hunger_response() -> void:
	"""
	Test: Creature starts seeking food BEFORE critical hunger
	Expected: Creature should reach food before hunger >= 85
	"""
	var creature = create_test_creature()
	spawn_food_at(creature.global_position + Vector2(100, 0))
	
	var max_hunger_reached = 0.0
	while not creature.is_dead():
		max_hunger_reached = max(max_hunger_reached, creature.brain.needs.hunger)
		if creature.brain.needs.hunger < 10.0:  # Successfully ate
			break
		await get_tree().create_timer(0.1).timeout
	
	assert(max_hunger_reached < 85.0, 
	       "Creature reached critical hunger: %.1f" % max_hunger_reached)

func test_social_learning() -> void:
	"""
	Test: One creature discovers food, broadcasts to nearby creature
	Expected: Second creature should show memory of that location
	"""
	var creature_a = create_test_creature(Vector2(100, 100))
	var creature_b = create_test_creature(Vector2(150, 100))  # nearby
	
	spawn_food_at(Vector2(200, 200))
	
	# Creature A finds food
	simulate_until_goal_reached(creature_a, 20.0)
	
	# Wait for broadcast
	await get_tree().create_timer(2.0).timeout
	
	# Creature B should now have memory of food location
	var food_memories = creature_b.brain.episodic_memory.query_locations(
		"found_food", Time.get_ticks_msec() / 1000.0
	)
	
	assert(not food_memories.is_empty(), 
	       "Social learning failed: B didn't receive knowledge from A")

func test_ecosystem_stability() -> void:
	"""
	Test: Ecosystem with persistent patches should remain stable
	Expected: Population should not crash after initial phase
	"""
	setup_full_ecosystem(creature_count = 10)
	
	var metrics = EcosystemMetrics.new()
	for frame in range(600):  # 10 minutes of gameplay at 60fps
		simulate_frame()
		if frame % 60 == 0:  # Every second
			metrics.update(get_all_creatures(), get_all_patches())
		await get_tree().create_timer(0.016).timeout  # ~60fps
	
	assert(metrics.is_ecosystem_stable(), 
	       "Ecosystem unstable: population crashed or spiked")
```

---

## ЧАСТЬ 9: РИСКИ И АНТИ-ПАТТЕРНЫ

### Риск 1: Reward Hacking / Unintended Optimization

**Проблема:**
Если weight learning слишком агрессивен, существо может "зафиксироваться" на одном поведении, даже если оно больше не оптимально.

**Пример:**
```gdscript
# ❌ НЕПРАВИЛЬНО: слишком быстрый learning rate
brain.learning.reinforce_behavior(behavior_id, success, learning_rate = 1.0)
# Результат: behavior_weight скачет от 0 к 1 с первого события
```

**Решение:**
```gdscript
# ✓ ПРАВИЛЬНО: осторожный learning rate с decay
var learning_rate = 0.1 * (0.99 ^ creature_age_in_hours)  # decay over time
brain.learning.reinforce_behavior(behavior_id, success, learning_rate)

# Плюс: регулярный decay всех весов к baseline
func regularize_behavior_weights() -> void:
	for behavior in brain.learning.behavior_weights.values():
		behavior.weight = lerp(behavior.weight, 0.5, 0.01)  # baseline = 0.5
```

### Риск 2: Local Optima Trap

**Проблема:**
Существо учится, что ходить в одно место хорошо, и никогда не исследует альтернативы.

**Пример:**
```gdscript
# ❌ НЕПРАВИЛЬНО: greedy selection
var best_place = semantic_memory.get_places_by_type("food").max_by(lambda p: p.reputation)
set_goal_to(best_place)  # Always pick best
```

**Решение:**
```gdscript
# ✓ ПРАВИЛЬНО: epsilon-greedy exploration
var exploration_rate = 0.1 * (1.0 + brain.genetics.curiosity_modifier)
if randf() < exploration_rate:
	# Explore: pick random place or unexplored area
	var all_places = semantic_memory.get_places_by_type("food")
	var target = all_places[randi() % all_places.size()]
else:
	# Exploit: pick best
	var target = semantic_memory.get_places_by_type("food").max_by(lambda p: p.reputation)

set_goal_to(target)
```

### Риск 3: Memory Bloat & Incorrect Aggregation

**Проблема:**
Episodic memory растет без контроля; или memory entries aggregated неправильно в semantic memory.

**Решение:**
```gdscript
# Ограничить размер
const EPISODIC_MEMORY_MAX = 500
if episodic_memory.entries.size() > EPISODIC_MEMORY_MAX:
	# Remove oldest or least confident entries
	episodic_memory.entries.sort_custom(func(a, b):
		return a.confidence_decay(_current_time()) < b.confidence_decay(_current_time())
	)
	while episodic_memory.entries.size() > EPISODIC_MEMORY_MAX:
		episodic_memory.entries.pop_front()

# Правильно агрегировать в semantic memory
func consolidate_episodic_to_semantic() -> void:
	var food_memories = episodic_memory.query_locations("found_food", _current_time())
	
	# Cluster similar locations
	var clusters: Dictionary[Vector2, Array] = {}
	for mem in food_memories:
		var cluster_key = mem.location.round() / 50.0  # Grid: 50px cells
		if not clusters.has(cluster_key):
			clusters[cluster_key] = []
		clusters[cluster_key].append(mem)
	
	# Create semantic places from clusters
	for cluster_pos in clusters:
		var avg_reward = 0.0
		for mem in clusters[cluster_pos]:
			avg_reward += mem.emotional_valence
		avg_reward /= clusters[cluster_pos].size()
		
		var place = semantic_memory.register_place(
			cluster_pos * 50.0,
			"food_patch",
			current_biome
		)
		place.average_reward = avg_reward * 100.0
```

### Риск 4: Goal Abandonment & Flakiness

**Проблема:**
Существо постоянно меняет цели, никогда ничего не завершает.

**Решение:**
```gdscript
# ✓ Sticky goals: переоценка происходит реже
var goal_reevaluation_chance = 0.05  # 5% chance per decision
if randf() < goal_reevaluation_chance:
	if should_abandon_current_goal():
		set_new_goal()
	# else: keep current goal
else:
	# Force continuing current goal
	pass

func should_abandon_current_goal() -> bool:
	if not brain.goal_system.current_goal:
		return false
	
	# Only abandon if:
	# 1) Goal is expired
	if brain.goal_system.current_goal.is_expired(_current_time()):
		return true
	
	# 2) More critical need appeared
	var new_primary_need = _select_primary_need()
	var current_need = goal_to_need(brain.goal_system.current_goal.goal_type)
	if new_primary_need != current_need and \
	   _score_need(new_primary_need) > _score_need(current_need) * 1.5:
		return true
	
	# 3) Goal target became impossible (blocked, despawned)
	if is_goal_target_unreachable():
		return true
	
	return false
```

### Риск 5: Uncalibrated World Model

**Проблема:**
Предсказания мира (est_time_to_food) неправильны → неверные решения.

**Решение:**
```gdscript
# Калибровать модель на основе реальных данных
class_name WorldModelCalibration

var estimated_vs_actual: Array[Dictionary] = []

func record_prediction(est_time: float, actual_time: float) -> void:
	estimated_vs_actual.append({
		"estimated": est_time,
		"actual": actual_time,
		"error": abs(est_time - actual_time) / max(actual_time, 0.1)
	})
	
	if estimated_vs_actual.size() > 100:
		estimated_vs_actual.pop_front()

func get_calibration_factor() -> float:
	if estimated_vs_actual.is_empty():
		return 1.0
	
	var avg_error = 0.0
	for record in estimated_vs_actual:
		avg_error += record["error"]
	avg_error /= estimated_vs_actual.size()
	
	# If we're systematically underestimating, apply factor
	if avg_error > 0.2:  # >20% error
		return 1.2  # Add 20% safety margin
	return 1.0

# Apply factor in prediction
var est_time = _calculate_distance_to_food() / creature_speed
var calibrated_time = est_time * world_model_calibration.get_calibration_factor()
```

### Риск 6: Infinite Loop в планировании

**Проблема:**
Planner генерирует план, который не может быть выполнен → план не обновляется → существо зависает.

**Решение:**
```gdscript
# Планировать с timeout и fallback
func _generate_action_plan() -> void:
	var plan_start_time = _current_time()
	var max_plan_generation_time = 0.5  # seconds
	
	var plan = ActionPlan.new()
	plan.plan_created_time = plan_start_time
	
	# Try to plan
	var success = try_generate_detailed_plan(plan)
	
	# If detailed planning takes too long, fallback to simple plan
	if _current_time() - plan_start_time > max_plan_generation_time:
		plan = create_simple_fallback_plan()
	
	# If still failed, just go to goal
	if not success:
		plan.steps.clear()
		plan.add_step("move_to", brain.goal_system.current_goal.target_location, 60.0)
	
	brain.action_plan = plan

# Плюс: мониторить plan stuckness
func detect_stuck_plan() -> bool:
	var current_step = brain.action_plan.get_current_step()
	if not current_step:
		return false
	
	# If we've been on same step for too long, it's stuck
	var step_duration = _current_time() - brain.action_plan.plan_created_time
	if step_duration > current_step.duration_estimate * 2.0:
		return true
	
	return false

# In main update loop:
if detect_stuck_plan():
	print("Plan stuck, regenerating")
	_generate_action_plan()
```

### Риск 7: Evolution Bottleneck (Genetic Drift)

**Проблема:**
Все существа эволюционируют в одну стратегию; разнообразие теряется.

**Решение:**
```gdscript
# Явно сохранять разнообразие
func select_parents_for_breeding(population: Array[Creature]) -> Array[Creature]:
	# Tournament selection с diversity bonus
	var parent_a = select_with_diversity_bonus(population)
	
	# Select parent_b, preferring genetic distance от parent_a
	var parent_b = select_with_diversity_bonus(
		population,
		existing_parent = parent_a,
		diversity_weight = 0.3
	)
	
	return [parent_a, parent_b]

func select_with_diversity_bonus(population: Array[Creature],
                                  existing_parent: Creature = null,
                                  diversity_weight: float = 0.0) -> Creature:
	var scores: Array[float] = []
	for creature in population:
		var fitness = creature.metrics.calculate_fitness_score()
		var diversity_bonus = 0.0
		
		if existing_parent:
			var genetic_distance = creature.genetics.distance_to(existing_parent.genetics)
			diversity_bonus = diversity_weight * (genetic_distance / 10.0)  # normalize
		
		scores.append(fitness + diversity_bonus)
	
	# Select top 25% by weighted random
	var top_quartile_idx = int(population.size() * 0.25)
	var top_creatures = []
	for i in range(top_quartile_idx):
		var max_idx = scores.find(scores.max())
		top_creatures.append(population[max_idx])
		scores[max_idx] = -9999.0
	
	return top_creatures[randi() % top_creatures.size()]
```

---

## ЧАСТЬ 10: ИТОГОВАЯ АРХИТЕКТУРА (VISUAL)

```
CREATURE AI ARCHITECTURE - HOSHI
─────────────────────────────────────────────────────────────────

┌─────────────────────────────────────────────────────────────────┐
│                      LAYER 0: BODY STATE                        │
│  ┌───────────────┬──────────────┬──────────────┬──────────────┐ │
│  │   Hunger      │   Thirst     │   Fatigue    │   Stress     │ │
│  │   Temperature │   Pain       │   Oxygen     │   Social Urge│ │
│  └───────────────┴──────────────┴──────────────┴──────────────┘ │
│  Updates: Every frame (homeostatic dynamics)                    │
│  Role: Drives all motivation                                     │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                    LAYER 1: PERCEPTION                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Scan biome (position, temperature, threat level)         │   │
│  │ Detect nearby creatures, food, dangers                   │   │
│  │ Update short-term "what's around me" state              │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Every frame                                           │
│  Role: Ground truth about immediate environment                 │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                  LAYER 2: WORLD MODEL                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Predict:                                                 │   │
│  │  • Time to nearest food/water (based on memory + sight) │   │
│  │  • Survival time with current trajectory                │   │
│  │  • Risk on different paths                               │   │
│  │  • Novelty / exploration bonus                           │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Every decision (0.2s)                                 │
│  Role: Abstract reasoning about future                          │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────���───────────────────────────────────────────┐
│              LAYER 3: MEMORY QUERY & RECALL                     │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ EPISODIC MEMORY: "Where did I find food before?"         │   │
│  │  - Events: time, location, biome, emotional value        │   │
│  │  - Decay: confidence decreases with age                  │   │
│  │  - Query: search by type, location, time                 │   │
│  │                                                           │   │
│  │ SEMANTIC MEMORY: "Which places are reliable?"            │   │
│  │  - Places: reputation, resource level, visit count       │   │
│  │  - Routes: danger, success rate, traversal time          │   │
│  │  - Clustering: nearby events → single "place"            │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Query on demand (every decision)                      │
│  Role: Convert past experiences → actionable targets            │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                 LAYER 4: NEED PRIORITIZATION                    │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Utility AI: Score each need                              │   │
│  │                                                           │   │
│  │ Score = f(                                               │   │
│  │   current_level,                    // urgency           │   │
│  │   time_to_critical,                 // risk              │   │
│  │   time_to_resource,                 // feasibility       │   │
│  │   intelligence_modifier,            // planning ability   │   │
│  │   recent_satisfaction               // habituation       │   │
│  │ )                                                         │   │
│  │                                                           │   │
│  │ Select: PRIMARY_NEED = argmax(all_scores)               │   │
│  │ Override: if any need critical, ignore others            │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Every decision                                        │
│  Role: What should I care about NOW?                            │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────���───────────────────────────────────────────┐
│                   LAYER 5: GOAL SELECTION                       │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Given PRIMARY_NEED, select TARGET and CREATE GOAL        │   │
│  │                                                           │   │
│  │ TARGET selection:                                        │   │
│  │  1) Query memory: known good places?                     │   │
│  │  2) Expand search radius based on confidence             │   │
│  │  3) Add exploration bonus for novel areas                │   │
│  │  4) Fallback: random search if no memory                 │   │
│  │                                                           │   │
│  │ GOAL creation:                                           │   │
│  │  - type: FIND_FOOD, FIND_WATER, REST, etc.             │   │
│  │  - target: Vector2 (from memory or search radius)        │   │
│  │  - confidence: high if from memory, low if random        │   │
│  │  - timeout: typically 60 seconds                         │   │
│  │  - state: ACTIVE                                         │   │
│  │                                                           │   │
│  │ PERSISTENCE:                                             │   │
│  │  - Goal persists until timeout or explicit completion    │   │
│  │  - Not evaluated every frame (sticky goals)              │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: When no active goal or goal reevaluation chance       │
│  Role: Commit to a specific target                              │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                 LAYER 6: ACTION PLANNING                        │
│  ┌──────────────────��───────────────────────────────────────┐   │
│  │ Given GOAL, generate ACTION PLAN                         │   │
│  │                                                           │   │
│  │ Simple planner (for now):                                │   │
│  │  1. Move to target                                       │   │
│  │  2. Search (if not visible)                              │   │
│  │  3. Consume/interact                                     │   │
│  │  4. Return to safe zone (optional)                       │   │
│  │                                                           │   │
│  │ Future: GOAP/HTN-style planning with conditions          │   │
│  │                                                           │   │
│  │ PLAN STICKINESS:                                         │   │
│  │  - Re-plan only if: plan too old, goal changed, stuck   │   │
│  │  - Don't re-plan every frame (expensive)                │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: When goal selected or plan stale                      │
│  Role: Sequence of concrete steps                               │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌──────────────────────────────────────────────────────��──────────┐
│              LAYER 7: BEHAVIOR EXECUTION                        │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Get current PLAN STEP and EXECUTE                        │   │
│  │                                                           │   │
│  │ Action types:                                            │   │
│  │  • move_to(target): Physics/pathfinding                  │   │
│  │  • search(area): Raycast/sensor check                    │   │
│  │  • eat/drink: State transition + consumption             │   │
│  │  • rest: Reduce fatigue                                  │   │
│  │  • wait: Hold position                                   │   │
│  │                                                           │   │
│  │ Behavior Tree or simple state machine                    │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Every frame (physics process)                         │
│  Role: Ground-truth action in world                             │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│              LAYER 8: OUTCOME DETECTION                         │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Was the action successful?                               │   │
│  │                                                           │   │
│  │ Check:                                                   │   │
│  │  • Did we reach the goal?                                │   │
│  │  • Did we acquire resource?                              │   │
│  │  • Did threat encounter?                                 │   │
│  │  • Did something unexpected happen?                      │   │
│  │                                                           │   │
│  │ Generate EVENT for memory recording                      │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Every frame, or when significant event                │
│  Role: Detect ground truth to learn from                        │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│             LAYER 9: LEARNING & MEMORY UPDATE                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ EPISODIC MEMORY:                                         │   │
│  │  - Record event: (type, location, timestamp, valence)   │   │
│  │  - Decay: confidence -= over time                        │   │
│  │                                                           │   │
│  │ SEMANTIC MEMORY:                                         │   │
│  │  - Register place: cluster nearby events                 │   │
│  │  - Update reputation: success → reputation++             │   │
│  │  - Update route: mark as successful/failed               │   │
│  │  - Update resource_abundance: if depleted, mark down     │   │
│  │                                                           │   │
│  │ REINFORCEMENT LEARNING:                                  │   │
│  │  - Identify behavior used: "go_to_memory", "explore"     │   │
│  │  - Update weight: success → weight++, fail → weight--    │   │
│  │  - Learning rate depends on intelligence                 │   │
│  │                                                           │   │
│  │ SOCIAL BROADCASTING:                                     │   │
│  │  - If significant discovery (food, safe zone):           │   │
│  │    - Send to nearby creatures within broadcast_range     │   │
│  │    - Transmission chance depends on sociability          │   │
│  │    - Receiver gets episodic memory entry                 │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: After goal completion or significant event            │
│  Role: Convert experience → knowledge                           │
└─────────────────────────────────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│          LAYER 10: GENETIC EVOLUTION (meta-level)               │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │ Upon reproduction:                                       │   │
│  │  - Fitness = f(lifetime, goal_success, learning_rate)   │   │
│  │  - Genetics inherited with variation                     │   │
│  │  - New genes affect:                                     │   │
│  │    • intelligence → faster learning, better planning    │   │
│  │    • curiosity → more exploration                        │   │
│  │    • sociability → better social learning               │   │
│  │    • search_radius → how far to look for food           │   │
│  │    • metabolic_efficiency → lower hunger_rate           │   │
│  │                                                           │   │
│  │ Selective pressure:                                      │   │
│  │  - Only fit creatures reproduce                          │   │
│  │  - Diversity maintained via fitness + genetic_distance   │   │
│  │  - Different phenotypes emerge in different biomes       │   │
│  └──────────────────────────────────────────────────────────┘   │
│  Updates: Upon creature death/birth                             │
│  Role: Adapt population to selection pressure                   │
└─────────────────────────────────────────────────────────────────┘

                      TIME-STEP FLOW
─────────────────────────────────────────────────────────────────

Each frame (δt):
  1. Update physics (velocity, position)
  2. Update homeostasis (hunger, thirst, fatigue)
  3. Update perception (nearby creatures, food, threats)
  
Every 0.2s (decision loop):
  4. Query world model
  5. Query memory
  6. Prioritize needs
  7. Select goal (if needed)
  8. Generate/update plan (if needed)
  9. Execute current action
  10. Detect outcome
  11. Update learning & memory
  12. Broadcast discoveries

Async (slower):
  - Genetic evolution (upon death/reproduction)
  - Memory consolidation (episodic → semantic)
  - Behavior weight regularization
```

---

## ФИНАЛЬНЫЕ РЕКОМЕНДАЦИИ

### Что внедрить ПЕРВЫМ (День 2-3):

1. **SemanticMemory + PlaceRecord** → существа должны помнить, где была еда
2. **_select_target_from_memory()** → navigation должна использовать эту память
3. **_record_goal_outcome()** → обновлять место-репутацию после успеха
4. **Перспективные нужды** → hunger urgency должна зависеть от того, сколько времени до еды

### Какие проверки добавить:

- [ ] Debug draw: показать все запомненные места на экране
- [ ] Debug log: каждый раз, когда существо выбирает goal, логировать его
- [ ] Метрика: % времени, проведенного в целедиректированном поведении vs wander
- [ ] Метрика: средний возраст при смерти (увеличится, когда будет работать memory)

### Какие параметры СРАЗУ начать настраивать:

- `MEMORY_CONFIDENCE_DECAY` — как быстро забывать
- `NEED_URGENCY_SCALE` — как сильно память влияет на выбор
- `GOAL_REEVALUATION_CHANCE` — как часто менять цели
- `LEARNING_RATE` — как быстро обновлять веса

### Что НЕ делать:

- ❌ Не оптимизировать AI раньше, чем она работает базово
- ❌ Не добавлять сложный GOAP/HTN с первого раза
- ❌ Не использовать нейросети без бекапа и контроля
- ❌ Не менять механику спавна ресурсов без тестирования экосистемы
- ❌ Не игнорировать debug visualization

---

Это полный технический blueprint. Начните с PHASE 1 (Memory Integration), запустите проект, соберите метрики, и двигайтесь пошагово. **Простота и отладываемость важнее, чем максимальная сложность.**

## Main AI Brain: Orchestrates all layers and decision-making
## This is the core decision loop
class_name CreatureBrain

var creature_id: String
var genetics: Dictionary  # Will link to CreatureGenetics
var personality: Dictionary  # Will link to CreaturePersonality

# LAYER 0: Homeostasis
var needs: CreatureNeeds

# LAYER 3: Memory
var episodic_memory: EpisodicMemory
var semantic_memory: SemanticMemory

# LAYER 2: World Model
var world_model: WorldModel

# LAYER 4-5: Goals
var goal_system: CreatureGoal
var action_plan: ActionPlan

# LAYER 6: Learning
var learning: CreatureLearning

# World context (updated each frame)
var current_position: Vector2
var current_biome: String
var nearby_creatures: Array[Node2D] = []
var nearby_threats: Array[Node2D] = []
var nearby_food: Array[Node2D] = []
var last_decision_time: float = 0.0

# Debug
var debug_last_decision: String = "NONE"

func _init(p_id: String) -> void:
	creature_id = p_id
	
	# Initialize all systems
	needs = CreatureNeeds.new()
	needs.hunger_rate = CreatureAIConstants.HUNGER_RATE
	needs.thirst_rate = CreatureAIConstants.THIRST_RATE
	
	episodic_memory = EpisodicMemory.new(CreatureAIConstants.EPISODIC_MEMORY_MAX_ENTRIES)
	semantic_memory = SemanticMemory.new()
	world_model = WorldModel.new(CreatureAIConstants.CREATURE_SPEED)
	goal_system = CreatureGoal.new()
	action_plan = ActionPlan.new()
	learning = CreatureLearning.new()
	
	genetics = {}
	personality = {}

## Main update loop - called from creature's _physics_process
func update(delta: float) -> void:
	# STEP 0: Perception is handled by creature itself
	# (done in creature._update_perception)
	
	# STEP 1: Update homeostasis every frame
	_update_homeostasis(delta)

## Make decision (called less frequently, every ~0.2s)
func make_decision(current_time: float) -> void:
	# STEP 2: Update world model
	_update_world_model()
	
	# STEP 3: Evaluate needs
	var primary_need = _select_primary_need()
	
	# STEP 4: Select or validate goal
	_evaluate_and_select_goal(primary_need, current_time)
	
	# STEP 5: Generate or update plan
	_generate_or_update_plan(current_time)
	
	# Debug
	debug_last_decision = "%s (goal: %s)" % [primary_need, goal_system.get_goal_type_name()]
	last_decision_time = current_time

## Get next action to execute
func get_next_action() -> ActionPlan.ActionStep:
	return action_plan.get_current_step()

# ============ INTERNAL HELPERS ============

func _update_homeostasis(delta: float) -> void:
	# Apply metabolic costs
	needs.hunger += needs.hunger_rate * delta
	needs.thirst += needs.thirst_rate * delta
	
	# Activity affects fatigue
	if current_position.length() > 0:  # moving
		needs.fatigue += 0.5 * delta
	else:  # resting
		needs.fatigue -= needs.fatigue_recovery * delta
	
	# Stress from threats
	if not nearby_threats.is_empty():
		needs.stress += 2.0 * delta
	else:
		needs.stress -= needs.stress_recovery * delta
	
	# Clamp
	needs.clamp_all()
	
	# Update survival prediction
	var est_time_to_food = world_model.estimate_time_to_nearest_food(current_position)
	needs.update_predicted_survival(est_time_to_food)

func _update_world_model() -> void:
	# Query semantic memory for known patches
	var food_places = semantic_memory.get_places_by_type("food_patch")
	var water_places = semantic_memory.get_places_by_type("water_source")
	
	var food_locations: Array[Vector2] = []
	var water_locations: Array[Vector2] = []
	
	for place in food_places:
		food_locations.append(place.location)
	for place in water_places:
		water_locations.append(place.location)
	
	world_model.update_food_patches(food_locations)
	world_model.update_water_patches(water_locations)

func _select_primary_need() -> String:
	# Check for critical needs first
	if needs.is_critical("hunger"):
		return "hunger"
	if needs.is_critical("thirst"):
		return "thirst"
	
	# Score all needs
	var need_scores: Dictionary = {
		"hunger": _score_need("hunger"),
		"thirst": _score_need("thirst"),
		"fatigue": _score_need("fatigue"),
		"social": _score_need("social"),
		"explore": _score_need("explore")
	}
	
	# Return highest
	var max_need = "explore"
	var max_score = 0.0
	for need_name in need_scores:
		if need_scores[need_name] > max_score:
			max_score = need_scores[need_name]
			max_need = need_name
	
	return max_need

func _score_need(need_name: String) -> float:
	# Utility formula: urgency * (intelligence bonus) - recent_satisfaction
	var urgency = 0.0
	var intelligence_bonus = 1.0  # Will use genetics.intelligence_modifier
	
	match need_name:
		"hunger":
			urgency = needs.get_urgency("hunger")
			
			# Risk factor: if food far, increase urgency
			var est_time_to_food = world_model.estimate_time_to_nearest_food(current_position)
			if est_time_to_food > needs.predicted_survival_seconds * 0.8:
				urgency *= 1.5  # DANGER
			
			urgency *= intelligence_bonus
		
		"thirst":
			urgency = needs.get_urgency("thirst")
			urgency *= intelligence_bonus
		
		"fatigue":
			urgency = needs.get_urgency("fatigue") * 0.5
		
		"social":
			# Only if other creatures nearby
			urgency = needs.get_urgency("social_need")
			if nearby_creatures.is_empty():
				urgency *= 0.5
		
		"explore":
			# Curiosity-driven (only when other needs low)
			urgency = (1.0 - needs.get_urgency("hunger")) * 0.2
	
	return max(urgency, 0.0)

func _evaluate_and_select_goal(primary_need: String, current_time: float) -> void:
	# Check if current goal is still valid
	if goal_system.is_goal_valid(current_time):
		# Keep current goal (sticky)
		return
	
	# Need new goal
	var target: Vector2 = current_position
	var goal_type: CreatureGoal.GoalType = CreatureGoal.GoalType.EXPLORE
	var confidence: float = 0.5
	
	match primary_need:
		"hunger":
			goal_type = CreatureGoal.GoalType.FIND_FOOD
			var food_target = _select_target_from_memory("found_food")
			target = food_target if food_target != Vector2.ZERO else current_position
			confidence = 0.8 if food_target != Vector2.ZERO else 0.3
		
		"thirst":
			goal_type = CreatureGoal.GoalType.FIND_WATER
			var water_target = _select_target_from_memory("found_water")
			target = water_target if water_target != Vector2.ZERO else current_position
			confidence = 0.8 if water_target != Vector2.ZERO else 0.3
		
		"fatigue":
			goal_type = CreatureGoal.GoalType.REST
			target = current_position
			confidence = 0.7
		
		_:
			goal_type = CreatureGoal.GoalType.EXPLORE
			target = current_position + Vector2.from_angle(randf() * TAU) * 60.0
			confidence = 0.4
	
	goal_system.set_goal(goal_type, target, 0.8, CreatureAIConstants.GOAL_DEFAULT_TIMEOUT, confidence)

func _select_target_from_memory(event_type: String) -> Vector2:
	# Query episodic memory for locations
	var candidates = episodic_memory.query_locations(event_type, Time.get_ticks_msec() / 1000.0)
	
	if candidates.is_empty():
		return Vector2.ZERO
	
	# Find nearest with highest confidence
	candidates.sort_custom(func(a, b):
		var conf_a = a.confidence_decay(Time.get_ticks_msec() / 1000.0)
		var dist_a = a.location.distance_to(current_position)
		
		var conf_b = b.confidence_decay(Time.get_ticks_msec() / 1000.0)
		var dist_b = b.location.distance_to(current_position)
		
		var score_a = conf_a - dist_a / 200.0
		var score_b = conf_b - dist_b / 200.0
		
		return score_a > score_b
	)
	
	return candidates[0].location

func _generate_or_update_plan(current_time: float) -> void:
	# Replan if: no plan, plan too old, or stuck
	if action_plan.steps.is_empty() or \
	   action_plan.is_plan_stale(current_time, CreatureAIConstants.PLAN_MAX_AGE):
		
		_generate_simple_plan()

func _generate_simple_plan() -> void:
	action_plan.clear()
	action_plan.plan_created_time = Time.get_ticks_msec() / 1000.0
	
	if not goal_system.current_goal:
		return
	
	var target = goal_system.current_goal.target_location
	var distance = current_position.distance_to(target)
	var est_time = distance / CreatureAIConstants.CREATURE_SPEED
	
	# Step 1: Move to target
	action_plan.add_step("move_to", target, est_time)
	
	# Step 2-3: Goal-specific actions
	match goal_system.current_goal.goal_type:
		CreatureGoal.GoalType.FIND_FOOD:
			action_plan.add_step("search", target, 3.0)
			action_plan.add_step("eat", target, 2.0)
		
		CreatureGoal.GoalType.FIND_WATER:
			action_plan.add_step("search", target, 3.0)
			action_plan.add_step("drink", target, 2.0)
		
		CreatureGoal.GoalType.REST:
			action_plan.add_step("rest", target, 10.0)
		
		_:
			action_plan.add_step("wait", target, 5.0)

## Record outcome of a goal
func record_goal_outcome(success: bool, reward: float) -> void:
	var goal = goal_system.current_goal
	if not goal:
		return
	
	var behavior_id = _get_behavior_id_for_goal(goal)
	learning.reinforce_behavior(behavior_id, success, CreatureAIConstants.BEHAVIOR_WEIGHT_LEARNING_RATE)
	
	learning.record_outcome(
		goal_system.get_goal_type_name(),
		success,
		reward,
		{
			"location": goal.target_location,
			"biome": current_biome,
			"confidence": goal.confidence
		}
	)

func _get_behavior_id_for_goal(goal: CreatureGoal.Goal) -> String:
	match goal.goal_type:
		CreatureGoal.GoalType.FIND_FOOD:
			return "go_to_food_%.1f" % goal.confidence
		CreatureGoal.GoalType.FIND_WATER:
			return "go_to_water_%.1f" % goal.confidence
		_:
			return "explore"

## Get debug information
func get_debug_info() -> Dictionary:
	return {
		"creature_id": creature_id,
		"hunger": "%.1f" % needs.hunger,
		"thirst": "%.1f" % needs.thirst,
		"fatigue": "%.1f" % needs.fatigue,
		"current_goal": goal_system.get_goal_type_name(),
		"plan_progress": "%.1f%%" % (action_plan.get_progress() * 100.0),
		"last_decision": debug_last_decision,
		"memory_entries": episodic_memory.entries.size(),
		"known_places": semantic_memory.places.size()
	}

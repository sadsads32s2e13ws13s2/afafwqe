## Creature Metrics: Tracks performance and learning over lifetime
class_name CreatureMetrics

var creature_id: String
var birth_time: float
var death_time: float = -1.0

# Homeostatic metrics
var avg_hunger_over_lifetime: float = 0.0
var avg_thirst_over_lifetime: float = 0.0
var critical_hunger_events: int = 0
var starvation_deaths: int = 0

# Behavior metrics
var total_distance_traveled: float = 0.0
var goals_completed: int = 0
var goals_failed: int = 0
var average_goal_duration: float = 0.0
var wander_time_percent: float = 0.0
var goal_directed_time_percent: float = 0.0

# Memory metrics
var episodic_memories_recorded: int = 0
var places_discovered: int = 0
var routes_learned: int = 0
var memory_to_navigation_conversions: int = 0

# Learning metrics
var behaviors_learned: int = 0
var average_learning_rate: float = 0.0
var successful_strategies: Array[String] = []
var failed_strategies: Array[String] = []

# Social metrics
var discoveries_broadcasted: int = 0
var discoveries_received: int = 0
var social_learning_rate: float = 0.0

func _init(p_id: String) -> void:
	creature_id = p_id
	birth_time = Time.get_ticks_msec() / 1000.0

func calculate_lifetime() -> float:
	if death_time > 0:
		return death_time - birth_time
	else:
		return Time.get_ticks_msec() / 1000.0 - birth_time

func success_rate() -> float:
	var total = goals_completed + goals_failed
	if total == 0:
		return 0.0
	return float(goals_completed) / total

func calculate_fitness_score() -> float:
	var survival_score = calculate_lifetime() / 300.0  # 5 min = 1.0
	var goal_success_score = success_rate()
	var learning_score = float(behaviors_learned) / 10.0
	var memory_utilization = float(memory_to_navigation_conversions) / max(goals_completed, 1)
	
	var fitness = (survival_score * 0.4 +
	              goal_success_score * 0.3 +
	              learning_score * 0.2 +
	              memory_utilization * 0.1)
	
	return clamp(fitness, 0.0, 1.0)

func print_summary() -> void:
	print("=== Creature %s ===" % creature_id)
	print("Lifetime: %.1f sec" % calculate_lifetime())
	print("Goal Success Rate: %.1f%%" % (success_rate() * 100.0))
	print("Goals Completed: %d" % goals_completed)
	print("Memories Recorded: %d" % episodic_memories_recorded)
	print("Routes Learned: %d" % routes_learned)
	print("Fitness Score: %.2f" % calculate_fitness_score())

func to_dict() -> Dictionary:
	return {
		"creature_id": creature_id,
		"lifetime": calculate_lifetime(),
		"success_rate": success_rate(),
		"fitness": calculate_fitness_score(),
		"goals_completed": goals_completed,
		"episodic_memories": episodic_memories_recorded,
		"places_discovered": places_discovered
	}

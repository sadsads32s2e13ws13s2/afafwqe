# PHASE 1 Test Setup
#
# To run PHASE 1 tests, create a new scene with:
# 
# 1. Node2D (root)
#    - Attach script: ai_test_manager.gd
#    - Set spawn_creatures_count = 5
#    - Set spawn_food_per_frame = 1
#
# 2. Run the scene for 5 minutes (300 seconds)
#
# 3. Check output console for metrics

extends Node2D

@export var run_test: bool = true
@export var test_name: String = "PHASE_1_MEMORY_INTEGRATION"
@export var creatures_to_spawn: int = 5
@export var test_duration_seconds: int = 300

var test_manager: AITestManager

func _ready() -> void:
	if run_test:
		test_manager = AITestManager.new()
		test_manager.spawn_creatures_count = creatures_to_spawn
		test_manager.test_max_duration = test_duration_seconds
		add_child(test_manager)
		print("[TEST] Starting %s" % test_name)
